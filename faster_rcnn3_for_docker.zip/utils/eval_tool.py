from __future__ import division

from collections import defaultdict
import itertools
import numpy as np
import six  # Six is a Python 2 and 3 compatibility library. It provides utility functions for smoothing over the differences between the Python versions with the goal of writing Python code that is compatible on both Python versions

from model.utils.bbox_tools import bbox_iou


def eval_detection_voc( pred_bboxesF, pred_labelsF, pred_scoresF,
                        gt_bboxesF, gt_labelsF, gt_difficultsF,
                        cnt_obj_predF, cnt_obj_gtF,
                        iou_thresh=0.5, use_07_metric=False, list_id_imgs=[]):
    """Calculate average precisions based on evaluation code of PASCAL VOC.

    This function evaluates predicted bounding boxes obtained from a dataset
    which has :math:`N` images by using average precision for each class.
    The code is based on the evaluation code used in PASCAL VOC Challenge.

    Args:
        pred_bboxes (iterable of numpy.ndarray): An iterable of :math:`N`
            sets of bounding boxes.
            Its index corresponds to an index for the base dataset.
            Each element of :obj:`pred_bboxes` is a set of coordinates
            of bounding boxes. This is an array whose shape is :math:`(R, 4)`,
            where :math:`R` corresponds
            to the number of bounding boxes, which may vary among boxes.
            The second axis corresponds to
            :math:`y_{min}, x_{min}, y_{max}, x_{max}` of a bounding box.
        pred_labels (iterable of numpy.ndarray): An iterable of labels.
            Similar to :obj:`pred_bboxes`, its index corresponds to an
            index for the base dataset. Its length is :math:`N`.
        pred_scores (iterable of numpy.ndarray): An iterable of confidence
            scores for predicted bounding boxes. Similar to :obj:`pred_bboxes`,
            its index corresponds to an index for the base dataset.
            Its length is :math:`N`.
        gt_bboxes (iterable of numpy.ndarray): An iterable of ground truth
            bounding boxes
            whose length is :math:`N`. An element of :obj:`gt_bboxes` is a
            bounding box whose shape is :math:`(R, 4)`. Note that the number of
            bounding boxes in each image does not need to be same as the number
            of corresponding predicted boxes.
        gt_labels (iterable of numpy.ndarray): An iterable of ground truth
            labels which are organized similarly to :obj:`gt_bboxes`.
        gt_difficults (iterable of numpy.ndarray): An iterable of boolean
            arrays which is organized similarly to :obj:`gt_bboxes`.
            This tells whether the
            corresponding ground truth bounding box is difficult or not.
            By default, this is :obj:`None`. In that case, this function
            considers all bounding boxes to be not difficult.
        iou_thresh (float): A prediction is correct if its Intersection over
            Union with the ground truth is above this value.
        use_07_metric (bool): Whether to use PASCAL VOC 2007 evaluation metric
            for calculating average precision. The default value is
            :obj:`False`.

    Returns:
        dict:

        The keys, value-types and the description of the values are listed
        below.

        * **ap** (*numpy.ndarray*): An array of average precisions. \
            The :math:`l`-th value corresponds to the average precision \
            for class :math:`l`. If class :math:`l` does not exist in \
            either :obj:`pred_labels` or :obj:`gt_labels`, the corresponding \
            value is set to :obj:`numpy.nan`.
        * **map** (*float*): The average of Average Precisions over classes.

    """

    # Calculate Precision, Recall per CLASS (Note: this is not normal Precision, Recall : https://kharshit.github.io/blog/2019/09/20/evaluation-metrics-for-object-detection-and-segmentation)
    prec, rec = calc_detection_voc_prec_rec( pred_bboxesF, pred_labelsF, pred_scoresF,
                                             gt_bboxesF, gt_labelsF, gt_difficultsF,
                                             cnt_obj_predF, cnt_obj_gtF,
                                             iou_thresh=iou_thresh, list_id_imgs=list_id_imgs )

    # Calculate Average Precision (AP) per CLASS (not normal AP, this AP is calculated based on Precision-Recall Curve : https://kharshit.github.io/blog/2019/09/20/evaluation-metrics-for-object-detection-and-segmentation)
    ap = calc_detection_voc_ap( prec, rec, use_07_metric=use_07_metric )

    return {'ap': ap, 'map': np.nanmean(ap)}  # mAP is just the Average of ALL AP non NA CLASSES (np.nanmean : Compute the arithmetic mean, ignoring NaNs)


def calc_detection_voc_prec_rec( pred_bboxesF, pred_labelsF, pred_scoresF,
                                 gt_bboxesF, gt_labelsF, gt_difficultsF,
                                 cnt_obj_predF, cnt_obj_gtF,
                                 iou_thresh=0.5, list_id_imgs=[] ):
    """Calculate precision and recall based on evaluation code of PASCAL VOC.

    This function calculates precision and recall of
    predicted bounding boxes obtained from a dataset which has :math:`N`
    images.
    The code is based on the evaluation code used in PASCAL VOC Challenge.

    Args:
        same as above

    Returns:
        tuple of two lists:
        This function returns two lists: :obj:`prec` and :obj:`rec`.

        * :obj:`prec`: A list of arrays. :obj:`prec[l]` is precision \
            for class :math:`l`. If class :math:`l` does not exist in \
            either :obj:`pred_labels` or :obj:`gt_labels`, :obj:`prec[l]` is \
            set to :obj:`None`.
        * :obj:`rec`: A list of arrays. :obj:`rec[l]` is recall \
            for class :math:`l`. If class :math:`l` that is not marked as \
            difficult does not exist in \
            :obj:`gt_labels`, :obj:`rec[l]` is \
            set to :obj:`None`.

    """

# E.g. with 4 test photos:
#
# pred_bboxes 4 
#    [array([[221.61136 ,  44.299164, 487.33102 , 309.88437 ],
#            [ 25.14003 ,  30.123611, 492.1704  , 342.72693 ]], dtype=float32), 
#     array([[191.42728, 138.70303, 302.36884, 212.67474]], dtype=float32), 
#     array([], shape=(0, 4), dtype=float32),
#     array([[325.56445 , 366.76416 , 397.30756 , 497.12292 ],
#           [307.4119  ,  17.040134, 364.4894  ,  89.87898 ],
#           [330.57782 , 226.93521 , 370.17725 , 330.95572 ],
#           [326.009   , 173.09056 , 365.33005 , 236.80714 ],
#           [322.85275 ,  98.584496, 353.1072  , 145.67227 ],
#           [322.5796  , 137.15245 , 357.75793 , 193.14159 ],
#           [337.3039  , 116.71232 , 359.41534 , 145.02661 ],
#           [321.9413  ,  84.13301 , 351.60965 , 116.031525],
#           [336.00732 , 132.81207 , 360.46997 , 163.81601 ],
#           [325.2001  , 215.71725 , 356.9553  , 243.51517 ]], dtype=float32)]    ----> there are many predicted bbox than actual ground-truth bbox  : sort score, take only argmax in each object, the rest will be set to False Positive (even if these rests have IoU w.r.t ground-truth > 0.5)
#    
# pred_labels 4 
#    [array([11, 14], dtype=int32), 
#     array([18], dtype=int32), 
#     array([], dtype=int32),
#     array([6, 6, 6, 6, 6, 6, 6, 6, 6, 6], dtype=int32)]
#     
# pred_scores 4 
#    [array([0.7608298, 0.9993948], dtype=float32), 
#     array([0.9987317], dtype=float32), 
#     array([], dtype=float32),                                 ----> there is not even a predicted bbox (all score < 0.05 : the model is very sure that all bbox are backgrounds) !   -> recall 1 and precision 0 on this object
#     array([0.9997483 , 0.9984164 , 0.99511576, 0.99032074, 0.9720905 , 0.964653  , 0.555981  , 0.34069893, 0.21620221, 0.07177667], dtype=float32)]
#                                                               
#    -----------------------------------------
#  
# gt_bboxes 4 
#    [array([[239.,  47., 370., 194.],
#           [ 11.,   7., 497., 351.]], dtype=float32), 
#     array([[199., 138., 300., 206.]], dtype=float32), 
#     array([[154., 122., 194., 214.],
#           [155., 238., 204., 306.]], dtype=float32),
#     array([[310.,  12., 361.,  83.],
#           [329., 361., 388., 499.],
#           [327., 234., 374., 333.],
#           [326., 174., 363., 251.],
#           [319., 138., 358., 188.],
#           [324., 107., 352., 149.],
#           [322.,  83., 349., 120.]], dtype=float32)]
#           
# gt_labels 4 
#    [array([11, 14], dtype=int32), 
#     array([18], dtype=int32), 
#     array([17,  8], dtype=int32),
#     array([6, 6, 6, 6, 6, 6, 6], dtype=int32)]
#     
# gt_difficults 4 
#    [array([0, 0], dtype=uint8), 
#     array([0], dtype=uint8), 
#     array([0, 0], dtype=uint8),
#     array([0, 0, 0, 0, 0, 0, 0], dtype=uint8)]


    # Turn out that the solution to the Out-of-Memory problem is not write into hard disk (due to unsufficient RAM), it is the problem of Python List (which is much memory-consuming than numpy array !!!) -> we don't really need to write and read numpy array from file (cost a little bit more time !)
    pred_bboxes = np.load(pred_bboxesF, mmap_mode="r")
    pred_labels = np.load(pred_labelsF, mmap_mode="r")
    pred_scores = np.load(pred_scoresF, mmap_mode="r")
    gt_bboxes = np.load(gt_bboxesF, mmap_mode="r")
    gt_labels = np.load(gt_labelsF, mmap_mode="r")
    gt_difficults = np.load(gt_difficultsF, mmap_mode="r")

    cnt_obj_pred = np.load(cnt_obj_predF, mmap_mode="r")
    cnt_obj_gt = np.load(cnt_obj_gtF, mmap_mode="r")    
    
    prev_pred_index, prev_gt_index, n_photos = 0, 0, cnt_obj_pred.shape[0]

#    E.g. with 4 test photos:
#        cnt_obj_pred (4,) [2  3  3 13] 
#        cnt_obj_gt (4,) [2  3  5 12]

    #
    n_pos = defaultdict(int)    #  logo category index : number ground-truth bbox of this logo category in all photos of test set (for Recall calculation of each logo category)
    score = defaultdict(list)   #  logo category index : list confident score of predicted bbox of this logo category in all photos of test set
    match = defaultdict(list)   #  logo category index : list matching determination of predicted bbox w.r.t ground-truth (by IoU and keep only one predicted bbox with highest confident score on each logo object in each image)

    
    # Do calculations on EACH PHOTO ======================================================
    for i_photo in range(n_photos):
        
        # Get the right number of predicted bbox on each photo                                            
        pred_bbox = pred_bboxes[prev_pred_index:cnt_obj_pred[i_photo],:]  
        pred_label = pred_labels[prev_pred_index:cnt_obj_pred[i_photo]]
        pred_score = pred_scores[prev_pred_index:cnt_obj_pred[i_photo]] 
        # Get the right number of ground-truth bbox on each photo
        gt_bbox = gt_bboxes[prev_gt_index:cnt_obj_gt[i_photo],:]
        gt_label = gt_labels[prev_gt_index:cnt_obj_gt[i_photo]]
        gt_difficult = gt_difficults[prev_gt_index:cnt_obj_gt[i_photo]]
        
        prev_pred_index, prev_gt_index = cnt_obj_pred[i_photo], cnt_obj_gt[i_photo]
        
        # print("pred_bbox", pred_bbox.shape, pred_bbox)
        # print("pred_label", pred_label.shape, pred_label)
        # print("pred_score", pred_score.shape, pred_score)
        # print("gt_bbox", gt_bbox.shape, gt_bbox)
        # print("gt_label", gt_label.shape, gt_label)
        # print("gt_difficult", gt_difficult)
        

        if gt_difficult is None:
            gt_difficult = np.zeros(gt_bbox.shape[0], dtype=bool)
            
#        E.g. :
#        np.concatenate((pred_label, gt_label)).astype(int) 
#        [11 14 11 14]
#        np.unique(np.concatenate((pred_label, gt_label)).astype(int)) 
#        [11 14]     
        
        # Work on EACH OBJECT CATEGORY in the joint set of GROUND-TRUTH and *PREDICTED* bbox in EACH PHOTO =======================================
        for l in np.unique(np.concatenate((pred_label, gt_label)).astype(int)):   # Take an example with the 4th photo, there're only Object class 6
            
            # Consider only pred_bbox and pred_score (confident bbox score) of the SELECTED OBJECT CATEGORY *****************
            pred_mask_l = pred_label == l
            pred_bbox_l = pred_bbox[pred_mask_l]
            pred_score_l = pred_score[pred_mask_l]
            
            # SORT SELECTED pred_bbox and SELECTED pred_score  (confident bbox score)of the SELECTED OBJECT CATEGORY by pred_score
            order = pred_score_l.argsort()[::-1]
            pred_bbox_l = pred_bbox_l[order]
            pred_score_l = pred_score_l[order]




            # Consider only gt_bbox_l and gt_difficult_l of the SELECTED OBJECT LABEL *****************
            gt_mask_l = gt_label == l
            gt_bbox_l = gt_bbox[gt_mask_l]
            gt_difficult_l = gt_difficult[gt_mask_l]




            # Increase counter n_pos[logo category index] -----------------------------------------------------------
            # n_pos[logo category index] : number ground-truth bbox of this logo category in all photos of test set
            n_pos[l] += np.logical_not(gt_difficult_l).sum()   # np.logical_not : reverse bool value (True -> False, False -> True). 
            
#            gt_difficult_l   7
#            [0, 0, 0, 0, 0, 0, 0]       
#            np.logical_not(gt_difficult_l)
#            [True, True, True, True, True, True, True]
#            np.logical_not(gt_difficult_l).sum()
#            7   ground-truth bbox of this object category in this photo
            
            # Extend list score[logo category index] ----------------------------------------------------------
            # score[logo category index] : list confident score of predicted bbox of this logo category in all photos of test set
            score[l].extend(pred_score_l)
            
#            pred_score_l    10   predicted bbox of this object category in this photo (though we have only 7 ground-truth bbox of this object category in this photo)
#            [0.9997483 , 0.9984164 , 0.99511576, 0.99032074, 0.9720905 , 0.964653  , 0.555981  , 0.34069893, 0.21620221, 0.07177667]
            
            
            
            
            # Skip the rest if OBJECT CATEGORY appears ONLY either on pred_bbox or ground truth bbox side (make sense)
            # (as we can not compute IoU between two bbox)
            
#            pred_bbox_l (10, 4) 
#             array([[325.56445 , 366.76416 , 397.30756 , 497.12292 ],
#                   [307.4119  ,  17.040134, 364.4894  ,  89.87898 ],
#                   [330.57782 , 226.93521 , 370.17725 , 330.95572 ],
#                   [326.009   , 173.09056 , 365.33005 , 236.80714 ],
#                   [322.85275 ,  98.584496, 353.1072  , 145.67227 ],
#                   [322.5796  , 137.15245 , 357.75793 , 193.14159 ],
#                   [337.3039  , 116.71232 , 359.41534 , 145.02661 ],
#                   [321.9413  ,  84.13301 , 351.60965 , 116.031525],
#                   [336.00732 , 132.81207 , 360.46997 , 163.81601 ],
#                   [325.2001  , 215.71725 , 356.9553  , 243.51517 ]], dtype=float32)]
#            
#            (0,) * pred_bbox_l.shape[0]     10
#            (0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
#            
#            gt_bbox_l (7, 4) 
#             array([[310.,  12., 361.,  83.],
#                   [329., 361., 388., 499.],
#                   [327., 234., 374., 333.],
#                   [326., 174., 363., 251.],
#                   [319., 138., 358., 188.],
#                   [324., 107., 352., 149.],
#                   [322.,  83., 349., 120.]], dtype=float32)]
            
            if len(pred_bbox_l) == 0:
                # no predicted bbox coordinates for this object category in this photo (no matter if we have ground_truth bbox for this object category in this photo) => no need to store matching
                continue
            
            if len(gt_bbox_l) == 0:
                # we predict some bboxes (coordinates) for this object category in this photo but actually, this object category does not present in this photo (=> matchings for predicted bbox are stored zeros)
                match[l].extend((0,) * pred_bbox_l.shape[0])
                continue


            # *********************************
            # VOC evaluation : compute IoU between each predicted bbox and each ground-truth bbox of the same Object Category in the same photo to determine matching bbox 
            pred_bbox_l = pred_bbox_l.copy()
            pred_bbox_l[:, 2:] += 1                  #  why do we need to increase y-max height and x-max width of pred_bbox and ground_truth_bbox by 1 ?
            
            gt_bbox_l = gt_bbox_l.copy()
            gt_bbox_l[:, 2:] += 1

            iou = bbox_iou(pred_bbox_l, gt_bbox_l)   
#            iou  [10 predicted bbox, 7 ground-truth bbox]
#            [[-0.          0.787057   -0.         -0.         -0.         -0.          -0.        ]
#             [ 0.7651776  -0.         -0.         -0.         -0.         -0.           0.0429894 ]
#             [-0.         -0.          0.78181285  0.1310975  -0.         -0.          -0.        ]
#             [-0.         -0.          0.02062552  0.769715    0.127254   -0.          -0.        ]
#             [-0.         -0.         -0.         -0.          0.08284064  0.71930206   0.31071663]
#             [-0.         -0.         -0.          0.1511224   0.8176162   0.12689179  -0.        ]
#             [-0.         -0.         -0.         -0.          0.0684712   0.31420916   0.03226731]
#             [-0.         -0.         -0.         -0.         -0.          0.1457626    0.7997665 ]
#             [-0.         -0.         -0.         -0.          0.27546027  0.16502596  -0.        ]
#             [-0.         -0.          0.06007995  0.30808    -0.         -0.          -0.        ]]
            
            # Note !!! we don't take iou.argmax(axis=0) because it has a different meaning : it will be using as many predicted bbox to imitate each ground-truth bbox as much as possible (via IoU measure). The problem with this approach is that we can consider only IoU measure but we can not consider the confident score of predicted bbox (it can have high overlapping w.r.t ground-truth bbox but is very unsure about its object category type prediction)
            # When we take iou.argmax(axis=1) : it means that for each predicted bbox, find its nearest ground-truth bbox and keep this predicted bbox only if it has IoU > 0.5 with the nearest (best imitated) ground-truth bbox.
            # by this calculation, it can happen that two predicted bbox point to the same ground-truth bbox (IoU both > 0.5) of the same object category on the same photo (when the number of predicted bbox > the number of ground-truth bbox of that object category in that photo)
            # however, don't worry, we'll filter out multiple predicted bbox on the same ground-truth bbox of the same object category later (we'll keep ONLY ONE RIGHT predicted bbox with the highest confident score)
            gt_index = iou.argmax(axis=1)  # assign each PREDICTED bbox to only 1 GROUND-TRUTH bbox of that object category with the highest overlapping IoU w.r.t ground-truth bbox
#            gt_index   10 
#            [1 0 2 3 5 4 5 6 4 3]
            
            # set -1 if there is no matching ground truth (eliminate argmax predicted bbox that have low overlapping regions IoU < 0.5 with ground-truth bbox)
            gt_index[iou.max(axis=1) < iou_thresh] = -1
#            gt_index 
#            [ 1  0  2  3  5  4 -1  6 -1 -1]    #  =>  by this calculation, it can happen that two predicted bbox point to the same ground-truth bbox (IoU both > 0.5) of the same object category on the same photo (when the number of predicted bbox > the number of ground-truth bbox of that object category in that photo)
            
            # if l == 1 and list_id_imgs[i_photo]:   #  debug  ------------------------------
            #     print("image : ", list_id_imgs[i_photo])
            #     print("pred_bbox_l:\n", pred_bbox_l)
            #     print("gt_bbox_l:\n", gt_bbox_l)
            #     print("iou:\n", iou)
            #     print("gt_index:", gt_index)
                

            del iou





            # ----------------------------------------------------------------------------------------------------------
            # Extend match[logo category index] with the determination if predicted bbox is matched with ground-truth bbox)
            # match[logo category index] : list matching determination of predicted bbox w.r.t ground-truth (by IoU and keep only one predicted bbox with highest confident score on each logo object in each image)
            selec = np.zeros(gt_bbox_l.shape[0], dtype=bool)
            
            for gt_idx in gt_index:
                if gt_idx >= 0:                 #  the nearest & best matched (largest IoU) ground-truth bbox of this predicted bbox
                    if gt_difficult_l[gt_idx]:  #  if this nearest & best match(largest IoU) ground-truth is a difficult bbox type =>  set match = -1 (ignored in the calculation of accumulated Precision or accumulated Recall, even not False Positive)
                        match[l].append(-1)
                    else:                       #  this nearest & best match(largest IoU) ground-truth is not a difficult bbox type                                        
                        if not selec[gt_idx]:   #  only set the first (highest confident score in DESC order) predicted bbox to an unchosen ground-truth bbox (other predicted satisfied bbox with Lower Confident Score will not be set to the chosen ground-truth bbox)
                            match[l].append(1)
                        else:
                            match[l].append(0)
                    selec[gt_idx] = True
                else:                           #  predicted bbox does not match any ground-truth bbox (all IoU w.r.t ground-truth bbox are < 0.5)
                    match[l].append(0)          #  => set False Positive to this predicted bbox


            # if l == 1 and list_id_imgs[i_photo]:   #  debug  ------------------------------
            #     print("match[l]:", match[l], "\n")


#    n_pos 6     :    logo category index : number ground-truth bbox of this logo category in all photos of test set (for Recall calculation of each logo category)
#    defaultdict(<class 'int'>, {11: 1, 
#                                14: 1, 
#                                18: 1, 
#                                8 : 1, 
#                                17: 1, 
#                                6 : 7})                                       
#    
#    score 6     :    logo category index : list confident score of predicted bbox of this logo category in all photos of test set
#    defaultdict(<class 'list'>, {11: [0.7608298], 
#                                 14: [0.9993948], 
#                                 18: [0.9987317], 
#                                  8: [],            #  no predicted bbox for this category => in matching, we don't need to care about this category (even if there is or there is not ground-truth bbox)
#                                 17: [],            #  no predicted bbox for this category => in matching, we don't need to care about this category (even if there is or there is not ground-truth bbox)
#                                  6: [0.9997483, 0.9984164, 0.99511576, 0.99032074, 0.9720905, 0.964653, 0.555981, 0.34069893, 0.21620221, 0.071776666]})
#    
#    match 4     :    logo category index : list matching determination of predicted bbox w.r.t ground-truth (by IoU and keep only one predicted bbox with highest confident score on each logo object in each image)
#    defaultdict(<class 'list'>, {11: [0], 
#                                 14: [1], 
#                                 18: [1], 
#                                  6: [1, 1, 1, 1, 1, 1, 0, 1, 0, 0]})




    # ===========================================================================
    # Visit each Object class (PREDICTED object class) of ALL PHOTOS
    # Calculate Precision, Recall per CLASS (Note: this is not normal Precision, Recall : https://kharshit.github.io/blog/2019/09/20/evaluation-metrics-for-object-detection-and-segmentation)
    n_fg_class = max(n_pos.keys()) + 1                     # id of each logo (e.g. 0..31 of Logos-32plus dataset)
    prec = [None] * n_fg_class
    rec = [None] * n_fg_class
    
    # print("n_pos.keys()", n_pos.keys(), len(n_pos.keys()), max(n_pos.keys()))
    # print("n_fg_class", n_fg_class)
    
    for l in n_pos.keys():  #  visit id of each logo (e.g. 0..31 of Logos-32plus dataset)
        score_l = np.array(score[l])                       #  the corresponding confident PREDICTED bbox score (if exist) of this object class
        match_l = np.array(match[l], dtype=np.int8)        #  determination : bbox is True Positive (1 : if IoU predicted bbox w.r.t ground-truth bbox > 0.5) or False Positive (0 : if IoU predicted bbox w.r.t ground-truth bbox < 0.5)
        
        # if l == 1 : #  debug --------------------------
        #     print("score_l", len(score_l), score_l)
        #     print("match_l", len(match_l), match_l)

        order = score_l.argsort()[::-1]
        match_l = match_l[order]                           #  refined bbox matching : take ONLY ONE predicted bbox (with Highest Confident Score) with IoU > 0.5 in EACH OBJECT in an Image - other predicted bbox (with lower confident score) with IoU > 0.5 of the same object in the same image is set to False Positive
        
        # if l == 1 : #  debug --------------------------
        #     print("order", len(order), order)
        #     print("match_l", len(match_l), match_l)        

        tp = np.cumsum(match_l == 1)
        fp = np.cumsum(match_l == 0)

        # If an element of fp + tp is 0,
        # the corresponding element of prec[l] is nan.
        prec[l] = tp / (fp + tp)
        
        # if l == 1 : #  debug --------------------------
        #     print("tp", len(tp), tp)
        #     print("fp", len(fp), fp)      
        #     print("prec[l]", len(prec[l]), prec[l])
        
        # If n_pos[l] is 0, rec[l] is None.
        if n_pos[l] > 0:                                   #  number of ground-truth bbox in all photos of this logo in test set
            rec[l] = tp / n_pos[l]

        # if l == 1 : #  debug --------------------------
        #     print("n_pos[l]", n_pos[l])
        #     print("rec[l]", len(rec[l]), rec[l])
        
# prec 19   :  List of calculated precision of PREDICTED bbox in DESC order (of confident predicted bbox score) in EACH CLASS from ALL Photos
#    [None,                                                                           # 0
#     None,                                                                           # 1
#     None,                                                                           # 2
#     None,                                                                           # 3
#     None,                                                                           # 4
#     None,                                                                           # 5
#     array([1. , 1. , 1. , 1. , 1. , 1. , 0.85714286, 0.875 , 0.77777778, 0.7 ]),    # 6
#     None,                                                                           # 7
#     array([], dtype=float64),                                                       # 8
#     None,                                                                           # 9
#     None,                                                                           # 10
#     array([0.]),                                                                    # 11
#     None,                                                                           # 12
#     None,                                                                           # 13 
#     array([1.]),                                                                    # 14 
#     None,                                                                           # 15 
#     None,                                                                           # 16
#     array([], dtype=float64),                                                       # 17
#     array([1.])]                                                                    # 18
#     
#
# rec 19   :  List of calculated recall of PREDICTED bbox in EACH CLASS from ALL Photos
#    [None,                                                                                                           # 0
#     None,                                                                                                           # 1
#     None,                                                                                                           # 2
#     None,                                                                                                           # 3
#     None,                                                                                                           # 4
#     None,                                                                                                           # 5 
#     array([0.14285714, 0.28571429, 0.42857143, 0.57142857, 0.71428571, 0.85714286, 0.85714286, 1. , 1. , 1. ]),     # 6
#     None,                                                                                                           # 7
#     array([], dtype=float64),                                                                                       # 8
#     None,                                                                                                           # 9 
#     None,                                                                                                           # 10 
#     array([0.]),                                                                                                    # 11
#     None,                                                                                                           # 12 
#     None,                                                                                                           # 13 
#     array([1.]),                                                                                                    # 14
#     None,                                                                                                           # 15 
#     None,                                                                                                           # 16 
#     array([], dtype=float64),                                                                                       # 17
#     array([1.])]                                                                                                    # 18

    
    return prec, rec



def calc_detection_voc_ap(prec, rec, use_07_metric=False):
    """Calculate average precisions based on evaluation code of PASCAL VOC.

    This function calculates average precisions
    from given precisions and recalls.
    The code is based on the evaluation code used in PASCAL VOC Challenge.

    Args:
        prec (list of numpy.array): A list of arrays.
            :obj:`prec[l]` indicates precision for class :math:`l`.
            If :obj:`prec[l]` is :obj:`None`, this function returns
            :obj:`numpy.nan` for class :math:`l`.
        rec (list of numpy.array): A list of arrays.
            :obj:`rec[l]` indicates recall for class :math:`l`.
            If :obj:`rec[l]` is :obj:`None`, this function returns
            :obj:`numpy.nan` for class :math:`l`.
        use_07_metric (bool): Whether to use PASCAL VOC 2007 evaluation metric
            for calculating average precision. The default value is
            :obj:`False`.

    Returns:
        ~numpy.ndarray:
        This function returns an array of average precisions.
        The :math:`l`-th value corresponds to the average precision
        for class :math:`l`. If :obj:`prec[l]` or :obj:`rec[l]` is
        :obj:`None`, the corresponding value is set to :obj:`numpy.nan`.

    """

# prec 19   :  List of calculated precision of PREDICTED bbox in DESC order (of confident predicted bbox score) in EACH CLASS from ALL Photos
#    [None,                                                                           # 0
#     None,                                                                           # 1
#     None,                                                                           # 2
#     None,                                                                           # 3
#     None,                                                                           # 4
#     None,                                                                           # 5
#     array([1. , 1. , 1. , 1. , 1. , 1. , 0.85714286, 0.875 , 0.77777778, 0.7 ]),    # 6
#     None,                                                                           # 7
#     array([], dtype=float64),                                                       # 8
#     None,                                                                           # 9
#     None,                                                                           # 10
#     array([0.]),                                                                    # 11
#     None,                                                                           # 12
#     None,                                                                           # 13 
#     array([1.]),                                                                    # 14 
#     None,                                                                           # 15 
#     None,                                                                           # 16
#     array([], dtype=float64),                                                       # 17
#     array([1.])]                                                                    # 18
#     
#
# rec 19   :  List of calculated recall of PREDICTED bbox in EACH CLASS from ALL Photos
#    [None,                                                                                                           # 0
#     None,                                                                                                           # 1
#     None,                                                                                                           # 2
#     None,                                                                                                           # 3
#     None,                                                                                                           # 4
#     None,                                                                                                           # 5 
#     array([0.14285714, 0.28571429, 0.42857143, 0.57142857, 0.71428571, 0.85714286, 0.85714286, 1. , 1. , 1. ]),     # 6
#     None,                                                                                                           # 7
#     array([], dtype=float64),                                                                                       # 8
#     None,                                                                                                           # 9 
#     None,                                                                                                           # 10 
#     array([0.]),                                                                                                    # 11
#     None,                                                                                                           # 12 
#     None,                                                                                                           # 13 
#     array([1.]),                                                                                                    # 14
#     None,                                                                                                           # 15 
#     None,                                                                                                           # 16 
#     array([], dtype=float64),                                                                                       # 17
#     array([1.])]                                                                                                    # 18

    n_fg_class = len(prec)
    ap = np.empty(n_fg_class)
    
    # print("prec", len(prec), prec)
    # print("rec", len(rec), rec)
    # print("n_fg_class", n_fg_class)
    
    # ===================================================================
    # Calculate Average Precision (AP) per CLASS (not normal AP, this AP is calculated based on Precision-Recall Curve : https://kharshit.github.io/blog/2019/09/20/evaluation-metrics-for-object-detection-and-segmentation)
    for l in six.moves.range(n_fg_class):
        # if l == 1:  # debug --------------------
        #     print("rec[l]", rec[l])
        #     print("prec[l]", prec[l])
        
        if prec[l] is None or rec[l] is None:
            ap[l] = np.nan
            continue

        if use_07_metric:
            
            ap[l] = 0
            for t in np.arange(0., 1.1, 0.1):  # 11 x-point metric (on recall axis) to get 11 corresponding max Precision to the right side
                
                # if l == 1:  # debug --------------------
                #     print("t", t)
                    
                #     print("[item >= t for item in rec[l]]", [item >= t for item in rec[l]])
                #     print("np.sum(rec[l] >= t)", np.sum(rec[l] >= t))
                    
                #     print("np.nan_to_num(prec[l])[rec[l] >= t]", np.nan_to_num(prec[l])[rec[l] >= t])
                #     print("np.max(np.nan_to_num(prec[l])[rec[l] >= t])", np.max(np.nan_to_num(prec[l])[rec[l] >= t]))
                    
                if np.sum(rec[l] >= t) == 0: # at the end of x-axis recall (no more predicted bbox) OR when recall t > 1
                    p = 0   # for these two cases, if the table sorted TP/FP is right, this means that either there is no more predicted bbox OR the number of True Positive (matched bbox w.r.t ground-truth) bbox is equal to the total number of ground-truth bbox in this brand (from all photos of this brand in the test set) => precision p must be set to 0 (ignore the right side when we touch the end of recall axis 100%, enough predicted bbox w.r.t ground-truth, can't have more !!!)
                else:
                    p = np.max(np.nan_to_num(prec[l])[rec[l] >= t])  # maximum Precision to the right side of the considering point (it means max of all elements in this sub list from the considering point)
                ap[l] += p / 11   #  get average Precision at 11 x-point metric [0, 0.1, 0.2, .., 0.8, 0.9, 1]
                
                # if l == 1:  # debug --------------------
                #     print("p, p/11", p, p/11)
                #     print("ap[l]", ap[l])
                    
        else:
            # correct AP calculation
            # first append sentinel values at the end
            mpre = np.concatenate(([0], np.nan_to_num(prec[l]), [0]))
            mrec = np.concatenate(([0], rec[l], [1]))

            mpre = np.maximum.accumulate(mpre[::-1])[::-1]

            # to calculate area under PR curve, look for points
            # where X axis (recall) changes value
            i = np.where(mrec[1:] != mrec[:-1])[0]

            # and sum (\Delta recall) * prec
            ap[l] = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])

# ap (19,)   :  Average Precision of each class
#    [       nan       # 0      
#            nan       # 1        
#            nan       # 2        
#            nan       # 3        
#            nan       # 4        
#            nan       # 5
#     0.97727273       # 6        
#            nan       # 7 
#            0.        # 8               
#            nan       # 9        
#            nan       # 10 
#            0.        # 11
#            nan       # 12        
#            nan       # 13 
#            1.        # 14               
#            nan       # 15        
#            nan       # 16 
#            0.        # 17
#            1. ]      # 18
    
    return ap
