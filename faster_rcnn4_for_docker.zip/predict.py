import os
import io
from google.cloud import storage
import gcsfs
import json
import logging
from PIL import Image

# reproducibility
import torch
torch.manual_seed(2000)
import numpy as np
np.random.seed(2000)


from data.dataset import inverse_normalize, preprocess
from data.voc_dataset_logo_detection import VOC_BBOX_LABEL_NAMES

from utils import array_tool as at
from utils.config import opt

from model import FasterRCNNVGG16
from trainer import FasterRCNNTrainer



#
from flask import Flask, request
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)



        




    

class PredictObject(Resource):
    ''' PredictObject '''


    def get(self):
        ''' '''
        return {'hello': 'world'}        

    def post(self):
        ''' '''
        
        def preprocess_image(image_url, gcs_file_system):  # image_url : "12logos/test/JPEGImages/bigfernand_237614.jpg"
        
            logging.info('Preprocessing image ...')
            
            # read blob object
            with gcs_file_system.open('gs://' + opt.gcs_bucket_name + '/'  + image_url) as g:
                img = Image.open(g)
                img = img.convert('RGB')  # img <PIL.Image.Image image mode=RGB size=500x375 at 0x7F7D16693690>
                img = np.asarray(img, dtype=np.float32) # convert from PIL Image object type into unsigned integer Numpy numbers H x W x 3 colors channel with each 8 bit [0..255] color pixel
                img = img.transpose((2, 0, 1))     
                img = preprocess(img)
                ori_img_ = inverse_normalize(img)  #  for VISUALIZATION : always need to get back all raw pixel values (before normalizing) [channel, width, height] of SCALED image (shorter side to 600 pixel)
        
            return ori_img_           
  
        

        
        
        
        # Set CORS headers for the preflight request
        if request.method == 'OPTIONS':
            # Allows POST requests from any origin with the Content-Type
            # header and caches preflight response for an 3600s
            headers = {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Max-Age': '3600'
            }
            return ('', 204, headers)

        # Disallow non-POSTs
        if request.method != 'POST':
            return ('Not found', 404)


        # Set CORS headers for the main request 
        headers = {'Access-Control-Allow-Origin': '*'}


        # Get request json input ------------------
        request_json = request.get_json(silent=True)
        
        
        
        

        
        # authenticate to Google Cloud Storage --------------------------
        json_auth_path = 'mylibot_service_account_auth.json'
        storage_client = storage.Client.from_service_account_json(json_auth_path)
        gcs_bucket = storage_client.bucket(opt.gcs_bucket_name)    
        
        #
        f = open(json_auth_path,)
        token_auth = json.load(f)
        gcs_file_system = gcsfs.GCSFileSystem(project=opt.gcs_project_name, token=token_auth)
        
        
        
        # Initialize model ------------------------
        faster_rcnn = FasterRCNNVGG16(n_fg_class = opt.n_class)  # n_fg_class : foreground class = only object class
        trainer = FasterRCNNTrainer(faster_rcnn).cuda()
        
        return {'class' : opt.n_class, 'link' : request['parameters']}
    
        # load pretrained model -------------------
        blob = gcs_bucket.blob(request['parameters'])
        # download it
        blob.download_to_filename("pretrained_model")        
        # load pretrained model
        trainer.load("pretrained_model")
        
        
        
        # Visit each image, preprocess & run prediction
        result_json = {}
        result_json['predictions'] = []
        
        for img_dict in request_json['instances']:   # img_dict : {"id": 1, "image_url" : "12logos/test/JPEGImages/bigfernand_237614.jpg"}

            # Preprocess image ------------------
            ori_img_ = preprocess_image(img_dict['image_url'], gcs_file_system)

            # Run prediction ------------------
            _bboxes, _labels, _scores = trainer.faster_rcnn.predict([ori_img_], visualize=True)

            _bboxes, _labels, _scores = at.tonumpy(_bboxes[0]), \
                                        at.tonumpy(_labels[0]).reshape(-1), \
                                        at.tonumpy(_scores[0])  
            
            #
            img_dict['bbox'] = _bboxes
            img_dict['label'] = _labels
            img_dict['score'] = _scores
            #
            result_json['predictions'].append(img_dict)


        return result_json








###

api.add_resource(PredictObject, '/predict')

if __name__ == '__main__':
    app.run(host='0.0.0.0')