from __future__ import  absolute_import
import os
from collections import namedtuple
import time
from torch.nn import functional as F
from torch import nn
import torch as t
from torchnet.meter import ConfusionMeter, AverageValueMeter

from utils import array_tool as at
from utils.vis_tool import Visualizer
from utils.config import opt

from model.utils.creator_tool import AnchorTargetCreator, ProposalTargetCreator


LossTuple = namedtuple('LossTuple',
                       ['rpn_loc_loss',
                        'rpn_cls_loss',
                        'roi_loc_loss',
                        'roi_cls_loss',
                        'total_loss'
                        ])


class FasterRCNNTrainer(nn.Module):
    """wrapper for conveniently training. return losses

    The losses include:

    * :obj:`rpn_loc_loss`: The localization loss for \
        Region Proposal Network (RPN).
    * :obj:`rpn_cls_loss`: The classification loss for RPN.
    * :obj:`roi_loc_loss`: The localization loss for the head module.
    * :obj:`roi_cls_loss`: The classification loss for the head module.
    * :obj:`total_loss`: The sum of 4 loss above.

    Args:
        faster_rcnn (model.FasterRCNN):
            A Faster R-CNN model that is going to be trained.
    """

    def __init__(self, faster_rcnn):
        super(FasterRCNNTrainer, self).__init__()

        self.faster_rcnn = faster_rcnn
        self.rpn_sigma = opt.rpn_sigma
        self.roi_sigma = opt.roi_sigma

        # target creator create gt_bbox gt_label etc as training targets. 
        self.anchor_target_creator = AnchorTargetCreator()       #
        self.proposal_target_creator = ProposalTargetCreator()   #

        self.loc_normalize_mean = faster_rcnn.loc_normalize_mean
        self.loc_normalize_std = faster_rcnn.loc_normalize_std

        self.optimizer = self.faster_rcnn.get_optimizer()
        # visdom wrapper
        self.vis = Visualizer(env=opt.env)

        # indicators for training status
        self.rpn_cm = ConfusionMeter(2)  #
        self.roi_cm = ConfusionMeter(opt.n_class + 1) # nunber of object class + background class.       The ConfusionMeter constructs a confusion matrix for a multi-class classification problems. It does not support multi-label, multi-class problems: for such problems, please use MultiLabelConfusionMeter.
        self.meters = {k: AverageValueMeter() for k in LossTuple._fields}  # average loss

    def forward(self, imgs, bboxes, labels, scale):
        """Forward Faster R-CNN and calculate losses.
        
        Process details:
            1. Features Extraction from the image.
            2. Creating anchor targets.
            3. Locations and objectness score prediction from the RPN network.
            4. Taking the top N locations and their objectness scores aka proposal layer
            5. Passing these top N locations through Fast R-CNN network and generating locations and cls predictions for each location is suggested in 4.
            6. Generating proposal targets for each location suggested in 4
            7. Using 2 and 3 to calculate rpn_cls_loss and rpn_reg_loss.
            8. Using 5 and 6 to calculate roi_cls_loss and roi_reg_loss.        

        Here are notations used.

        * :math:`N` is the batch size.
        * :math:`R` is the number of bounding boxes per image.

        Currently, only :math:`N=1` is supported.

        Args:
            imgs (~torch.autograd.Variable): A variable with a batch of images.
            bboxes (~torch.autograd.Variable): A batch of bounding boxes.
                Its shape is :math:`(N, R, 4)`.
            labels (~torch.autograd..Variable): A batch of labels.
                Its shape is :math:`(N, R)`. The background is excluded from
                the definition, which means that the range of the value
                is :math:`[0, L - 1]`. :math:`L` is the number of foreground
                classes.
            scale (float): Amount of scaling applied to the raw image during preprocessing (scale the shorter side among (width, height) to 600 pixels)

        Returns:
            namedtuple of 5 losses
        """
        n = bboxes.shape[0]
        if n != 1:
            raise ValueError('Currently only batch size 1 is supported.')

        # At training time : besides scaled (shorter side to 600 : ratio in *scale* variable), image can be also flipped + flip & scale the corresponding ground-truth bounding-box
        _, _, H, W = imgs.shape  # batch_size, 3 color channels, height, width   : e.g.: torch.Size([1, 3, 600, 800])
        img_size = (H, W)        # SCALED image size 

        # Step 1: CNN features extraction , the subsampling ratio from rescaled (+ flipped) image to output of VGG16 is ~16
        features = self.faster_rcnn.extractor(imgs)                            # 1. call the body VGG net in faster_rcnn_vgg16.py   , e.g. : torch.Size([1, 512, 37, 50])

#        features torch.Size([1, 512, 37, 50])

        # Step 2: Region Proposal Network =======================================================================================================================
        # And compute 4 coordinates DIFFERENCE & objectness class (binary class) 
        # of each of 128 predicted positive and negative sample bbox w.r.t GROUND-TRUTH =========================================================================

        rpn_locs, rpn_scores, rois, roi_indices, anchor = \
            self.faster_rcnn.rpn(features, img_size, scale)                    # 2, 3, 4, 5. call the forward RPN in region_proposal_network.py

#       Use image + CNN to PREDICT 4 INCREMENTAL (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) coordinates + objectness class score for each FIXED anchor BOXES ---------------------------------------------------------------------------
#       There are 37 (output Height of VGG16) * 50 (output Width of VGG16) * 9 (anchors BOXES at each feature map point) = 16650 anchor BOXES in total
#
#        rpn_locs  torch.Size([1, 16650, 4])                                   # Use image + CNN to predict 4 INCREMENTAL (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) coordinates of each FIXED anchor BOXES
#           tensor([[[ 1.0164e-02, -8.5225e-02, -1.6837e-03, -8.4621e-03],
#                 [-1.1096e-02,  4.1846e-02,  2.9004e-02, -2.2258e-02],
#                 [-1.2302e-05,  1.5893e-02,  9.9560e-04, -2.6399e-02],
#                 ...,
#                 [-1.1011e-02,  4.7739e-03, -8.5138e-03, -9.6025e-03],
#                 [-2.1682e-02,  7.7298e-03,  2.0266e-03,  9.3305e-03],
#                 [-3.1961e-04,  8.2755e-03, -2.9834e-03, -3.8120e-03]]],
#               device='cuda:0', grad_fn=<ViewBackward>)
#
#        rpn_scores  torch.Size([1, 16650, 2])                                 # Use image + CNN to predict 2 classes objectness (1: object, 0: not object) of each FIXED anchor BOXES
#           tensor([[[ 0.0311,  0.0244],
#                 [-0.0643,  0.0984],
#                 [-0.0117, -0.0406],
#                 ...,
#                 [-0.0293, -0.0084],
#                 [-0.0123, -0.0070],
#                 [-0.0153,  0.0179]]], device='cuda:0', grad_fn=<ViewBackward>)
#
#
#        REGION PROPOSAL BBOX via CNN & NMS (instead of Selective Search) --------------------------------------------------------------------
#
#        rois  (1724, 4)                                                       # MAX 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI created by FIXED anchor bbox + INCREMENTAL dy, dx, dheight, dwidth PREDICTED by CNN) with HIGHEST PREDICTED objectness scores & Non-redundant via NMS  x  4 corresponding coordinates  . NOTE: maximum is 2000, due to randomness, it can be less (1940 for ex)
#        [[  0.        42.739    528.5074   376.7633  ]
#         [283.63934    0.       420.3711   103.96875 ]
#         [ 56.598816   0.       405.03427  668.30994 ]
#         ...
#         [446.4488   353.54617  600.       440.49185 ]
#         [287.0526   375.04297  378.7989   551.0982  ]
#         [282.63702  578.0259   410.42755  710.7428  ]]
#
#        roi_indices  (1724,) [0 0 0 ... 0 0 0]                                # index of image in batch (always the first and unique image - index 0 if batch_size = 1)
#
#
#        ENUMERATE the (fixed) list of 37 * 50 * 9 anchor BOXES coordinates -------------------------------------------------------------------
#
#        anchor  (16650, 4)                                                    # to compute anchor target creator (for RPN localisation loss)                                                 
#         [[ -37.254833  -82.50967    53.254833   98.50967 ]
#         [ -82.50967  -173.01933    98.50967   189.01933 ]
#         [-173.01933  -354.03867   189.01933   370.03867 ]
#         ...
#         [ 493.49033   746.7452    674.50964   837.2548  ]
#         [ 402.98065   701.49036   765.01935   882.50964 ]
#         [ 221.96133   610.98065   946.0387    973.01935 ]]
        
        

        # Since batch size is one, convert variables to singular form
        bbox = bboxes[0]   # ground-truth bounding-box [number_bbox, 4 coordinates]
        label = labels[0]  # [number of ground-truth classes which correspond to number_bbox]
        rpn_score = rpn_scores[0]  # [16650, 2]
        rpn_loc = rpn_locs[0]      # [16650, 4]
        roi = rois                 # [2000, 4]


#        ground-truth (rescaled) bbox  [3, 4]
#        tensor([[336.0000, 283.2000, 540.8000, 380.8000],
#                [420.8000, 396.8000, 593.6000, 537.6000],
#                [308.8000, 329.6000, 476.8000, 416.0000]], device='cuda:0')
#        
#        ground-truth label [3]
#        tensor([8, 8, 8], device='cuda:0', dtype=torch.int32)



        # Sample RoIs and forward -----------------------------------------------------------------------------------------
        # Note: At test time, we don't have ground-truth bbox and label -> At training time, these sample_roi serve as ATTENTION !

        # it's fine to break the computation graph of rois, 
        # consider them as constant input
        sample_roi, gt_roi_loc, gt_roi_label = self.proposal_target_creator(   # 6a.
            roi,                     # [1724, 4]  : Max 2000 bounding-boxes Regions Proposal (Region of Interest ROI) that matches reality's conditions via NMS & HIGHEST PREDICTED objectness scores  x  4 corresponding coordinates  . NOTE: maximum is 2000, due to randomness, it can be less (1940 for ex)
            at.tonumpy(bbox),        # [number_bbox, 4 coordinates]  : ground-truth (rescaled) bounding-box 
            at.tonumpy(label),       # [number of ground-truth classes which correspond to number_bbox]  : ex 3 object: tensor([8, 8, 8], device='cuda:0', dtype=torch.int32)
            self.loc_normalize_mean, # (0., 0., 0., 0.)        #  where does this number come from ?
            self.loc_normalize_std)  # (0.1, 0.1, 0.2, 0.2)
        # NOTE it's all zero because now it only supports for batch=1 now
        sample_roi_index = t.zeros(len(sample_roi))

#        sample_roi  (128, 4)                                                  # [128, 4] 4 coordinates of 128 POSITIVE and NEGATIVE BBOX SAMPLES from Max 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI) that has the HIGHEST OVERLAPPING REGION > (or <=) 0.5 w.r.t GROUND-TRUTH BBOX
#        [[383.26605   377.29407   600.        559.4009   ]
#         [435.51804   455.8985    600.        540.8511   ]
#         [407.90097   321.36078   600.        561.5512   ]
#         [321.29504   308.42358   453.60413   433.7323   ]
#         [339.50854   326.33182   470.59094   450.54117  ]
#         [416.9333    372.28577   524.9664    529.8954   ]
#         [411.02887   400.4822    600.        588.9612   ]
#         [308.80002   329.6       476.80002   416.       ]
#         [420.80002   396.8       593.60004   537.6      ]
#         [336.89325   255.24194   472.21466   378.19446  ]
#         [336.        283.2       540.8       380.8      ]
#         ...
#        
#        gt_roi_loc (128, 4)                                                   # normalized DIFFERENCE dcenter_y, dcenter_x, dheight, dwidth between ground-truth and predicted sample bbox
#        [[ 7.18253255e-01 -6.30119964e-02 -1.13267779e+00 -1.28626525e+00]
#         [-6.41956151e-01 -3.66967130e+00  2.46670112e-01  2.52623582e+00]
#         [ 1.69158146e-01  1.07181573e+00 -5.29380262e-01 -2.67045856e+00]
#         [ 4.04388964e-01  1.37424275e-01  1.19411612e+00 -1.85896420e+00]
#         [-9.34505761e-01 -1.25888300e+00  1.24068916e+00 -1.81490433e+00]
#         [ 3.35547066e+00  1.02210808e+00  2.34848738e+00 -5.63904166e-01]
#         [ 8.91976133e-02 -1.46019995e+00 -4.47296411e-01 -1.45823050e+00]
#         ...
#         [ 1.74070892e+01 -8.66320324e+00  2.28472009e-01 -3.08015609e+00]    # negative samples (predicted bbox are far from ground-truth bbox) have large difference ...
#         [ 3.28212509e+01  1.13312740e+01  4.22831488e+00 -3.05706358e+00]
#         [ 1.18478956e+01 -2.91177607e+00  2.37985134e+00 -3.86248040e+00]
#         [ 4.67760038e+00 -3.27569885e+01  6.76378071e-01  5.99376082e-01]
#         [ 2.45431709e+00  1.67006481e+00 -3.73248911e+00 -1.21479452e+00]]
#        
#        gt_roi_label (128,)                                                   # Labels of 128 sample predicted bbox (~1/4 highest IoU positive, ~3/4 negative predicted bbox that MATCH ANY ground-truth bbox - LABELS OF NEGATIVE PREDICTED BBOX are 0)   
#        [9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#         0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#         0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#         0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]
#         
#        sample_roi_index  torch.Size([128])                                   # id of image in batch_size, here batch_size = 1 => 128 bbox all have id = 0
#        tensor([0., 0., 0., 0., 0., 0., 0.,.....






        # Apply 128 positive and negative predicted samples ROI bbox again on CNN features & perform ROI Pooling to get FIXED SIZE for FEEDFORWARD NEURAL NETWORK ============================
        # Then, compute 21 classes (20 objects + background) score & 4 coordinates of each object class (4 * 21 = 84) =========================================

        # Step 3: Run ROI Pooling & Last VGG classifier on (Sample) ROI (by Proposal_target_creator)  -------------------------------------------------------
        roi_cls_loc, roi_score = self.faster_rcnn.head(                        # 6b. 
            features,           # [1, 512, 37, 50]  features obtained by CNN (VGG16)
            sample_roi,         # [128, 4] 4 coordinates of 128 POSITIVE and NEGATIVE BBOX SAMPLES from Max 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI) that has the HIGHEST OVERLAPPING REGION > (or <=) 0.5 w.r.t GROUND-TRUTH BBOX
            sample_roi_index)   # torch.Size([128]) all zeros

#        roi_score torch.Size([128, 21])                                       # 128 predicted positive and negative bbox, for each bbox: we predict 21 object scores (20 object classes + background) OBJECT ROI sample bbox to ground-truth bbox 
#        tensor([[ 0.3237, -0.1683, -0.2037,  ...,  0.1305,  0.5009, -0.4061],
#                [ 0.0662, -0.0491, -0.0649,  ...,  0.1462,  0.3161, -0.2695],
#                [ 0.2649, -0.1429, -0.0971,  ...,  0.0496,  0.3100, -0.4186],
#                ...,
#                [-0.1920,  0.3956, -0.2486,  ..., -0.1070,  0.3637,  0.1624],
#                [ 0.0360,  0.0459,  0.0788,  ...,  0.0969, -0.2308, -0.2668],
#                [ 0.3036, -0.0374, -0.1368,  ...,  0.2855,  0.5802, -0.2827]],
#               device='cuda:0', grad_fn=<AddmmBackward>)
#
#        Note: we predict 4 coordinates of each of 21 object class separately (not unique 4 coordinates bbox like in RPN) because here, we're treating the multi-object prediction (not binary prediction object or not problem like in RPN !!!!)
#        
#        roi_cls_loc torch.Size([128, 84])                                     # 128 predicted positive and negative bbox, for each bbox: we predict 4 INCREMENTAL coordinates of each of 21 classes (20 object classes + background) OBJECT ROI sample bbox to ground-truth bbox 
#        tensor([[ 2.3361e-02,  5.1721e-02, -9.4898e-03,  ..., -2.6796e-02, 2.7425e-03, -7.4335e-03],
#                [ 8.4832e-03,  4.4859e-02,  1.1071e-02,  ..., -2.4948e-02, 2.3907e-02, -6.5800e-03],
#                [ 1.4902e-02,  3.7563e-02, -8.6419e-03,  ..., -1.1015e-02,-8.2988e-05, -1.4083e-02],
#                ...,
#                [-1.7331e-02,  1.5235e-03, -3.1996e-02,  ...,  4.0901e-03, -1.6853e-02,  6.1920e-03],
#                [ 3.5230e-02,  9.9208e-03,  2.5442e-03,  ..., -3.2313e-02, 3.1963e-02, -2.6983e-02],
#                [ 3.9199e-03,  7.0513e-02, -4.1272e-02,  ..., -6.2037e-03, 2.6381e-02, -4.4130e-03]], device='cuda:0', grad_fn=<AddmmBackward>)

        
        
        
        
        
        
        # Compute IoU & Sample 256 positive and negative FIXED anchor bbox w.r.t ground-truth bbox => this serves for the calculation of RPN LOCALISATION LOSS (match 4 coordinates of Bounding-box regressor)
        gt_rpn_loc, gt_rpn_label = self.anchor_target_creator(                 # 6c --------------------------------------------------------
            at.tonumpy(bbox),   # [3, 4] ground-truth 3 bbox for ex. 
            anchor,             # [16650, 4] FIXED generated list of bbox coordinates (= 37 * 50 * 9)
            img_size)           # [600, 800] scaled raw image
        gt_rpn_label = at.totensor(gt_rpn_label).long()
        gt_rpn_loc = at.totensor(gt_rpn_loc)

#        gt_rpn_loc  torch.Size([16650, 4])                                    # Fill 5834 inside FIXED anchor bbox to 16650 bbox with the DIFFERENCE dy, dx, dheight, dwidth to ground-truth coordinates
#        tensor([[0., 0., 0., 0.],                        
#                [0., 0., 0., 0.],
#                [0., 0., 0., 0.],
#                ...,
#                [0., 0., 0., 0.],
#                [0., 0., 0., 0.],
#                [0., 0., 0., 0.]], device='cuda:0')
#                
#        gt_rpn_label  torch.Size([16650])                                     # Fill 5834 inside FIXED anchor bbox to 16650 bbox with 256 positive and negative sampling fixed anchor bbox (247 negative label 0, 9 positive label 1, the rest are igore label -1)
#        tensor([-1, -1, -1,  ..., -1, -1, -1], device='cuda:0')    
        
        
        
        
        
        
        # ------------------ RPN losses -------------------#
        # First, try to approximate good distance from FIXED anchor bbox to GROUND-TRUTH bbox (rpn_loc estimated by CNN) & refine object v.s background (Attention)  -> Found the right FIXED anchor bbox
        
        rpn_loc_loss = _fast_rcnn_loc_loss(                                                    # 7a. RPN bounding-box regression loss (4 coordinates localisation)
            rpn_loc,             # [16650, 4]  :  Use image + CNN to predict 4 INCREMENTAL (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) coordinates of each anchor BOXES
            gt_rpn_loc,          # [16650, 4]  :  Fill 5834 inside FIXED anchor bbox to 16650 bbox with DIFFERENCE dy, dx, dheight, dwidth to ground-truth coordinates
            gt_rpn_label.data,   # [16650]     :  Fill 5834 inside FIXED anchor bbox to 16650 bbox with 256 positive and negative sampling fixed anchor bbox (247 negative label 0, 9 positive label 1, the rest are igore label -1)
            self.rpn_sigma)      # 3.  : sigma for l1_smooth_loss

#        rpn_loc_loss  
#        tensor(0.0078, device='cuda:0', grad_fn=<DivBackward0>)
        
        # NOTE: default value of ignore_index is -100 ...                                      # 7b. RPN object classification loss    
        rpn_cls_loss = F.cross_entropy(rpn_score,              # [16650, 2] : Use image + CNN to predict 2 classes objectness (1: object, 0: not object) of each anchor BOXES
                                       gt_rpn_label.cuda(),    # [16650]    : Fill 5834 inside FIXED anchor bbox to 16650 bbox with 256 positive and negative sampling fixed anchor bbox (247 negative label 0, 9 positive label 1, the rest are igore label -1)
                                       ignore_index=-1)        # ignore_index of gt_rpn_label

#        rpn_cls_loss  tensor(0.6856, device='cuda:0', grad_fn=<NllLossBackward>)
        
        _gt_rpn_label = gt_rpn_label[gt_rpn_label > -1]        # only keep 256 positive and negative sample fixed anchor bbox w.r.t ground-truth bbox
        
#        _gt_rpn_label  torch.Size([256])                 
#        tensor([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#                ...
#                0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
#                0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
#                0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
#                0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0], device='cuda:0')
        
        _rpn_score = at.tonumpy(rpn_score)[at.tonumpy(gt_rpn_label) > -1]
        
#        _rpn_score  (256, 2)                                  # corresponding rpn_score of 256 positive and negative sample fixed anchor bbox w.r.t ground-truth bbox
#        [[ 3.17773893e-02 -2.47774292e-02]
#         [ 6.64890334e-02 -4.16323207e-02]
#         [ 6.99627325e-02 -8.20792913e-02]
#         [ 6.83548748e-02 -1.00666054e-01]
#         [ 6.30739629e-02  1.73325967e-02]
#         [ 3.48951481e-02  2.19747564e-03]
#         ...
        
        # add stat number to Confusion Matrix 2x2 classes
        self.rpn_cm.add(at.totensor(_rpn_score, False), _gt_rpn_label.data.long())     #  at.totensor(x, cuda=False)




        # ------------------ ROI losses (fast rcnn loss) -------------------#
        # After obtained good distance from FIXED anchor bbox to GROUND-TRUTH bbox (rpn_loc estimated by CNN -> Found the right FIXED anchor bbox), try to approximate good distance from 2000 remaining bbox after NMS -> 128 PREDICTED SAMPLE bbox to GROUND-TRUTH bbox  

        n_sample = roi_cls_loc.shape[0]                               # 128
        roi_cls_loc = roi_cls_loc.view(n_sample, -1, 4)               # roi_cls_loc: reshaped from [128, 84] -> [128, 21, 4]  : 128 predicted positive and negative bbox, for each bbox: we predict 4 INCREMENTAL coordinates of each of 21 classes (20 object classes + background) OBJECT ROI sample bbox to ground-truth bbox 
        roi_loc = roi_cls_loc[t.arange(0, n_sample).long().cuda(), \
                              at.totensor(gt_roi_label).long()]       # [[0,1,2,...,127], [9,9,9,..,0,0,0] of size 128]
        
#        roi_loc  torch.Size([128, 4])                                # the corresponding 4 PREDICTED coordinates of ground-truth OBJECT ROI bbox 
#        tensor([[-2.1290e-02,  1.1263e-02, -6.1761e-03, -8.9484e-04],
#                [-1.9060e-02,  2.3638e-02,  4.7915e-03, -7.4005e-04],
#                [-3.5782e-02,  4.7630e-02, -1.0751e-02, -2.4448e-03],
#                [-1.9436e-02,  6.4710e-03,  2.3618e-02, -1.4385e-02],
#                ...        
        
        gt_roi_label = at.totensor(gt_roi_label).long()
        gt_roi_loc = at.totensor(gt_roi_loc)             

        roi_loc_loss = _fast_rcnn_loc_loss(                                                    # 8a. ROI bounding-box regression loss
            roi_loc.contiguous(),  # [128, 4]  : the corresponding 4 PREDICTED INCREMENTAL coordinates of OBJECT ROI sample bbox to ground-truth bbox 
            gt_roi_loc,            # [128, 4]  : normalized DIFFERENCE dcenter_y, dcenter_x, dheight, dwidth between ground-truth and PREDICTED sample bbox
            gt_roi_label.data,     # [128]     : 128 sample PREDICTED bbox labels (~1/4 highest IoU positive, ~3/4 negative predicted bbox that MATCH ANY ground-truth bbox - LABELS OF NEGATIVE PREDICTED BBOX are 0) 
            self.roi_sigma)        # 1.        : sigma for l1_smooth_loss

#        roi_loc_loss  tensor(0.4065, device='cuda:0', grad_fn=<DivBackward0>)            
            
        roi_cls_loss = nn.CrossEntropyLoss()(roi_score,               # [128, 21] : 128 PREDICTED positive and negative bbox, for each bbox: we predict 21 object scores (20 object classes + background)
                                             gt_roi_label.cuda()      # [128]     : 128 sample PREDICTED bbox labels (~1/4 highest IoU positive, ~3/4 negative predicted bbox that MATCH ANY ground-truth bbox - LABELS OF NEGATIVE PREDICTED BBOX are 0)
                                             )                                                 # 8b. ROI object classification loss       , roi_score: [128, 21], gt_roi_label : [128] 

#        roi_cls_loss  tensor(3.1059, device='cuda:0', grad_fn=<NllLossBackward>)
        
        # add stat number to Confusion Matrix 21x21 classes
        # print("roi_score", roi_score.size(), roi_score)
        # print("gt_roi_label", gt_roi_label.size(), gt_roi_label)
        # print("self.roi_cm", self.roi_cm)
        self.roi_cm.add(at.totensor(roi_score, False), gt_roi_label.data.long())     #  at.totensor(x, cuda=False)




        # -------------------------- Total Loss ----------------------------#

        losses = [rpn_loc_loss, rpn_cls_loss, roi_loc_loss, roi_cls_loss]

        losses = losses + [sum(losses)]
        
#        losses 
#        [tensor(0.0078, device='cuda:0', grad_fn=<DivBackward0>),             # 4 coordinates localisation avg loss only on positive fixed anchor bbox (9 e.g.) -> very small value 
#         tensor(0.6856, device='cuda:0', grad_fn=<NllLossBackward>),          # only 2 classes : object or not
#         tensor(0.4065, device='cuda:0', grad_fn=<DivBackward0>),             # 
#         tensor(3.1059, device='cuda:0', grad_fn=<NllLossBackward>),          # 20 object + background class  -> big value
#         tensor(4.2059, device='cuda:0', grad_fn=<AddBackward0>)]

        return LossTuple(*losses)


    def train_step(self, imgs, bboxes, labels, scale):
        ''' wrapper of common zero_grad, backward, optimizer.step, update_log_meters'''
        
        self.optimizer.zero_grad()
        losses = self.forward(imgs, bboxes, labels, scale)   # train_step points immediately to forward
        losses.total_loss.backward()
        self.optimizer.step()
        self.update_meters(losses)
        return losses



    def save(self, save_optimizer=False, save_path=None, **kwargs):
        """serialize models include optimizer and other info
        return path where the model-file is stored.

        Args:
            save_optimizer (bool): whether save optimizer.state_dict().
            save_path (string): where to save model, if it's None, save_path
                is generate using time str and info from kwargs.
        
        Returns:
            save_path(str): the path to save models.
        """
        save_dict = dict()

        save_dict['model'] = self.faster_rcnn.state_dict()
        save_dict['config'] = opt._state_dict()
        save_dict['other_info'] = kwargs
        save_dict['vis_info'] = self.vis.state_dict()

        if save_optimizer:
            save_dict['optimizer'] = self.optimizer.state_dict()

        if save_path is None:
            timestr = time.strftime('%m%d%H%M')
            if not os.path.exists('checkpoints'):
                os.mkdir('checkpoints')
            save_path = 'checkpoints/fasterrcnn_%s' % timestr
            for k_, v_ in kwargs.items():
                save_path += '_%s' % v_

        # save_dir = os.path.dirname(save_path)
        # if not os.path.exists(save_dir):
        #     os.makedirs(save_dir)

        t.save(save_dict, save_path)
        self.vis.save([self.vis.env])
        return save_path

    def load(self, path, load_optimizer=True, parse_opt=False, ):
        state_dict = t.load(path)
        if 'model' in state_dict:
            self.faster_rcnn.load_state_dict(state_dict['model'])
        else:  # legacy way, for backward compatibility
            self.faster_rcnn.load_state_dict(state_dict)
            return self
        if parse_opt:
            opt._parse(state_dict['config'])
        if 'optimizer' in state_dict and load_optimizer:
            self.optimizer.load_state_dict(state_dict['optimizer'])
        return self

    def update_meters(self, losses):
        loss_d = {k: at.scalar(v) for k, v in losses._asdict().items()}
        for key, meter in self.meters.items():
            meter.add(loss_d[key])

    def reset_meters(self):
        for key, meter in self.meters.items():
            meter.reset()
        self.roi_cm.reset() #
        self.rpn_cm.reset() #

    def get_meter_data(self):
        return {k: v.value()[0] for k, v in self.meters.items()}


def _smooth_l1_loss(x, t, in_weight, sigma):  # Theory : |x|<1 : take L2 loss, robust calculation (differentiable at x=0), |x|>1: take L1 loss, less insensitive to outlier
    # Note : apply L2 and L1 loss only on (a small number 9 e.g.) POSITIVE anchor bbox w.r.t ground-truth      
    # For background RoIs there is no notion of a ground-truth bounding box and hence Loss_loc is ignored   (page 3 of https://arxiv.org/pdf/1504.08083.pdf)
    # However, in the end, we still 'normalize' (scale / divide) by 256 (number of positive and negative bbox)
    # (This is applied only for 4 coordinates localisation loss. For binary or 21 classification loss, we still compute all positive or 20 object and negative background class)
    
    sigma2 = sigma ** 2                               # sigma2 = 9 if sigma = 3 : determine the range of L2 loss and L1 loss on the absolute difference value (Note : for RPN loss, we penalize more as RPN loss is smaller -> apply only L2 loss on smaller values than 1)
    diff = in_weight * (x - t)                        # in_weight (there's only 9 positive fixed anchor bbox w.r.t ground-truth !!!) * (Difference PREDICTED by CNN - Difference between FIXED anchor bbox and ground-truth bbox)
    
#    diff torch.Size([16650, 4]) 
#    tensor([[0., 0., 0., -0.],
#            [-0., -0., 0., -0.],
#            [-0., -0., -0., 0.],
#            ...,
#            [0., 0., 0., -0.],
#            [-0., 0., 0., 0.],
#            [0., 0., -0., 0.]], device='cuda:0', grad_fn=<MulBackward0>)
    
    abs_diff = diff.abs()                             

#    abs_diff torch.Size([16650, 4]) 
#    tensor([[0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            ...,
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.]], device='cuda:0', grad_fn=<AbsBackward>) 

#    abs_diff.data[abs_diff.data > 0] 
#    tensor([4.2218e-02, 3.0124e-02, 1.1158e-01, 1.1003e-02, 
#            2.7270e-02, 4.3806e-02, 1.2581e-01, 2.1411e-04, 
#            1.5779e-01, 6.7278e-02, 9.0623e-02, 8.0649e-03,
#            2.2024e-02, 8.0829e-03, 1.3096e-01, 1.0212e-01, 
#            1.2022e-01, 1.7978e-02, 1.6845e-01, 9.9847e-02, 
#            2.0039e-01, 2.2914e-02, 1.8491e-01, 1.0654e-01,
#            1.1489e-01, 1.2462e-01, 1.6797e-01, 1.7118e-01, 
#            1.0807e-02, 5.6329e-02, 2.2422e-01, 1.4044e-01, 
#            1.5939e-01, 6.4360e-02, 2.5619e-01, 1.2416e-01],
#           device='cuda:0')
    
    # Determine the range of L2 loss and L1 loss on the absolute difference value (Note : for RPN loss, we penalize more as RPN loss is smaller -> apply only L2 loss on smaller values than 1)
    flag = (abs_diff.data < (1. / sigma2)).float()    # flag = 1 if absolute difference subtraction < 1/9 = 0.111  :  L2 loss ,  flag = 0 : absolute difference > 1/9 = 0.11 -> Small difference values  :  L1 loss

#    abs_diff.data[abs_diff.data >= (1. / sigma2)]    # this is applied individualy on each DY, DX, DHEIGHT, DWIDTH , not on each fixed anchor bbox
#    tensor([0.1116, 0.1258, 0.1578, 0.1310, 
#            0.1202, 0.1685, 0.2004, 0.1849, 
#            0.1149, 0.1246, 0.1680, 0.1712, 
#            0.2242, 0.1404, 0.1594, 0.2562, 0.1242],
#           device='cuda:0')
#    
#    flag torch.Size([16650, 4])                      # mostly flag 1, there's SMALL difference between predicted and fixed anchor bbox and ground-truth bbox
#    tensor([[1., 1., 1., 1.],
#            [1., 1., 1., 1.],
#            [1., 1., 1., 1.],
#            ...,
#            [1., 1., 1., 1.],
#            [1., 1., 1., 1.],
#            [1., 1., 1., 1.]], device='cuda:0')
    
    y = flag * (sigma2 / 2.) * (diff ** 2)    +    (1 - flag) * (abs_diff - 0.5 / sigma2)   #  Combine [ L2 Loss (SMALL Difference values determined by 1/sigma2) * sigma2 / 2 ]   +    [ L1 Loss (BIG Difference values determined by 1/sigma2) - 1 / (sigma2 * 2) ]  on difference values

#    (sigma2 / 2.) * (diff ** 2) torch.Size([16650, 4]) 
#    tensor([[0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            ...,
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.]], device='cuda:0', grad_fn=<MulBackward0>)
#            
#    (abs_diff - 0.5 / sigma2) torch.Size([16650, 4]) 
#    tensor([[-0.0556, -0.0556, -0.0556, -0.0556],
#            [-0.0556, -0.0556, -0.0556, -0.0556],
#            [-0.0556, -0.0556, -0.0556, -0.0556],
#            ...,
#            [-0.0556, -0.0556, -0.0556, -0.0556],
#            [-0.0556, -0.0556, -0.0556, -0.0556],
#            [-0.0556, -0.0556, -0.0556, -0.0556]], device='cuda:0',
#           grad_fn=<SubBackward0>)
#           
#    y torch.Size([16650, 4]) 
#    tensor([[0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            ...,
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.]], device='cuda:0', grad_fn=<AddBackward0>)
#            
#    y.sum() tensor(2.0036, device='cuda:0', grad_fn=<SumBackward0>)
    
    return y.sum()


def _fast_rcnn_loc_loss(pred_loc, gt_loc, gt_label, sigma):

#    RPN loss :  COMPUTE RPN Loss on ALL 16650 FIXED & PREDICTED anchor bbox w.r.t ground-truth bbox (before Attention -> must compute ALL)
#            rpn_loc,             # [16650, 4]  :  Use image + CNN to predict 4 INCREMENTAL (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) coordinates of each anchor BOXES
#            gt_rpn_loc,          # [16650, 4]  :  Fill 5834 inside FIXED anchor bbox to 16650 bbox with DIFFERENCE dy, dx, dheight, dwidth to ground-truth coordinates
#            gt_rpn_label.data,   # [16650]     :  Fill 5834 inside FIXED anchor bbox to 16650 bbox with 256 positive and negative sampling fixed anchor bbox (247 negative label 0, 9 positive label 1, the rest are igore label -1)
#            self.rpn_sigma       # 3.  : sigma for l1_smooth_loss    
#
#            pred_loc : rpn_locs  torch.Size([16650, 4])                                     # Use image + CNN to PREDICT 4 INCREMENTAL (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) coordinates of each anchor BOXES
#            tensor([[ 1.0164e-02, -8.5225e-02, -1.6837e-03, -8.4621e-03],
#                    [-1.1096e-02,  4.1846e-02,  2.9004e-02, -2.2258e-02],
#                    [-1.2302e-05,  1.5893e-02,  9.9560e-04, -2.6399e-02],
#                    ...,
#                    [-1.1011e-02,  4.7739e-03, -8.5138e-03, -9.6025e-03],
#                    [-2.1682e-02,  7.7298e-03,  2.0266e-03,  9.3305e-03],
#                    [-3.1961e-04,  8.2755e-03, -2.9834e-03, -3.8120e-03]],
#                  device='cuda:0', grad_fn=<ViewBackward>)
#
#            gt_loc : gt_rpn_loc  torch.Size([16650, 4])                                     # Fill 5834 inside FIXED anchor bbox to 16650 bbox with the DIFFERENCE dy, dx, dheight, dwidth to ground-truth coordinates
#            tensor([[0., 0., 0., 0.],                        
#                    [0., 0., 0., 0.],
#                    [0., 0., 0., 0.],
#                    ...,
#                    [0., 0., 0., 0.],
#                    [0., 0., 0., 0.],
#                    [0., 0., 0., 0.]], device='cuda:0')
#                    
#            gt_label : gt_rpn_label  torch.Size([16650])                                    # Fill 5834 inside FIXED anchor bbox to 16650 bbox with 256 positive and negative sampling fixed anchor bbox (247 negative label 0, 9 positive label 1, the rest are igore label -1)
#            tensor([-1, -1, -1,  ..., -1, -1, -1], device='cuda:0')   
#
#    ROI loss : COMPUTE ROI Loss only on 128 positive and negative sample bbox w.r.t ground-truth bbox (After Attention -> only compute 128 sample bbox)
#            roi_loc.contiguous(),  # [128, 4]  : the corresponding 4 PREDICTED coordinates of ground-truth OBJECT ROI bbox 
#            gt_roi_loc,            # [128, 4]  : normalized DIFFERENCE dcenter_y, dcenter_x, dheight, dwidth between ground-truth and PREDICTED sample bbox
#            gt_roi_label.data,     # [128]     : 128 sample PREDICTED bbox labels (~1/4 highest IoU positive, ~3/4 negative predicted bbox that MATCH ANY ground-truth bbox - LABELS OF NEGATIVE PREDICTED BBOX are 0) 
#            self.roi_sigma         # 1.        : sigma for l1_smooth_loss
#
#            pred_loc : roi_loc  torch.Size([128, 4])                                        # the corresponding 4 PREDICTED INCREMENTAL coordinates of OBJECT ROI sample bbox to ground-truth bbox 
#            tensor([[-2.1290e-02,  1.1263e-02, -6.1761e-03, -8.9484e-04],
#                    [-1.9060e-02,  2.3638e-02,  4.7915e-03, -7.4005e-04],
#                    [-3.5782e-02,  4.7630e-02, -1.0751e-02, -2.4448e-03],
#                    [-1.9436e-02,  6.4710e-03,  2.3618e-02, -1.4385e-02],
#                    ...    
#
#            gt_loc : gt_roi_loc (128, 4)                                                    # normalized DIFFERENCE dcenter_y, dcenter_x, dheight, dwidth between ground-truth and predicted sample bbox
#                    [[ 7.18253255e-01 -6.30119964e-02 -1.13267779e+00 -1.28626525e+00]
#                     [-6.41956151e-01 -3.66967130e+00  2.46670112e-01  2.52623582e+00]
#                     [ 1.69158146e-01  1.07181573e+00 -5.29380262e-01 -2.67045856e+00]
#                     [ 4.04388964e-01  1.37424275e-01  1.19411612e+00 -1.85896420e+00]
#                     [-9.34505761e-01 -1.25888300e+00  1.24068916e+00 -1.81490433e+00]
#                     [ 3.35547066e+00  1.02210808e+00  2.34848738e+00 -5.63904166e-01]
#                     [ 8.91976133e-02 -1.46019995e+00 -4.47296411e-01 -1.45823050e+00]
#                     ...
#                     [ 1.74070892e+01 -8.66320324e+00  2.28472009e-01 -3.08015609e+00]      # negative samples (predicted bbox are far from ground-truth bbox) have large difference ...
#                     [ 3.28212509e+01  1.13312740e+01  4.22831488e+00 -3.05706358e+00]
#                     [ 1.18478956e+01 -2.91177607e+00  2.37985134e+00 -3.86248040e+00]
#                     [ 4.67760038e+00 -3.27569885e+01  6.76378071e-01  5.99376082e-01]
#                     [ 2.45431709e+00  1.67006481e+00 -3.73248911e+00 -1.21479452e+00]]
#            
#            gt_label : gt_roi_label (128,)                                                  # Labels of 128 sample predicted bbox (~1/4 highest IoU positive, ~3/4 negative predicted bbox that MATCH ANY ground-truth bbox - LABELS OF NEGATIVE PREDICTED BBOX are 0)   
#                    [9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#                     0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#                     0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#                     0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]
            
    in_weight = t.zeros(gt_loc.shape).cuda()
    # Localization loss is calculated only for positive rois  : For background RoIs there is no notion of a ground-truth bounding box and hence Loss_loc is ignored  (page 3 of https://arxiv.org/pdf/1504.08083.pdf)
    # NOTE:  unlike origin implementation, 
    # we don't need inside_weight and outside_weight, they can calculate by gt_label
    in_weight[(gt_label > 0).view(-1, 1).expand_as(in_weight).cuda()] = 1
    
#    (gt_label > 0).view(-1, 1) torch.Size([16650, 1])
#    
#    (gt_label > 0).view(-1, 1).expand_as(in_weight) torch.Size([16650, 4])
#    
#    in_weight torch.Size([16650, 4])                                          # There are only 9 positive fixed anchor bbox in this image (overlapped with ground-truth bbox) : (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) weight = 1
#    tensor([[0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            ...,
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.],
#            [0., 0., 0., 0.]], device='cuda:0')
    
    loc_loss = _smooth_l1_loss(pred_loc, gt_loc, in_weight.detach(), sigma)
    
#    loc_loss 
#    tensor(2.0036, device='cuda:0', grad_fn=<SumBackward0>)
    
    # Normalize by total number of negtive and positive rois.
    loc_loss /= ((gt_label >= 0).sum().float()) # ignore gt_label==-1 for rpn_loss
    
#    (gt_label >= 0).sum() 
#    tensor(256, device='cuda:0')                                              #  normalized by the sampling size 256 positive and negative samples fixed anchor bbox w.r.t ground-truth  : page 5 of https://arxiv.org/pdf/1506.01497.pdf
#    
#    loc_loss 
#    tensor(0.0078, device='cuda:0', grad_fn=<DivBackward0>)
    
    return loc_loss
