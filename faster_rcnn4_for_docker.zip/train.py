from __future__ import  absolute_import
import os
os.system('nohup python -m visdom.server &')
import sys
from time import time as ttime
import time

import zipfile
import shutil
import ipdb  # ipdb exports functions to access the IPython debugger
import matplotlib
from tqdm import tqdm
from torch.utils import data as data_
from google.cloud import storage
import gcsfs
import json

# reproducibility
import torch
torch.manual_seed(2000)
from torch import nn
from torchnet.meter import ConfusionMeter
import numpy as np
from npy_append_array import NpyAppendArray
np.random.seed(2000)

import matplotlib.backends.backend_pdf
from matplotlib import pyplot as plot

from data.dataset import Dataset, TestDataset, inverse_normalize
from data import util
from data.voc_dataset_logo_detection import VOC_BBOX_LABEL_NAMES, VOCBboxDataset

from model import FasterRCNNVGG16
from model.faster_rcnn_vgg16 import normal_init
from trainer import FasterRCNNTrainer

from utils import array_tool as at
from utils.config import opt

from utils.vis_tool import visdom_bbox, vis_bbox  #####
from utils.eval_tool import eval_detection_voc

# fix for ulimit
# https://github.com/pytorch/pytorch/issues/973#issuecomment-346405667
import resource

rlimit = resource.getrlimit(resource.RLIMIT_NOFILE)
resource.setrlimit(resource.RLIMIT_NOFILE, (20480, rlimit[1]))

matplotlib.use('agg')


def zipdir(path, ziph):
    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file), 
                       os.path.relpath(os.path.join(root, file), 
                                       os.path.join(path, '..')))
      

def eval_plot_inspect(opt, dataloader, faster_rcnn, dataset_name, trainer):
    ''' only load pretrained model & plot ground-truth + predicted bbox in the same graph '''

    # if os.path.exists(dataset_name + "_output_pdfs/"):
    #     shutil.rmtree(dataset_name + "_output_pdfs/")  
    # os.mkdir(dataset_name + "_output_pdfs/")
    
    for ii, (id_imgs, imgs, sizes, gt_bboxes_, gt_labels_, gt_difficults_) in tqdm(enumerate(dataloader)):
        # imgs       : ONLY Rescale shorter edge to 600 pixels & Scale, Normalize the pixel values
        #              Don't do (Scale the ground-truth corresponding bounding-boxes + Image Augmentation: Flip Image by Width + Flip the scaled bounding-boxes) at Test time        
        # sizes      : (H, W) from ori_img.shape [C, H, W] before scaling shorter side to 600 pixels
        # gt_bboxes_ : list of 4 coordinates ground-truth bbox before adjusted according to image scaling shorter side to 600 pixels


#        imgs torch.Size([1, 3, 850, 600])
#        sizes [tensor([500]), tensor([353])]
        sizes = [sizes[0][0].item(), sizes[1][0].item()]    #  (H, W) from ori_img.shape [C, H, W] before scaling shorter side to 600 pixels
#        sizes [500, 353]

        
        # need to scale gt_bboxes_ correspondingly to the SCALED image --------------------------------------------------
        H, W = sizes[0], sizes[1]                           #  (H, W) from ori_img.shape [C, H, W] before scaling shorter side to 600 pixels                 
        _, o_H, o_W = imgs[0].shape                         #  (H, W) of SCALED image (shorter side to 600 pixels)
        
        # resize ground-truth bbox following the SCALED image
        # print("gt_bboxes_", gt_bboxes_.size(), gt_bboxes_, type(gt_bboxes_))
        gt_bboxes_np = util.resize_bbox(at.tonumpy(gt_bboxes_[0]), (H, W), (o_H, o_W))    


        # ============================================================================
        # We only perform batch_size = 1 -> image, bbox or label : we take the first element 
        # plot groud truth bboxes
        ori_img_ = inverse_normalize(at.tonumpy(imgs[0]))  #  for VISUALIZATION : always need to get back all raw pixel values (before normalizing) [channel, width, height] of SCALED image (shorter side to 600 pixel)
        gt_img = vis_bbox(ori_img_,     
                             gt_bboxes_np,
                             at.tonumpy(gt_labels_[0]),
                             title="Ground-truth")
        gt_img = gt_img.get_figure()
        
        #
        if opt.visualization:
            gt_img2 = visdom_bbox(ori_img_,     
                                 gt_bboxes_np,
                                 at.tonumpy(gt_labels_[0]))        
            trainer.vis.img('gt_img', gt_img2) 
        
        # ============================================================================
        # special   : here, sizes are (H, W) of original, unscaling shorter size to 600 pixels (unlike predict after 100 training iteration point)
        
        ### visualization at test time                                : imgs     (SCALED image + normalized)   +  sizes ([H, W] of original image before scaling shorter side to 600 pixels) + visualize (False)
        # pred_bboxes_, pred_labels_, pred_scores_ = faster_rcnn.predict(imgs, [[o_H, o_W]])                                 
        ### visualization at test time (but mimic training time !!!)  : ori_img_ (SCALED image + unnormalized) +  sizes (None)                                                               + visualize (True)
        pred_bboxes_, pred_labels_, pred_scores_ = faster_rcnn.predict([ori_img_], visualize=True)  
        
        pred_img = vis_bbox(ori_img_,       
                               at.tonumpy(pred_bboxes_[0]),
                               at.tonumpy(pred_labels_[0]).reshape(-1),
                               at.tonumpy(pred_scores_[0]),
                               title="Prediction")
        pred_img = pred_img.get_figure()
        
        #
        if opt.visualization:
            pred_img2 = visdom_bbox(ori_img_,       
                                   at.tonumpy(pred_bboxes_[0]),
                                   at.tonumpy(pred_labels_[0]).reshape(-1),
                                   at.tonumpy(pred_scores_[0]))        
            trainer.vis.img('pred_img', pred_img2) 

        # if id_imgs[0].split("_")[0] == 'aldi':   #  debug  ------------------------------
        #     print("image : ", id_imgs[0])
        #     print("pred_bbox_l:\n", at.tonumpy(pred_bboxes_[0]))
        #     print("gt_bbox_l:\n", gt_bboxes_np)
        #     print("at.tonumpy(gt_bboxes_[0]):\n", at.tonumpy(gt_bboxes_[0]), "\n")

        # saving mulitple plots into a pdf --------------------------
        # pdf = matplotlib.backends.backend_pdf.PdfPages(dataset_name + "_output_pdfs/" + id_imgs[0][:-4] + ".pdf")
        pdf = matplotlib.backends.backend_pdf.PdfPages(dataset_name + id_imgs[0][:-4] + ".pdf")
        
        pdf.savefig(gt_img)
        plot.close(gt_img)
        pdf.savefig(pred_img)
        plot.close(pred_img)
        pdf.close()
        


    print("finished creating pdf graphs... preparing to zip these pdfs....")
    
    #
    # zipf = zipfile.ZipFile(dataset_name + '_output_pdfs.zip', 'w', zipfile.ZIP_DEFLATED)
    # zipdir(dataset_name + "_output_pdfs/", zipf)
    # zipf.close()
    
    # print("finished zipping pdf graphs...")


def checkanddeletefile(filename):
    if os.path.exists(filename):
        os.remove(filename)

def eval(dataloader, faster_rcnn):
    pred_bboxesF, pred_labelsF, pred_scoresF = "pred_bboxes.npy", "pred_labels.npy", "pred_scores.npy"
    gt_bboxesF, gt_labelsF, gt_difficultsF = "gt_bboxes.npy", "gt_labels.npy", "gt_difficults.npy"
    cnt_obj_predF, cnt_obj_gtF, cnt_obj_pred_index, cnt_obj_gt_index = "cnt_obj_pred.npy", "cnt_obj_gt.npy", 0, 0

    #
    checkanddeletefile(pred_bboxesF)
    checkanddeletefile(pred_labelsF)
    checkanddeletefile(pred_scoresF)
    checkanddeletefile(gt_bboxesF)
    checkanddeletefile(gt_labelsF)
    checkanddeletefile(gt_difficultsF)

    checkanddeletefile(cnt_obj_predF)
    checkanddeletefile(cnt_obj_gtF)
    
    #
    pred_bboxes, pred_labels, pred_scores = NpyAppendArray(pred_bboxesF), NpyAppendArray(pred_labelsF), NpyAppendArray(pred_scoresF)
    gt_bboxes, gt_labels, gt_difficults = NpyAppendArray(gt_bboxesF), NpyAppendArray(gt_labelsF), NpyAppendArray(gt_difficultsF)
    cnt_obj_pred, cnt_obj_gt = NpyAppendArray(cnt_obj_predF), NpyAppendArray(cnt_obj_gtF)
    
    list_id_imgs = []
    
    for ii, (id_imgs, imgs, sizes, gt_bboxes_, gt_labels_, gt_difficults_) in tqdm(enumerate(dataloader)):
        # imgs       : ONLY Rescale shorter edge to 600 pixels & Scale, Normalize the pixel values
        #              Don't do (Scale the ground-truth corresponding bounding-boxes + Image Augmentation: Flip Image by Width + Flip the scaled bounding-boxes) at Test time        
        # sizes      : (H, W) from ori_img.shape [C, H, W] before scaling shorter side to 600 pixels
        # gt_bboxes_ : list of 4 coordinates ground-truth bbox before adjusted according to image scaling shorter side to 600 pixels
        
#        imgs torch.Size([1, 3, 850, 600])
#        sizes [tensor([500]), tensor([353])]
        sizes = [sizes[0][0].item(), sizes[1][0].item()]    #  compute IoU, mAP : we compare original ground-truth bbox w.r.t predicted bbox on original image size
#        sizes [500, 353]
        
        # ============================================================================
        # special   : here, sizes are (H, W) of original, unscaling shorter size to 600 pixels (unlike predict after 100 training iteration point)
        # visualize : False
        pred_bboxes_, pred_labels_, pred_scores_ = faster_rcnn.predict(imgs, [sizes])   
        
#        pred_bboxes_   always list of batch_size = 1 element : [2 bbox, 4 coordinates]
#            [array([[221.61136 ,  44.299164, 487.33102 , 309.88437 ],
#                    [ 25.14003 ,  30.123611, 492.1704  , 342.72693 ]], dtype=float32)]
#        gt_bboxes_     [batch_size=1, 2 bbox, 4 coordinates]
#            tensor([[[239.,  47., 370., 194.],
#                     [ 11.,   7., 497., 351.]]])
        
        #
        pred_bboxes.append(pred_bboxes_[0])
        pred_labels.append(pred_labels_[0])
        pred_scores.append(pred_scores_[0])
        gt_bboxes.append(gt_bboxes_.numpy()[0])
        gt_labels.append(gt_labels_.numpy()[0])
        gt_difficults.append(gt_difficults_.numpy()[0])
        
        #
        cnt_obj_pred_index += pred_bboxes_[0].shape[0] 
        cnt_obj_gt_index += gt_bboxes_.numpy()[0].shape[0]
        cnt_obj_pred.append(np.array([cnt_obj_pred_index]))
        cnt_obj_gt.append(np.array([cnt_obj_gt_index]))
        
        list_id_imgs.append(id_imgs[0])
        
        if ii == 100:
            break
        
        
#        cnt_obj_pred_index  25067 bbox  of 5000 test photos
#        cnt_obj_gt_index  14975 bbox  of 5000 test photos

    # ============================================================================

#    pred_bboxesT = np.load(pred_bboxesF, mmap_mode="r")
#    pred_labelsT = np.load(pred_labelsF, mmap_mode="r")
#    pred_scoresT = np.load(pred_scoresF, mmap_mode="r")
#    gt_bboxesT = np.load(gt_bboxesF, mmap_mode="r")
#    gt_labelsT = np.load(gt_labelsF, mmap_mode="r")
#    gt_difficultsT = np.load(gt_difficultsF, mmap_mode="r")
#
#    cnt_obj_predT = np.load(cnt_obj_predF, mmap_mode="r")
#    cnt_obj_gtT = np.load(cnt_obj_gtF, mmap_mode="r")    
#    
#    print(pred_bboxesT)
#    print(pred_labelsT)
#    print(pred_scoresT)
#    print(gt_bboxesT)
#    print(gt_labelsT)
#    print(gt_difficultsT)
#    
#    print(cnt_obj_predT)
#    print(cnt_obj_gtT)



    
# E.g. with 4 test photos:
#
# pred_bboxes 4 
#    [array([[221.61136 ,  44.299164, 487.33102 , 309.88437 ],
#            [ 25.14003 ,  30.123611, 492.1704  , 342.72693 ]], dtype=float32), 
#     array([[191.42728, 138.70303, 302.36884, 212.67474]], dtype=float32), 
#     array([], shape=(0, 4), dtype=float32),
#     array([[325.56445 , 366.76416 , 397.30756 , 497.12292 ],
#           [307.4119  ,  17.040134, 364.4894  ,  89.87898 ],
#           [330.57782 , 226.93521 , 370.17725 , 330.95572 ],
#           [326.009   , 173.09056 , 365.33005 , 236.80714 ],
#           [322.85275 ,  98.584496, 353.1072  , 145.67227 ],
#           [322.5796  , 137.15245 , 357.75793 , 193.14159 ],
#           [337.3039  , 116.71232 , 359.41534 , 145.02661 ],
#           [321.9413  ,  84.13301 , 351.60965 , 116.031525],
#           [336.00732 , 132.81207 , 360.46997 , 163.81601 ],
#           [325.2001  , 215.71725 , 356.9553  , 243.51517 ]], dtype=float32)]  ----> there are many predicted bbox than actual ground-truth bbox : sort score, take only argmax in each object, the rest will be set to False Positive (even if these rests have IoU w.r.t ground-truth > 0.5)
#    
# pred_labels 4 
#    [array([11, 14], dtype=int32), 
#     array([18], dtype=int32), 
#     array([], dtype=int32),
#     array([6, 6, 6, 6, 6, 6, 6, 6, 6, 6], dtype=int32)]
#     
# pred_scores 4 
#    [array([0.7608298, 0.9993948], dtype=float32), 
#     array([0.9987317], dtype=float32), 
#     array([], dtype=float32),                                 ----> there is not even a predicted bbox (all score < 0.05 : the model is very sure that all bbox are backgrounds) !  -> recall 1 and precision 0 on this object
#     array([0.9997483 , 0.9984164 , 0.99511576, 0.99032074, 0.9720905 , 0.964653  , 0.555981  , 0.34069893, 0.21620221, 0.07177667], dtype=float32)]
#                                                               
#    -----------------------------------------
#  
# gt_bboxes 4 
#    [array([[239.,  47., 370., 194.],
#           [ 11.,   7., 497., 351.]], dtype=float32), 
#     array([[199., 138., 300., 206.]], dtype=float32), 
#     array([[154., 122., 194., 214.],
#           [155., 238., 204., 306.]], dtype=float32),
#     array([[310.,  12., 361.,  83.],
#           [329., 361., 388., 499.],
#           [327., 234., 374., 333.],
#           [326., 174., 363., 251.],
#           [319., 138., 358., 188.],
#           [324., 107., 352., 149.],
#           [322.,  83., 349., 120.]], dtype=float32)]
#           
# gt_labels 4 
#    [array([11, 14], dtype=int32), 
#     array([18], dtype=int32), 
#     array([17,  8], dtype=int32),
#     array([6, 6, 6, 6, 6, 6, 6], dtype=int32)]
#     
# gt_difficults 4 
#    [array([0, 0], dtype=uint8), 
#     array([0], dtype=uint8), 
#     array([0, 0], dtype=uint8),
#     array([0, 0, 0, 0, 0, 0, 0], dtype=uint8)]

    result = eval_detection_voc(pred_bboxesF, pred_labelsF, pred_scoresF,
                                gt_bboxesF, gt_labelsF, gt_difficultsF,
                                cnt_obj_predF, cnt_obj_gtF,
                                use_07_metric=True, list_id_imgs=list_id_imgs)
    
#    mAP 
#    0.6992741489955043
#    
#    ap list of each class 
#    [0.70562041 0.77886009 0.67637282 0.58711691 0.52832156 0.76882137
#     0.79463471 0.85745323 0.50240377 0.75716503 0.70757718 0.76495373
#     0.80057762 0.75777106 0.76871225 0.42644152 0.68291277 0.64100552
#     0.73902737 0.73973406]
    
    return result


def train(**kwargs):
    opt._parse(kwargs)
    
    if opt.prod:
        # reading txt & json file
        json_auth_path = 'mylibot_service_account_auth.json'
        storage_client = storage.Client.from_service_account_json(json_auth_path)
        gcs_bucket = storage_client.bucket(opt.gcs_bucket_name)
        # reading image
        f = open(json_auth_path,)
        token_auth = json.load(f)
        gcs_file_system = gcsfs.GCSFileSystem(project=opt.gcs_project_name, token=token_auth)
    else:
        gcs_bucket = None
        gcs_file_system = None
    

    dataset = Dataset(opt, gcs_bucket, gcs_file_system)
    print('load data')
    dataloader = data_.DataLoader(dataset, \
                                  batch_size=1, \
                                  shuffle=True)
        
    testset = TestDataset(opt, gcs_bucket, gcs_file_system)
    test_dataloader = data_.DataLoader(testset,
                                       batch_size=1,
                                       shuffle=False, 
                                       pin_memory=True)
    # initialize model parameters with ( OLD ) opt.n_class
    faster_rcnn = FasterRCNNVGG16(n_fg_class = opt.n_class)  # n_fg_class : foreground class = only object class

    print('model construct completed')
    trainer = FasterRCNNTrainer(faster_rcnn).cuda()





    # = True only when we want to fine-tune on another dataset --------------------------------------
    if opt.freeze_net:
        print('freeze faster rcnn parameters ....')
        for param in faster_rcnn.parameters():
            param.requires_grad = False
    
    
    # Load pretrained model ----------------------------------------------------------
    if opt.load_path:
        # load pretrained model
        trainer.load(opt.load_path)
        print('load pretrained model from %s' % opt.load_path)
        if opt.n_class_new == 0:
            print('continue training from previous checkpoint....')
        else:
            print('fine-tune model on different dataset with different number of categories....')
            # REPLACE last layer parameters (n_class) by new layers with different number of categories (n_class_new)
            # Remember to set n_class = number of categories in the old dataset (to be able to load old parameters)
            # opt.n_class = opt.n_class_new
            trainer.roi_cm = ConfusionMeter(opt.n_class_new + 1)  #  to perform stats on new number of categories
            faster_rcnn.head.n_class = opt.n_class_new + 1        #  + background class (index 0)
            
            # Parameters of newly constructed modules have requires_grad=True by default
            faster_rcnn.head.cls_loc = nn.Linear(4096, faster_rcnn.head.n_class * 4).cuda()  # n_class = 21 (20 object classes + background)
            faster_rcnn.head.score = nn.Linear(4096, faster_rcnn.head.n_class).cuda()
            
            # initialize parameters of new last layer
            normal_init(faster_rcnn.head.cls_loc, 0, 0.001)
            normal_init(faster_rcnn.head.score, 0, 0.01)
            
            
            
            
    # inspect_testset = True : if we want to inspect test set from previous pretrained model --------------
    if opt.inspect_testset:
        print("inspecting testset and plot bbox predictions ....")
        
        # get graphs on test set ********************
        # eval_plot_inspect(opt, test_dataloader, trainer.faster_rcnn, opt.save_pdf_path, trainer)
        
        
        
        # get graphs on training set **********************
        # trainset = TestDataset(opt)   #  get the configuration of Test object (for evaluation code) but we will change the data directory of test set
        # trainset.db = VOCBboxDataset(opt.voc_data_dir, split="trainval")
        # train_dataloader = data_.DataLoader(trainset, \
        #                                       batch_size=1, \
        #                                       shuffle=False,
        #                                       pin_memory=True)      
        # eval_plot_inspect(opt, train_dataloader, trainer.faster_rcnn, opt.save_pdf_path, trainer)
        
        
        # compute mAP *****************************
        start_time = ttime()
        eval_result = eval(test_dataloader, faster_rcnn)     #
        print("\nTake ", round((ttime() - start_time)/60, 2), " minutes to evaluate on test set")
        print("mAP : ", eval_result['map'])
        print("AP on each class :", eval_result['ap'], "\n")
        
        
        exit(0)
    
    
    
    # Visualizer   
    if opt.visualization:
        trainer.vis.text(dataset.db.label_names, win='labels')
    
    best_map = 0
    lr_ = opt.lr
    start_training_time = ttime()
    for epoch in range(opt.epoch):
        print('epoch ', epoch, '\n')
        trainer.reset_meters()
        
        for ii, (id_img, img, bbox_, label_, scale) in tqdm(enumerate(dataloader)):  
            
            scale = at.scalar(scale)
            img, bbox, label = img.cuda().float(), bbox_.cuda(), label_.cuda()
            
            # ------------------------------------------------------------------------------------------------------
            # Call directly forward of trainer (+ optimizer.zero_grad(),  , losses.total_loss.backward(), optimizer.step(), update_meters(losses) as usual)
            # At training time : besides scaled (shorter side to 600 : ratio in *scale* variable), image can be also flipped + flip & scale the corresponding ground-truth bounding-box
            trainer.train_step(img, bbox, label, scale)
            
            if ii == 100:
                print("training 100 images takes : ", ttime() - start_training_time, " seconds")
                break
            
            # Plot stats at plot_every training step ------------------------------------------------------------------------------------------------------
            if (ii + 1) % opt.plot_every == 0:

                if os.path.exists(opt.debug_file):
                    ipdb.set_trace()

                # plot loss  
                if opt.visualization:
                    trainer.vis.plot_many(trainer.get_meter_data())

                # We only perform batch_size = 1 -> image, bbox or label : we take the first element 
                # plot groud truth bboxes
                ori_img_ = inverse_normalize(at.tonumpy(img[0]))  #  for VISUALIZATION : always need to get back all raw pixel values (before normalizing) [channel, width, height] of SCALED image (shorter side to 600 pixel)
                if opt.visualization:
                    gt_img = visdom_bbox(ori_img_,     
                                         at.tonumpy(bbox_[0]),
                                         at.tonumpy(label_[0]))
                    trainer.vis.img('gt_img', gt_img) 

                # plot predicti bboxes ==================================
                _bboxes, _labels, _scores = trainer.faster_rcnn.predict([ori_img_], visualize=True)
                
                if opt.visualization:
                    pred_img = visdom_bbox(ori_img_,       
                                           at.tonumpy(_bboxes[0]),
                                           at.tonumpy(_labels[0]).reshape(-1),
                                           at.tonumpy(_scores[0]))
                    trainer.vis.img('pred_img', pred_img)   

                    # rpn confusion matrix(meter)         
                    trainer.vis.text(str(trainer.rpn_cm.value().tolist()), win='rpn_cm')
                    # roi confusion matrix                
                    trainer.vis.img('roi_cm', at.totensor(trainer.roi_cm.conf, False).float())
            
                

        # Evaluate on dev set after each epoch ------------------------------------------------------------------------------------------------------
        start_time = ttime()
        eval_result = eval(test_dataloader, faster_rcnn)     #
        print("\nTake ", round((ttime() - start_time)/60, 2), " minutes to evaluate on test set")
        print("mAP : ", eval_result['map'])
        print("AP on each class :", eval_result['ap'], "\n")
        if opt.visualization:
            trainer.vis.plot('test_map', eval_result['map'])
        lr_ = trainer.faster_rcnn.optimizer.param_groups[0]['lr']
        log_info = 'lr:{}, map:{},loss:{}'.format(str(lr_),
                                                  str(eval_result['map']),
                                                  str(trainer.get_meter_data()))
        if opt.visualization:
            trainer.vis.log(log_info)


        # Save model if the new performance is higher ----------------
        eval_result['map'] += 0.5
        
        if eval_result['map'] > best_map:
            best_map = eval_result['map']
            # save to current environment
            best_path = trainer.save(best_map=best_map)
            
            if opt.prod:
                # upload to gcs
                blob = gcs_bucket.blob(opt.save_model_path + best_path.split('/')[1])
                blob.upload_from_filename(best_path)
                
        if epoch == 9:
            trainer.load(best_path)
            trainer.faster_rcnn.scale_lr(opt.lr_decay)
            lr_ = lr_ * opt.lr_decay
        
        epoch = 13

        if epoch == 13: 
            print("\nTake ", round((ttime() - start_training_time)/60/60, 2), " hours to train on 13 epochs")
            # delete all saved files in current environment in the end
            shutil.rmtree('checkpoints')
            break


if __name__ == '__main__':
    import fire  # Python Fire is a Python library that will turn any Python component into a command line interface with just a single call to Fire

    fire.Fire(train)
