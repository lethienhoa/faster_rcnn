from __future__ import  absolute_import
from __future__ import  division
import torch as t
import numpy as np

from skimage import transform as sktsf
from torchvision import transforms as tvtsf

from data import util
from data.voc_dataset_logo_detection import VOCBboxDataset   
#from data.voc_dataset import VOCBboxDataset    # if we want to evaluate on Pascal VOC

from utils.config import opt


def inverse_normalize(img):
    if opt.caffe_pretrain:
        img = img + (np.array([122.7717, 115.9465, 102.9801]).reshape(3, 1, 1))
        return img[::-1, :, :]
        
    # approximate un-normalize (& un-scaling) for visualize
    return (img * 0.225 + 0.45).clip(min=0, max=1) * 255   # [ image * std + mean ] * 255


def pytorch_normalze(img):
    """ Normalize pixel values (on each color channel) from [0, 1] to [-2.117, 2.248] : help CNN perform better (reduces the skewness which helps learn faster and better).
        This change the shape of the data to normal distribution (because of the numerator) (https://kharshit.github.io/blog/2018/03/23/scaling-vs-normalization)
        To find the best numerator, if the dataset is really different than ImageNet, we can recompute the mean and std on the whole dataset (https://stackoverflow.com/questions/58151507/why-pytorch-officially-use-mean-0-485-0-456-0-406-and-std-0-229-0-224-0-2)    
    
    https://github.com/pytorch/vision/issues/223
    return appr -1~1 RGB
    """
    normalize = tvtsf.Normalize(mean=[0.485, 0.456, 0.406],
                                std=[0.229, 0.224, 0.225])  # Normalize: image = (image - mean) / std , these values are for RGB image, reused the stats computed on millions of ImageNet samples. For grey image, we will choose mean=0.5 and std=0.5 . This implies [0, 1] -> [-1, 1] : new values have mean = 0 and std = 1 
    img = normalize(t.from_numpy(img))
    return img.numpy()


def caffe_normalize(img):
    """
    return appr -125-125 BGR
    """
    img = img[[2, 1, 0], :, :]  # RGB-BGR
    img = img * 255
    mean = np.array([122.7717, 115.9465, 102.9801]).reshape(3, 1, 1)
    img = (img - mean).astype(np.float32, copy=True)
    return img


def preprocess(img, min_size=600, max_size=1000):  # one side must has the size = 600 pixels
    """Preprocess an image for feature extraction (both at training and test time) : Rescale shorter edge to 600 pixels & scale, normalize the pixel values

    The length of the shorter edge is scaled to :obj:`self.min_size`.
    After the scaling, if the length of the longer edge is longer than :param min_size:
    :obj:`self.max_size`, the image is scaled to fit the longer edge to :obj:`self.max_size`.

    After resizing the image, the image is subtracted by a mean image value :obj:`self.mean`.

    Args:
        img (~numpy.ndarray): An image. This is in CHW and RGB format.
            The range of its value is :math:`[0, 255]`.

    Returns:
        ~numpy.ndarray: A preprocessed image.

    """
    C, H, W = img.shape  # (3, 375, 500)      | (3, 500, 320)
    scale1 = min_size / min(H, W)
#    print("min_size, min(H, W), scale1 :", min_size, min(H, W), scale1)  # min_size, min(H, W), scale1 : 600 375 1.6    |  600 320 1.875
    scale2 = max_size / max(H, W)
#    print("max_size, max(H, W), scale2 :", max_size, max(H, W), scale2)  # max_size, max(H, W), scale2 : 1000 500 2.0   |  1000 500 2.0
    scale = min(scale1, scale2)
#    print("scale = min(scale1, scale2) : ", scale)                       # scale = min(scale1, scale2) :  1.6           |  1.875
    img = img / 255.  # pixel values in [0..1] - change the scale of the data
    img = sktsf.resize(img, (C, H * scale, W * scale), mode='reflect',anti_aliasing=False) # upsample or downsample image, perform Gaussian smoothing to avoid aliasing artifacts
    # img  (3, 600, 800)   |   img  (3, 938, 600)
    # both the longer and shorter should be less than max_size and min_size
    if opt.caffe_pretrain:
        normalize = caffe_normalize
    else:
        normalize = pytorch_normalze
    return normalize(img)


class Transform(object):
    ''' 
        Only perfom Transform at training time (not at test time) : 
            Preprocess resize image
            + Scale the ground-truth photo (shorter side to 600 pixel value) + scale corresponding bounding-boxes 
            + Image Augmentation: Flip Image by Width + Flip the scaled bounding-boxes
            + Normalize pixel values
    '''

    def __init__(self, min_size=600, max_size=1000): # These values were selected so that *VGG16* (from Fast RCNN) fits in GPU memory during fine-tuning
        self.min_size = min_size
        self.max_size = max_size

    def __call__(self, in_data):
        img, bbox, label = in_data
        _, H, W = img.shape
        
        # Rescale shorter edge to 600 pixels & Scale (so that it can fit VGG16 well), Normalize the pixel values
        img = preprocess(img, self.min_size, self.max_size)  #
        _, o_H, o_W = img.shape
        
        # the ratio (upsampling or downsampling image) of shorter adge that was scaled to min_size=600 pixels, it is different from one photo to another
        scale = o_H / H                                      
        

        # Only perform at training time (not at test time) -----------------------------------
        
        # resize ground-truth bbox following the resized image
        bbox = util.resize_bbox(bbox, (H, W), (o_H, o_W))    
        # An Image Augmentation trick : randomly Flip the Width (inverse W pixel values from left-to-right to right-to-left)
        img, params = util.random_flip(img, x_random=True, return_param=True)
        # flip the resized bbox following the flipped resize image (if it happens)
        bbox = util.flip_bbox(bbox, (o_H, o_W), x_flip=params['x_flip'])

        return img, bbox, label, scale


class Dataset:
    def __init__(self, opt, gcs_bucket, gcs_file_system):
        self.opt = opt
        self.db = VOCBboxDataset(opt.voc_data_dir, gcs_bucket, gcs_file_system, opt)        #
        self.tsf = Transform(opt.min_size, opt.max_size)  #

    def __getitem__(self, idx):
        ''' idx : the index (not the file name) of the image in trainval dataset in [0..5010] '''
        
        # read image using PIL and reshape, transform it into numpy vectors
        id_img, ori_img, bbox, label, difficult = self.db.get_example(idx) # bbox: 4 coordinates of the bounding box, difficult: level of difficulty in recognizing object
        # set --num_workers=1 to be able to debug on each image (default: 8 CPUs image input reading for processing batch_size=1 on GPU)        

#        ori_img  (3, 375, 500)   # 3 color channels, each has H x W unsigned 8 bit integer pixels (image 2 in order list trainval)   |    (3, 500, 320)  (image 3225)
#        [[[ 83.  64.  72. ...  97. 241. 218.]
#          [ 78.  53.  82. ... 238. 160. 128.]
#          [ 83.  73.  58. ... 118.  29. 102.]
#          ...
#          [109. 108. 113. ... 103.  86.  93.]
#          [111.  84. 100. ...  85. 104.  96.]
#          [ 92.  82.  87. ...  89. 104.  95.]]
#        
#         [[114.  83.  82. ... 105. 252. 233.]
#          [103.  74.  97. ... 255. 185. 156.]
#          [107.  97.  85. ... 145.  60. 138.]
#          ...
#          [140. 140. 145. ... 139. 122. 129.]
#          [145. 119. 135. ... 121. 140. 132.]
#          [126. 119. 126. ... 125. 140. 131.]]
#        
#         [[ 82.  51.  48. ... 107. 255. 240.]
#          [ 63.  31.  54. ... 255. 182. 157.]
#          [ 59.  45.  30. ... 138.  55. 136.]
#          ...
#          [ 72.  67.  70. ...  65.  48.  55.]
#          [ 69.  39.  55. ...  51.  70.  62.]
#          [ 52.  39.  43. ...  55.  70.  61.]]]
#        bbox  [[171.  68. 329. 269.]                        # transformed 4 coordinates of one bounding-box (there are possibly MANY bounding-box in one image)
#         [140. 149. 283. 228.]
#         [200. 284. 330. 326.]
#         [197. 257. 328. 296.]]
#        label  [12 14 14 14]   # a horse and 3 people       # label class of this corresponding unique bounding-box in 20 PASCAL VOC categories
#        difficult  [0 0 0 0]        
        
        # Rescale shorter edge to 600 pixels & Scale, Normalize the pixel values  +  Scale the ground-truth corresponding bounding-boxes + Image Augmentation: Flip Image by Width + Flip the scaled bounding-boxes
        img, bbox, label, scale = self.tsf((ori_img, bbox, label)) #
        # TODO: check whose stride is negative to fix this instead copy all
        # some of the strides of a given numpy array are negative.

#        img  (3, 600, 800)                                                                               |  img  (3, 938, 600)
#        [[[ 1.4055811   1.5112729   1.6395078  ... -1.0444628  -0.863382 -0.77722293]
#          [ 1.0274987   1.142823    1.3521332  ... -1.0859368  -0.89602596 -0.80344534]               # transformed img (not integer value pixel 8 bit 0-255 any more !!!), pixel values are normally distributed in range [-2.117, 2.248]   
#          [ 0.1279139   0.23681654  0.56606686 ... -1.1607908  -0.95709985 -0.85408366]
#          ...
#          [-0.4544616  -0.42422566 -0.37412235 ... -0.63734853 -0.40930834 -0.30067328]
#          [-0.45606703 -0.4194094  -0.35485703 ... -0.68818766 -0.5307203 -0.45606703]
#          [-0.45954543 -0.4218175  -0.35378674 ... -0.6996933  -0.5802214 -0.5237633 ]]
#        
#         [[ 1.8591833   1.9505483   2.0397928  ... -0.6083464  -0.31059062 -0.17655268]
#          [ 1.5303802   1.6326867   1.8059101  ... -0.64117205 -0.3549052 -0.2230556 ]
#          [ 0.74892503  0.8465814   1.1439269  ... -0.692257   -0.4411409 -0.3194125 ]
#          ...
#          [ 0.2951107   0.32602155  0.37724325 ...  0.0873518   0.31063452 0.41731778]
#          [ 0.29346946  0.33094534  0.3969386  ...  0.05958668  0.19841175 0.26543078]
#          [ 0.2899134   0.32848346  0.39803275 ...  0.0571248   0.15163527 0.19786467]]
#        
#         [[ 2.1624675   2.235997    2.285357   ... -0.97887254 -0.6751552 -0.53926194]
#          [ 1.8089815   1.8934042   2.0274594  ... -1.0589379  -0.75985014 -0.62286764]
#          [ 0.96911234  1.0491778   1.3095264  ... -1.2264215  -0.94619274 -0.8116612 ]
#          ...
#          [-0.70837957 -0.67760617 -0.6266121  ... -1.0776606  -0.81540567 -0.69149494]
#          [-0.7056563  -0.6683469  -0.60264695 ... -1.1146296  -0.9243382 -0.83528584]
#          [-0.70919657 -0.6707978  -0.6015576  ... -1.1178976  -0.96600485 -0.8954711 ]]]
#        bbox  [[273.6     369.6     526.4     691.2    ]                                             # corresponding scaled bbox of SCALED IMAGE (shorter side to 600 pixels)  
#         [224.      435.19998 452.80002 561.6    ]
#         [320.      278.39996 528.      345.6    ]
#         [315.2     326.4     524.8     388.8    ]]
#        label  [12 14 14 14]
#        scale  1.6                                                                                        |  scale  1.876  , scale ratio of new, resized image w.r.t original image stretching from shorter side to 600
        
        return id_img, img.copy(), bbox.copy(), label.copy(), scale  # scale : o_H / Hs

    def __len__(self):
        return len(self.db)


class TestDataset:
    def __init__(self, opt, gcs_bucket, gcs_file_system, split='test', use_difficult=True):
        self.opt = opt                                                                             #
        self.db = VOCBboxDataset(opt.voc_data_dir_test, gcs_bucket, gcs_file_system, opt, split=split, use_difficult=use_difficult)  #

    def __getitem__(self, idx):
        id_img, ori_img, bbox, label, difficult = self.db.get_example(idx) #
        
        # ONLY Rescale shorter edge to 600 pixels & Scale, Normalize the pixel values
        # Don't do (Scale the ground-truth corresponding bounding-boxes + Image Augmentation: Flip Image by Width + Flip the scaled bounding-boxes) at Test time
        img = preprocess(ori_img)                                  
        
        return id_img, img, ori_img.shape[1:], bbox, label, difficult      # ori_img.shape[1:] : only take the tuple size of original input image (H, W) from ori_img.shape [C, H, W] before scaling shorter side to 600 pixels

    def __len__(self):
        return len(self.db)
