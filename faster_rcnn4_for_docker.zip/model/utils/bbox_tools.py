import numpy as np
import numpy as xp

import six
from six import __init__


def loc2bbox(src_bbox, loc):
    """ Compute NEW bounding-box coordinates PROPOSALS : COMBINE the hard-coded anchor list (16650, 4) WITH the corresponding small bbox coordinates values PREDICTED by Image & CNN
    
    Decode bounding boxes from bounding box offsets and scales.

    Given bounding box offsets and scales computed by
    :meth:`bbox2loc`, this function decodes the representation to
    coordinates in 2D image coordinates.

    Given scales and offsets :math:`t_y, t_x, t_h, t_w` and a bounding
    box whose center is :math:`(y, x) = p_y, p_x` and size :math:`p_h, p_w`,
    the decoded bounding box's center :math:`\\hat{g}_y`, :math:`\\hat{g}_x`
    and size :math:`\\hat{g}_h`, :math:`\\hat{g}_w` are calculated
    by the following formulas.

    * :math:`\\hat{g}_y = p_h t_y + p_y`
    * :math:`\\hat{g}_x = p_w t_x + p_x`
    * :math:`\\hat{g}_h = p_h \\exp(t_h)`
    * :math:`\\hat{g}_w = p_w \\exp(t_w)`

    The decoding formulas are used in works such as R-CNN [#]_.

    The output is same type as the type of the inputs.

    .. [#] Ross Girshick, Jeff Donahue, Trevor Darrell, Jitendra Malik. \
    Rich feature hierarchies for accurate object detection and semantic \
    segmentation. CVPR 2014.

    Args:
        src_bbox (array): A coordinates of bounding boxes.
            Its shape is :math:`(R, 4)`. These coordinates are
            :math:`p_{ymin}, p_{xmin}, p_{ymax}, p_{xmax}`.
        loc (array): An array with offsets and scales.
            The shapes of :obj:`src_bbox` and :obj:`loc` should be same.
            This contains values :math:`t_y, t_x, t_h, t_w`.
   
    My explanations:      
        src_bbox :     #  (fixed) list of all anchor BOXES coordinates (16650 = 37 * 50 * 9, 4)    #  y-min, x-min, y-max, x-max
        loc :          #  predicted RPN box coordinates by CNN : torch.Size([37 height * 50 width * 9 = 16650 anchor BOXES, 4 coordinates])
        
    Returns:
        array:
        Decoded bounding box coordinates. Its shape is :math:`(R, 4)`. \
        The second axis contains four values \
        :math:`\\hat{g}_{ymin}, \\hat{g}_{xmin},
        \\hat{g}_{ymax}, \\hat{g}_{xmax}`.

    """

#    src_bbx   (16650, 4)  : all generated FIXED anchor boxes on the feature map (= 37 * 50 * 9)
#
#
#    loc  (16650, 4)                                         # PREDICTED INCREMENTAL dy-center, dx-center, dheight, dweight BY CNN
#    [[ 0.03109254  0.01648028  0.00398883 -0.04307193]
#     [-0.01841378 -0.00119185  0.01245641 -0.02187549]
#     [-0.03330704 -0.02837169 -0.03154986  0.08170885]
#     ...
#     [ 0.02140935  0.0101308   0.00046712 -0.06726369]
#     [-0.02889876  0.01333712  0.01700273  0.02914027]
#     [ 0.01432629  0.00619125 -0.05782509  0.00029537]]


    if src_bbox.shape[0] == 0:
        return xp.zeros((0, 4), dtype=loc.dtype)

    src_bbox = src_bbox.astype(src_bbox.dtype, copy=False)
    
    
    # IMPORTANT NOTE: we convert (y-min, x-min, y-max, x-max) to (y-center, x-center, height, width) for both fixed src_bbox and predicted loc
    #                 compute the new bounding-box PROPOSALS, and then convert back the new coordinates to (y-min, x-min, y-max, x-max) format
    #                 because it is the safest way (otherwise, if we keep and predict (y-min, x-min, y-max, x-max), there's a chance that y-min, x-min are not min; y-max, x-max are not max any more.... )

    # Recompute height, width, center-y, center-x of each FIXED anchor BOX ---------------------------------------------------------------
    src_height = src_bbox[:, 2] - src_bbox[:, 0]    #  compute height   = y_max - y_min
#    src_height  (16650,) [ 90.50967 181.01933 362.03867 ... 181.01932 362.0387  724.0774 ]
    src_width = src_bbox[:, 3] - src_bbox[:, 1]     #  compute width    = x_max - x_min
#    src_width  (16650,) [181.01933 362.03867 724.07733 ...  90.50964 181.01929 362.0387 ]
    src_ctr_y = src_bbox[:, 0] + 0.5 * src_height   #  compute y_center = y_min + height/2
#    src_ctr_y  (16650,) [  8.   8.   8. ... 584. 584. 584.]
    src_ctr_x = src_bbox[:, 1] + 0.5 * src_width    #  compute x_center = x_min + width/2
#    src_ctr_x  (16650,) [  8.   8.   8. ... 792. 792. 792.]



    # Select height, width, center-y, center-x PREDICTED of each anchor BOX --------------------------------------------------------------
    dy = loc[:, 0::4]   # predicted y by image & CNN (get element at every 4x position, starting from 0 in list of 4 elements . Here, we take only the fist element predicted y)
#    dy  (16650, 1) 
#    [[ 0.03109254]
#     [-0.01841378]
#     [-0.03330704]
#     ...
#     [ 0.02140935]
#     [-0.02889876]
#     [ 0.01432629]]
    dx = loc[:, 1::4]   # predicted x by image & CNN 
#    dx  (16650, 1) 
#    [[ 0.01648028]
#     [-0.00119185]
#     [-0.02837169]
#     ...
#     [ 0.0101308 ]
#     [ 0.01333712]
#     [ 0.00619125]]
    dh = loc[:, 2::4]   # predicted height by image & CNN 
#    dh  (16650, 1) 
#    [[ 0.00398883]
#     [ 0.01245641]
#     [-0.03154986]
#     ...
#     [ 0.00046712]
#     [ 0.01700273]
#     [-0.05782509]]
    dw = loc[:, 3::4]   # predicted width by image & CNN 
#    dw  (16650, 1) 
#    [[-0.04307193]
#     [-0.02187549]
#     [ 0.08170885]
#     ...
#     [-0.06726369]
#     [ 0.02914027]
#     [ 0.00029537]]


    #  Compute NEW Bounding-box PROPOSAL for each anchor BOXES :  e.g. new predicted center-y based on (small value predicted dy, src_height of the concerned anchor BOX, src_center_y of the concerned anchor BOX) -------------------------
    ctr_y = dy * src_height[:, xp.newaxis] + src_ctr_y[:, xp.newaxis]          # new predicted center_y  = predicted dy * FIXED GENERATED height + FIXED GENERATED center_y              # dy, dx, dh, dw are SMALL -> need to multiply by real Y, X, HEIGHT, WIDTH values or take exponential to get LARGE coordinate values
#    ctr_y  (16650, 1) 
#    [[ 10.814176 ]
#     [  4.666749 ]
#     [ -4.0584373]
#     ...
#     [587.8755   ]
#     [573.53754  ]
#     [594.37335  ]]
    ctr_x = dx * src_width[:, xp.newaxis] + src_ctr_x[:, xp.newaxis]           # new predicted center_x  = predicted dx * FIXED GENERATED width + FIXED GENERATED center_x
#    ctr_x  (16650, 1) 
#    [[ 10.98325 ]
#     [  7.568503]
#     [-12.543299]
#     ...
#     [792.91693 ]
#     [794.41425 ]
#     [794.24146 ]]
    h = xp.exp(dh) * src_height[:, xp.newaxis]                                 # new predicted height = exp( predicted dheight ) * FIXED GENERATED height
#    h  (16650, 1) 
#    [[ 90.87142]
#     [183.2883 ]
#     [350.79468]
#     ...
#     [181.10388]
#     [368.24698]
#     [683.3951 ]]
    w = xp.exp(dw) * src_width[:, xp.newaxis]                                  # new predicted width = exp( predicted dwidth ) * FIXED GENERATED width
#    w  (16650, 1) 
#    [[173.38802 ]
#     [354.2049  ]
#     [785.72516 ]
#     ...
#     [ 84.621864]
#     [186.37186 ]
#     [362.14563 ]]

    # Convert back NEW predicted bbox coordinates (center-y, center-x, height, width) to format (y-min, x-min, y-max, x-max)
    dst_bbox = xp.zeros(loc.shape, dtype=loc.dtype)
    dst_bbox[:, 0::4] = ctr_y - 0.5 * h   #  set back to y-min bbox
    dst_bbox[:, 1::4] = ctr_x - 0.5 * w   #  set back to x-min bbox 
    dst_bbox[:, 2::4] = ctr_y + 0.5 * h   #  set back to y-max bbox
    dst_bbox[:, 3::4] = ctr_x + 0.5 * w   #  set back to x-max bbox
    
#    dst_bbox  (16650, 4)    :  new bounding-box coordinates : adjust the hard-coded anchor list (16650, 4) by the corresponding small bbox coordinates values predicted by Image & CNN 
#    [[ -34.621536  -75.710754   56.249886   97.67726 ]
#     [ -86.9774   -169.53395    96.3109    184.67094 ]
#     [-179.45578  -405.40588   171.3389    380.31927 ]
#     ...
#     [ 497.32355   750.606     678.4274    835.22784 ]
#     [ 389.41406   701.22833   757.661     887.60016 ]
#     [ 252.67581   613.16864   936.0709    975.3143  ]]

    return dst_bbox


def bbox2loc(src_bbox, dst_bbox):
    """Encodes the source and the destination bounding boxes to "loc".

    Given bounding boxes, this function computes offsets and scales
    to match the source bounding boxes to the target bounding boxes.
    Mathematcially, given a bounding box whose center is
    :math:`(y, x) = p_y, p_x` and
    size :math:`p_h, p_w` and the target bounding box whose center is
    :math:`g_y, g_x` and size :math:`g_h, g_w`, the offsets and scales
    :math:`t_y, t_x, t_h, t_w` can be computed by the following formulas.

    * :math:`t_y = \\frac{(g_y - p_y)} {p_h}`
    * :math:`t_x = \\frac{(g_x - p_x)} {p_w}`
    * :math:`t_h = \\log(\\frac{g_h} {p_h})`
    * :math:`t_w = \\log(\\frac{g_w} {p_w})`

    The output is same type as the type of the inputs.
    The encoding formulas are used in works such as R-CNN [#]_.

    .. [#] Ross Girshick, Jeff Donahue, Trevor Darrell, Jitendra Malik. \
    Rich feature hierarchies for accurate object detection and semantic \
    segmentation. CVPR 2014.

    Args:
        src_bbox (array): An image coordinate array whose shape is
            :math:`(R, 4)`. :math:`R` is the number of bounding boxes.
            These coordinates are
            :math:`p_{ymin}, p_{xmin}, p_{ymax}, p_{xmax}`.
        dst_bbox (array): An image coordinate array whose shape is
            :math:`(R, 4)`.
            These coordinates are
            :math:`g_{ymin}, g_{xmin}, g_{ymax}, g_{xmax}`.

    Returns:
        array:
        Bounding box offsets and scales from :obj:`src_bbox` \
        to :obj:`dst_bbox`. \
        This has shape :math:`(R, 4)`.
        The second axis contains four values :math:`t_y, t_x, t_h, t_w`.

    """

#       BOUNDING-BOX REGRESSOR (compute the difference dcenter_x, dcenter_y, dheight, dwidth between 128 PREDICTED SAMPLE or FIXED ANCHOR BBOX w.r.t GROUND-TRUTH BBOX)
#
#       (y-min, x-min, y-max, x-max)
#
#        src_bbox: sample_roi (128, 4)                          # [128, 4] 4 coordinates of 128 PREDICTED POSITIVE (OBJECTS) and NEGATIVE BBOX SAMPLES (BACKGROUND) from Max 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI)     or ALL FIXED anchor bbox inside the height width limit (5834, 4)  
#        [[383.26605   377.29407   600.        559.4009   ]
#         [435.51804   455.8985    600.        540.8511   ]
#         [407.90097   321.36078   600.        561.5512   ]
#         [321.29504   308.42358   453.60413   433.7323   ]
#         [339.50854   326.33182   470.59094   450.54117  ]
#         [416.9333    372.28577   524.9664    529.8954   ]
#         [411.02887   400.4822    600.        588.9612   ]
#         [308.80002   329.6       476.80002   416.       ]
#         [420.80002   396.8       593.60004   537.6      ]
#         [336.89325   255.24194   472.21466   378.19446  ]
#         [336.        283.2       540.8       380.8      ]
#         ...

#        dst_bbox: bbox[gt_assignment[keep_index]] (128, 4)     # [128, 4] 4 coordinates of corresponding GROUND-TRUTH BBOX (for both POSITIVE OBJECTS 1/4 and NEGATIVE BACKGROUND 3/4 bbox) or ALL corresponding ground-truth bbox of ALL FIXED anchor bbox (5834, 4) 
#        [[420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [308.80002 329.6     476.80002 416.     ]
#         [308.80002 329.6     476.80002 416.     ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [308.80002 329.6     476.80002 416.     ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [336.      283.2     540.8     380.8    ]
#         [336.      283.2     540.8     380.8    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         ...

    # Compute height, weight, center-y, center-x of 128 PREDICTED POSITIVE and NEGATIVE BBOX (or ALL FIXED anchor bbox) ------------------------------------------------
    height = src_bbox[:, 2] - src_bbox[:, 0]
    width = src_bbox[:, 3] - src_bbox[:, 1]
    ctr_y = src_bbox[:, 0] + 0.5 * height
    ctr_x = src_bbox[:, 1] + 0.5 * width

    # 
    eps = xp.finfo(height.dtype).eps    # numpy.finfo(dtype) : Machine limits for floating point types.   , eps: 1.1920929e-07
    height = xp.maximum(height, eps)    # clip all NEGATIVE HEIGHT values of 128 SAMPLES to 0 
    width = xp.maximum(width, eps)      # clip all NEGATIVE WIDTH values of 128 SAMPLES to 0 
    
    # Compute height, weight, center-y, center-x of 128 CORRESPONDING GROUND-TRUTH BBOX (or ALL corresponding ground-truth bbox of ALL FIXED anchor bbox) -----------------------------------
    base_height = dst_bbox[:, 2] - dst_bbox[:, 0]
    base_width = dst_bbox[:, 3] - dst_bbox[:, 1]
    base_ctr_y = dst_bbox[:, 0] + 0.5 * base_height
    base_ctr_x = dst_bbox[:, 1] + 0.5 * base_width

    #
    dy = (base_ctr_y - ctr_y) / height  # dy = (GROUND-TRUTH center_y - predicted sample center_y) / predicted sample height      # divide by sample height to get SMALL dy value (similarly log)
    dx = (base_ctr_x - ctr_x) / width   # dx = (GROUND-TRUTH center_x - predicted sample center_x) / predicted sample width
    dh = xp.log(base_height / height)   # dh = log( GROUND-TRUTH height / predicted sample height )
    dw = xp.log(base_width / width)     # dw = log( GROUND-TRUTH width / predicted sample width )

    loc = xp.vstack((dy, dx, dh, dw)).transpose()
    
#    loc (128, 4)                       # difference dcenter_y, dcenter_x, dheight, dwidth between ground-truth and predicted sample bbox (or ALL FIXED anchor bbox)
#    [[ 7.18253255e-02 -6.30120002e-03 -2.26535559e-01 -2.57253051e-01]
#     [-6.41956180e-02 -3.66967142e-01  4.93340231e-02  5.05247176e-01]
#     [ 1.69158150e-02  1.07181571e-01 -1.05876058e-01 -5.34091711e-01]
#     [ 4.04388979e-02  1.37424273e-02  2.38823220e-01 -3.71792853e-01]
#     [-9.34505761e-02 -1.25888303e-01  2.48137847e-01 -3.62980872e-01]
#     [ 3.35547060e-01  1.02210805e-01  4.69697475e-01 -1.12780832e-01]
#     [ 8.91976152e-03 -1.46019995e-01 -8.94592851e-02 -2.91646093e-01]
#     [ 0.00000000e+00  0.00000000e+00  0.00000000e+00  0.00000000e+00]
#     [ 0.00000000e+00  0.00000000e+00  0.00000000e+00  0.00000000e+00]
#     [ 2.50115931e-01  1.24290258e-01  4.14381027e-01 -2.30920985e-01]
    
    return loc


def bbox_iou(bbox_a, bbox_b):  # TODO: check
    """Calculate the Intersection of Unions (IoUs) between bounding boxes.

    IoU is calculated as a ratio of area of the intersection
    and area of the union.

    This function accepts both :obj:`numpy.ndarray` and :obj:`cupy.ndarray` as
    inputs. Please note that both :obj:`bbox_a` and :obj:`bbox_b` need to be
    same type.
    The output is same type as the type of the inputs.

    Args:
        bbox_a (array): An array whose shape is :math:`(N, 4)`.
            :math:`N` is the number of bounding boxes.
            The dtype should be :obj:`numpy.float32`.
        bbox_b (array): An array similar to :obj:`bbox_a`,
            whose shape is :math:`(K, 4)`.
            The dtype should be :obj:`numpy.float32`.

    Returns:
        array:
        An array whose shape is :math:`(N, K)`. \
        An element at index :math:`(n, k)` contains IoUs between \
        :math:`n` th bounding box in :obj:`bbox_a` and :math:`k` th bounding \
        box in :obj:`bbox_b`.

    """

#        bbox_a = ROI (scaled) bbox [1724 + 3 below, 4]                        # MAX 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI) with HIGHEST PREDICTED objectness scores & Non-redundant via NMS x  4 corresponding coordinates  . NOTE: maximum is 2000, due to randomness, it can be less (1940 for ex)
#        [[  0.        42.739    528.5074   376.7633  ]
#         [283.63934    0.       420.3711   103.96875 ]
#         [ 56.598816   0.       405.03427  668.30994 ]
#         ...
#         [446.4488   353.54617  600.       440.49185 ]
#         [287.0526   375.04297  378.7989   551.0982  ]
#         [282.63702  578.0259   410.42755  710.7428  ]]
#  +
#        [[336.0000, 283.2000, 540.8000, 380.8000],
#         [420.8000, 396.8000, 593.6000, 537.6000],
#         [308.8000, 329.6000, 476.8000, 416.0000]] 

#        bbox_b = bbox: [number ground-truth bbox, 4 coordinates]              # ground-truth (rescaled) bounding-box 
#        tensor([[336.0000, 283.2000, 540.8000, 380.8000],
#                [420.8000, 396.8000, 593.6000, 537.6000],
#                [308.8000, 329.6000, 476.8000, 416.0000]], device='cuda:0')    

    if bbox_a.shape[1] != 4 or bbox_b.shape[1] != 4:
        raise IndexError

    # top left bbox coordinates (y-min, x-min)
    tl = xp.maximum(bbox_a[:, None, :2], bbox_b[:, :2])   # GET INTERSECTED Y-MIN, X-MIN each ground-truth with each predicted bbox: broadcast ALL GROUND-TRUTH (scaled) bbox to EACH PREDICTED BBOX, get predicted bbox starting from ground-truth bbox (take MAX y-min, MAX x-min coordinates)

#    bbox_a[:, None, :2] (1727, 1, 2) 
#    [[[  0.        42.739   ]]
#     [[283.63934    0.      ]]
#     [[ 56.598816   0.      ]]
#     ...
#     [[336.       283.2     ]]
#     [[420.80002  396.8     ]]
#     [[308.80002  329.6     ]]]
#
#    bbox_b[:, :2] (3, 2) 
#    [[336.      283.2    ]              
#     [420.80002 396.8    ]              
#     [308.80002 329.6    ]]
#
#
#    tl (1727, 3, 2) 
#    [[[336.      283.2    ]
#      [420.80002 396.8    ]
#      [308.80002 329.6    ]]
#    
#     [[336.      283.2    ]
#      [420.80002 396.8    ]
#      [308.80002 329.6    ]]
#    
#     [[336.      283.2    ]
#      [420.80002 396.8    ]
#      [308.80002 329.6    ]]
#    
#     ...
#    
#     [[336.      283.2    ]
#      [420.80002 396.8    ]
#      [336.      329.6    ]]
#    
#     [[420.80002 396.8    ]
#      [420.80002 396.8    ]
#      [420.80002 396.8    ]]
#    
#     [[336.      329.6    ]
#      [420.80002 396.8    ]
#      [308.80002 329.6    ]]]    
    
    # bottom right bbox coordinates (y-max, x-max)
    br = xp.minimum(bbox_a[:, None, 2:], bbox_b[:, 2:])  # GET INTERSECTED Y-MAX, X-MAX each ground-truth with each predicted bbox: broadcast ALL GROUND-TRUTH (scaled) bbox to EACH PREDICTED BBOX, take MAX y-min, x-max coordinates, get predicted bbox ending from ground-truth bbox backwards (take MIN y-max, MIN x-max coordinates)

#    bbox_a[:, None, 2:] (1727, 1, 2) 
#    [[[528.5074  376.7633 ]]
#     [[420.3711  103.96875]]
#     [[405.03427 668.30994]]
#     ...
#     [[540.8     380.8    ]]
#     [[593.60004 537.6    ]]
#     [[476.80002 416.     ]]]
#     
#    bbox_b[:, 2:] (3, 2) 
#    [[540.8     380.8    ]
#     [593.60004 537.6    ]
#     [476.80002 416.     ]]
#     
#     
#    br (1727, 3, 2) 
#    [[[528.5074  376.7633 ]
#      [528.5074  376.7633 ]
#      [476.80002 376.7633 ]]
#    
#     [[420.3711  103.96875]
#      [420.3711  103.96875]
#      [420.3711  103.96875]]
#    
#     [[405.03427 380.8    ]
#      [405.03427 537.6    ]
#      [405.03427 416.     ]]
#    
#     ...
#    
#     [[540.8     380.8    ]
#      [540.8     380.8    ]
#      [476.80002 380.8    ]]
#    
#     [[540.8     380.8    ]
#      [593.60004 537.6    ]
#      [476.80002 416.     ]]
#    
#     [[476.80002 380.8    ]
#      [476.80002 416.     ]
#      [476.80002 416.     ]]]
    
    area_i = xp.prod(br - tl, axis=2) * (tl < br).all(axis=2)

#    xp.prod(br - tl, axis=2) (1727, 3)                 # 1727 INTERSECTED PREDICTED bbox x 3 GROUND-TRUTH bbox area (= height (min y_max intersected - max y_min intersected) * width (min x_max intersected - max x_min intersected) )
#    [[ 18011.625    -2158.0984    7923.4346 ]
#     [-15121.9375     125.60251 -25173.922  ]
#     [  6737.743    -2219.817     8314.639  ]
#     ...
#     [ 19988.475    -1919.9995    7208.9585 ]
#     [ -1919.9995   24330.24      1075.2007 ]
#     [  7208.9585    1075.2007   14515.199  ]]
#
#    (tl < br).all(axis=2) (1727, 3)                    # INTERSECTED bounding box is non-zero (min y_max intersected < max y_min intersected AND min x_max intersected < max x_min intersected)
#    [[ True False  True]
#     [False False False]
#     [ True False  True]
#     ...
#     [ True False  True]
#     [False  True  True]
#     [ True  True  True]]
#     
#    area_i (1727, 3)                                   # areas of intersected bbox (ground-truth & predicted bbox)
#    [[18011.625     -0.      7923.4346]
#     [   -0.         0.        -0.    ]
#     [ 6737.743     -0.      8314.639 ]
#     ...
#     [19988.475     -0.      7208.9585]
#     [   -0.     24330.24    1075.2007]
#     [ 7208.9585  1075.2007 14515.199 ]]
    
    area_a = xp.prod(bbox_a[:, 2:] - bbox_a[:, :2], axis=1)
    area_b = xp.prod(bbox_b[:, 2:] - bbox_b[:, :2], axis=1)
    
#    area_a (1727,)                                     # areas of each predicted bbox (= height * width)
#    [176534.31   14215.829 232862.88  ...  19988.475  24330.24   14515.199]
#
#    area_b (3,)                                        # areas of each ground-truth bbox (= height * width) 
#    [19988.475 24330.24  14515.199]
    

#    area_a[:, None] (1727, 1) 
#
#    [[176534.31 ]
#     [ 14215.829]
#     [232862.88 ]
#     ...
#     [ 19988.475]
#     [ 24330.24 ]
#     [ 14515.199]]
#     
#    area_a[:, None] + area_b (1727, 3)                          # union area of bbox (each predicted bbox with each ground-truth bbox) via broadcasting  (if they're not overlapped : at the last step, ratio will be zero)
#
#    [[196522.78  200864.55  191049.52 ]
#     [ 34204.305  38546.07   28731.027]
#     [252851.34  257193.11  247378.08 ]
#     ...
#     [ 39976.95   44318.715  34503.67 ]
#     [ 44318.715  48660.48   38845.438]
#     [ 34503.67   38845.438  29030.398]]
#     
#    area_a[:, None] + area_b - area_i (1727, 3)                 # RIGHT union area = union area - intersected area (JUST 1 TIME) via substracting element-by-element
#
#    [[178511.16  200864.55  183126.08 ]
#     [ 34204.305  38546.07   28731.027]
#     [246113.6   257193.11  239063.44 ]
#     ...
#     [ 19988.475  44318.715  27294.713]
#     [ 44318.715  24330.24   37770.24 ]
#     [ 27294.713  37770.24   14515.199]]
#     
#    area_i / (area_a[:, None] + area_b - area_i) (1727, 3)      # IoU ratio = intersected area / RIGHT union area
#
#    [[ 0.10089915 -0.          0.04326765]
#     [-0.          0.         -0.        ]
#     [ 0.02737656 -0.          0.03478005]
#     ...
#     [ 1.         -0.          0.26411557]
#     [-0.          1.          0.02846688]
#     [ 0.26411557  0.02846688  1.        ]]
    
    return area_i / (area_a[:, None] + area_b - area_i)


def __test():
    pass


if __name__ == '__main__':
    __test()


def generate_anchor_base(base_size=16, ratios=[0.5, 1, 2],
                         anchor_scales=[8, 16, 32]):
    """Generate anchor base windows by enumerating aspect ratio and scales.

    Generate anchors that are scaled and modified to the given aspect ratios.
    Area of a scaled anchor is preserved when modifying to the given aspect
    ratio.

    :obj:`R = len(ratios) * len(anchor_scales)` anchors are generated by this
    function.
    The :obj:`i * len(anchor_scales) + j` th anchor corresponds to an anchor
    generated by :obj:`ratios[i]` and :obj:`anchor_scales[j]`.

    For example, if the scale is :math:`8` and the ratio is :math:`0.25`,
    the width and the height of the base window will be stretched by :math:`8`.
    For modifying the anchor to the given aspect ratio,
    the height is halved and the width is doubled.

    Args:
        base_size (number): The width and the height of the reference window.
        ratios (list of floats): This is ratios of width to height of
            the anchors.
        anchor_scales (list of numbers): This is areas of anchors.
            Those areas will be the product of the square of an element in
            :obj:`anchor_scales` and the original area of the reference
            window.

    Returns:
        ~numpy.ndarray:
        An array of shape :math:`(R, 4)`.
        Each element is a set of coordinates of a bounding box.
        The second axis corresponds to
        :math:`(y_{min}, x_{min}, y_{max}, x_{max})` of a bounding box.

    """
    # https://medium.com/@fractaldle/guide-to-build-faster-rcnn-in-pytorch-95b10c273439
    # each pixel in the feature map corresponds to 16x16 pixels (subsampling ratio) in the original image
    # we need to create 9 anchor boxes on all pixels of the feature map
    # Let's fill these values with corresponding y1, x1, y2, x2 at each anchor_scale and ratios. 
    # Our center for this base anchor will be at
    py = base_size / 2.  # center-y height = sub_sampling ratio / 2  . why don't we start at the origin point (0, 0) ? Does it really matter ?
    px = base_size / 2.  # center-x width = sub_sampling ratio / 2

    anchor_base = np.zeros((len(ratios) * len(anchor_scales), 4), dtype=np.float32)              # [9 anchor boxes, 4 coordinates x-min y-min x-max y-max]
                           
    for i in six.moves.range(len(ratios)): # six.moves : compatiable version for Python2 and Python3 functions.
        for j in six.moves.range(len(anchor_scales)):
            h = base_size * anchor_scales[j] * np.sqrt(ratios[i])        # where does come from this formula ?
            w = base_size * anchor_scales[j] * np.sqrt(1. / ratios[i])

            index = i * len(anchor_scales) + j
            anchor_base[index, 0] = py - h / 2. # top-left y (height)
            anchor_base[index, 1] = px - w / 2. # top-left x (width)
            anchor_base[index, 2] = py + h / 2. # right-bottom y
            anchor_base[index, 3] = px + w / 2. # right-bottom x
            
    return anchor_base

# anchor_base : hard-coded 9 anchor boxes (with 4 coordinates) at the first feature map pixel for VGG16 (with subsampling ratio = 16).
# Note 1: if we use another backbone deep CNN network, we need to change the subsampling ratio of anchor_base coordinates correspondingly.
# Note 2: Negative values mean that the anchor boxes are outside image dimension. 
# In the later section we will label them with -1 and remove them when calculating the loss the functions and generating proposals for anchor boxes
#
# array([[ -37.254833,  -82.50967 ,   53.254833,   98.50967 ],  # size H*W : 90  x 181 - wide bbox   : not very small bbox ! (intersection these bbox with border + bounding-box regressor will adapt these bbox to the variant object size)
#        [ -82.50967 , -173.01933 ,   98.50967 ,  189.01933 ],  # size H*W : 181 x 362 - wide bbox
#        [-173.01933 , -354.03867 ,  189.01933 ,  370.03867 ],  # size H*W : 362 x 724 - wide bbox   : very large bbox, this bbox can cover entire image if necessary
#        [ -56.      ,  -56.      ,   72.      ,   72.      ],  # size H*W : 128 x 128   - squared bbox
#        [-120.      , -120.      ,  136.      ,  136.      ],  # size H*W : 256 x 256   - squared bbox
#        [-248.      , -248.      ,  264.      ,  264.      ],  # size H*W : 512 x 512   - squared bbox
#        [ -82.50967 ,  -37.254833,   98.50967 ,   53.254833],  # size H*W : 181 x 90      - tall bbox
#        [-173.01933 ,  -82.50967 ,  189.01933 ,   98.50967 ],  # size H*W : 362 x 181     - tall bbox
#        [-354.03867 , -173.01933 ,  370.03867 ,  189.01933 ]], # size H*W : 724 x 362     - tall bbox
#       dtype=float32)