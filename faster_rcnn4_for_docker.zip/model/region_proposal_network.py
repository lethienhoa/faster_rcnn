import numpy as np
from torch.nn import functional as F
import torch as t
from torch import nn

from model.utils.bbox_tools import generate_anchor_base
from model.utils.creator_tool import ProposalCreator


class RegionProposalNetwork(nn.Module):
    """Region Proposal Network introduced in Faster R-CNN.

    This is Region Proposal Network introduced in Faster R-CNN [#]_.
    This takes features extracted from images and propose
    class agnostic bounding boxes around "objects".

    .. [#] Shaoqing Ren, Kaiming He, Ross Girshick, Jian Sun. \
    Faster R-CNN: Towards Real-Time Object Detection with \
    Region Proposal Networks. NIPS 2015.

    Args:
        in_channels (int): The channel size of input.
        mid_channels (int): The channel size of the intermediate tensor.
        ratios (list of floats): This is ratios of width to height of
            the anchors.
        anchor_scales (list of numbers): This is areas of anchors.
            Those areas will be the product of the square of an element in
            :obj:`anchor_scales` and the original area of the reference
            window.
        feat_stride (int): Stride size after extracting features from an
            image.
        initialW (callable): Initial weight value. If :obj:`None` then this
            function uses Gaussian distribution scaled by 0.1 to
            initialize weight.
            May also be a callable that takes an array and edits its values.
        proposal_creator_params (dict): Key valued paramters for
            :class:`model.utils.creator_tools.ProposalCreator`.

    .. seealso::
        :class:`~model.utils.creator_tools.ProposalCreator`

    """

    def __init__(  # in_channels = 512 : output of VGG16
            self, in_channels=512, mid_channels=512, ratios=[0.5, 1, 2],
            anchor_scales=[8, 16, 32], feat_stride=16,  # feat_stride : subsampling ratio 16 (from original raw image -> output feature map by VGG16)
            proposal_creator_params=dict(),
    ):
        super(RegionProposalNetwork, self).__init__()
        
        self.anchor_base = generate_anchor_base(                                 # [9 anchor boxes, 4 coordinates] : creation of anchor locations at the FIRST feature map pixel
            anchor_scales=anchor_scales, ratios=ratios)
        
#        anchor_base : hard-coded 9 anchor boxes (with 4 coordinates) at the first feature map pixel for VGG16 (with subsampling ratio = 16).
#        Note 1: if we use another backbone deep CNN network, we need to change the subsampling ratio of anchor_base coordinates correspondingly.
#        Note 2: Negative values mean that the anchor boxes are outside image dimension. 
#        In the later section we will label them with -1 and remove them when calculating the loss the functions and generating proposals for anchor boxes
#
#         array([[ -37.254833,  -82.50967 ,   53.254833,   98.50967 ],  # size H*W : 90  x 181 - wide bbox   : not very small bbox ! (intersection these bbox with border + bounding-box regressor will adapt these bbox to the variant object size)
#                [ -82.50967 , -173.01933 ,   98.50967 ,  189.01933 ],  # size H*W : 181 x 362 - wide bbox
#                [-173.01933 , -354.03867 ,  189.01933 ,  370.03867 ],  # size H*W : 362 x 724 - wide bbox   : very large bbox, this bbox can cover entire image if necessary
#                [ -56.      ,  -56.      ,   72.      ,   72.      ],  # size H*W : 128 x 128   - squared bbox
#                [-120.      , -120.      ,  136.      ,  136.      ],  # size H*W : 256 x 256   - squared bbox
#                [-248.      , -248.      ,  264.      ,  264.      ],  # size H*W : 512 x 512   - squared bbox
#                [ -82.50967 ,  -37.254833,   98.50967 ,   53.254833],  # size H*W : 181 x 90      - tall bbox
#                [-173.01933 ,  -82.50967 ,  189.01933 ,   98.50967 ],  # size H*W : 362 x 181     - tall bbox
#                [-354.03867 , -173.01933 ,  370.03867 ,  189.01933 ]], # size H*W : 724 x 362     - tall bbox
#               dtype=float32)    
        
        self.proposal_layer = ProposalCreator(self, **proposal_creator_params)   # control number of bounding boxes to pass to NMS and keep after NMS

        self.feat_stride = feat_stride
        n_anchor = self.anchor_base.shape[0] # k = 9  
        
        # nn.Conv2d (in_channels, out_channels, kernel_size - size of the convolving kernel, stride of the convolution, padding - zero-padding added to both sides of the input)
        self.conv1 = nn.Conv2d(in_channels , mid_channels, 3, 1, 1)              # conv1 layer 3x3 to predict objectness score (2 classes) and bounding box (4 coordinates) 
        self.score = nn.Conv2d(mid_channels, n_anchor * 2, 1, 1, 0)              # predict objectness score (2 classes) 
        self.loc   = nn.Conv2d(mid_channels, n_anchor * 4, 1, 1, 0)              # predict bounding box (4 coordinates) 
        normal_init(self.conv1, 0, 0.01)
        normal_init(self.score, 0, 0.01)
        normal_init(self.loc, 0, 0.01)

    def forward(self, x, img_size, scale=1.):
        """Forward Region Proposal Network.

        Here are notations.

        * :math:`N` is batch size.
        * :math:`C` channel size of the input.
        * :math:`H` and :math:`W` are height and witdh of the input feature.
        * :math:`A` is number of anchors assigned to each pixel.

        Args:
            x (~torch.autograd.Variable): The Features extracted from images.
                Its shape is :math:`(N, C, H, W)`.
            img_size (tuple of ints): A tuple :obj:`height, width`,
                which contains image size after scaling.
            scale (float): The amount of scaling done to the input images after
                reading them from files.

        Returns:
            (~torch.autograd.Variable, ~torch.autograd.Variable, array, array, array):

            This is a tuple of five following values.

            * **rpn_locs**: Predicted bounding box offsets and scales for \
                anchors. Its shape is :math:`(N, H W A, 4)`.
            * **rpn_scores**:  Predicted foreground scores for \
                anchors. Its shape is :math:`(N, H W A, 2)`.
            * **rois**: A bounding box array containing coordinates of \
                proposal boxes.  This is a concatenation of bounding box \
                arrays from multiple images in the batch. \
                Its shape is :math:`(R', 4)`. Given :math:`R_i` predicted \
                bounding boxes from the :math:`i` th image, \
                :math:`R' = \\sum _{i=1} ^ N R_i`.
            * **roi_indices**: An array containing indices of images to \
                which RoIs correspond to. Its shape is :math:`(R',)`.
            * **anchor**: Coordinates of enumerated shifted anchors. \
                Its shape is :math:`(H W A, 4)`.

        """
        n, _, hh, ww = x.shape               #   n: batch_size=1, 512 channel feature map obtained by VGG16, hh and ww of the feature map (37 x 50 e.g.)
        
        # anchor_base : only 9 anchor locations at the first feature map pixel ----------------------------------------------------------
        # anchor : all (fixed) generated coordinates of anchors BOXES at each feature map location (VGG dim output feature map ~ 37 * 50 e.g) * (9 anchor boxes at each feature map pixel projected on raw input image) = ~ 22500 anchor boxes
        anchor = _enumerate_shifted_anchor(                                    # (37 * 50 * 9 = 16650 anchor boxes, 4 coordinates)                               
            np.array(self.anchor_base),
            self.feat_stride, hh, ww)

#        anchor  (16650, 4)                                                    # 37 * 50 * 9 = 16650 anchor BOXES
#        1850 anchor POINTS (37 * 50) * 9 anchor BOXES at each point, ordered SEQUENTIALLY (from left to right, top to bottom, each position has 9 anchor BOXES)
#         [[ -37.254833  -82.50967    53.254833   98.50967 ]
#         [ -82.50967  -173.01933    98.50967   189.01933 ]
#         [-173.01933  -354.03867   189.01933   370.03867 ]
#         ...
#         [ 493.49033   746.7452    674.50964   837.2548  ]
#         [ 402.98065   701.49036   765.01935   882.50964 ]
#         [ 221.96133   610.98065   946.0387    973.01935 ]]

        # h : representation obtained by applying CNN 3x3 ON FEATURE MAP for predicting objectness & bounding-box -----------------------------------------
        n_anchor = anchor.shape[0] // (hh * ww)   #  n_anchor = 9
        h = F.relu(self.conv1(x))                 #  h has the same W*H shape as x : torch.Size([1, 512, 37, 50]) because 3x3 convolution with stride = 1 and padding = 1 on both height and width  +  use 512 channel features
        
        # Use image + CNN (9 * 4 CHANNEL FEATURES) to predict 4 INCREMENTAL (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) coordinates at each anchor POINTS 37 * 50 ------------------------
        rpn_locs = self.loc(h)                    #  torch.Size([1, 36 channel features = 9 anchor boxes * 4 coordinates, 37 height, 50 width])   : conv 1x1, stride = 1 and no padding -> height, width are the same
        rpn_locs = rpn_locs.permute(0, 2, 3, 1).contiguous().view(n, -1, 4)    #  rpn_locs.permute(0, 2, 3, 1) : torch.Size([1, 37, 50, 36])   , after view : torch.Size([1, 16650, 4])  

#        There are 37 (output Height of VGG16) * 50 (output Width of VGG16) * 9 (anchors boxes at each feature map point) = 16650 anchor boxes in total
#        rpn_locs  torch.Size([1, 16650, 4])                                   # 4 coordinates of each anchor point
#           tensor([[[ 1.0164e-02, -8.5225e-02, -1.6837e-03, -8.4621e-03],
#                 [-1.1096e-02,  4.1846e-02,  2.9004e-02, -2.2258e-02],
#                 [-1.2302e-05,  1.5893e-02,  9.9560e-04, -2.6399e-02],
#                 ...,
#                 [-1.1011e-02,  4.7739e-03, -8.5138e-03, -9.6025e-03],
#                 [-2.1682e-02,  7.7298e-03,  2.0266e-03,  9.3305e-03],
#                 [-3.1961e-04,  8.2755e-03, -2.9834e-03, -3.8120e-03]]],
#               device='cuda:0', grad_fn=<ViewBackward>)
        

        # Use image + CNN (9 * 2 CHANNEL FEATURES) to predict 2 classes objectness (1: object, 0: not object) at each anchor POINTS 37 * 50 --------------------------------
        rpn_scores = self.score(h)                # torch.Size([1, 18 channel features = 9 anchor boxes * 2 classes objectness or not, 37 height, 50 width])   : conv 1x1, stride = 1 and no padding -> height, width are the same
        rpn_scores = rpn_scores.permute(0, 2, 3, 1).contiguous()             #  rpn_scores  torch.Size([1, 37, 50, 18])           #  permuate() is like transpose(): moreover, we can swap not just 2 but all dimensions (https://jdhao.github.io/2019/07/10/pytorch_view_reshape_transpose_permute/)

        
        # rpn_fg_scores : compute softmax for rpn_scores
        rpn_softmax_scores = F.softmax(rpn_scores.view(n, hh, ww, n_anchor, 2), dim=4)
        rpn_fg_scores = rpn_softmax_scores[:, :, :, :, 1].contiguous()       #  rpn_fg_scores torch.Size([1, 37, 50, 9])
        rpn_fg_scores = rpn_fg_scores.view(n, -1)                            #  rpn_fg_scores torch.Size([1, 16650])
        
        # return rpn_scores
        rpn_scores = rpn_scores.view(n, -1, 2)   # torch.Size([1, 16650, 2]) 

#        rpn_scores  torch.Size([1, 16650, 2])                               # 2 classes objectness (1: object, 0: not object) of each anchor point
#           tensor([[[ 0.0311,  0.0244],
#                 [-0.0643,  0.0984],
#                 [-0.0117, -0.0406],
#                 ...,
#                 [-0.0293, -0.0084],
#                 [-0.0123, -0.0070],
#                 [-0.0153,  0.0179]]], device='cuda:0', grad_fn=<ViewBackward>)        
        

        #  -----------------------------------------------------------------------------------------------------
        # KEEP at most ~2000 BBOX with HIGHEST PREDICTED objectness score & by applying NMS
        # This is similar to SELECTIVE SEARCH (Faster R-CNN use CNN to replace SS)
        # Use the raw input above to create REAL PROPOSAL BBOX that matches reality's conditions
        rois = list()
        roi_indices = list()
        for i in range(n):  # visit each image in the batch (batch_size = 1 here)
            roi = self.proposal_layer(
                rpn_locs[i].cpu().data.numpy(),        #  predicted RPN 4 INCREMENTAL (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) box coordinates by CNN : torch.Size([37 height * 50 width * 9 = 16650 anchor BOXES, 4 coordinates])
                rpn_fg_scores[i].cpu().data.numpy(),   #  predicted RPN objectness score by CNN : torch.Size([16650 = 37 * 50 * 9])  objectiveness score
                anchor,                                #  (fixed) list of all anchor BOXES coordinates [37 height * 50 width * 9 = 16650 anchor BOXES, 4 coordinates]
                img_size,                              #  SCALED image size (600 height, 800 width) e.g.
                scale=scale)                           #  scaled ratio of the shorter side (among width, height) of original image to 600 pixels: 1.6 e.g. for this photo (or 1.8,...)
            rois.append(roi)
            #
            batch_index = i * np.ones((len(roi),), dtype=np.int32)
            roi_indices.append(batch_index)

        rois = np.concatenate(rois, axis=0)
        roi_indices = np.concatenate(roi_indices, axis=0)

#        rois  (1724, 4)                                                       # MAX 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI) non-redundant by NMS with highest objectness score  x  4 corresponding coordinates  . NOTE: maximum is 2000, due to randomness, it can be less (1940 for ex)
#        [[  0.        42.739    528.5074   376.7633  ]
#         [283.63934    0.       420.3711   103.96875 ]
#         [ 56.598816   0.       405.03427  668.30994 ]
#         ...
#         [446.4488   353.54617  600.       440.49185 ]
#         [287.0526   375.04297  378.7989   551.0982  ]
#         [282.63702  578.0259   410.42755  710.7428  ]]
#
#        roi_indices  (1724,) [0 0 0 ... 0 0 0]                                # index of image in batch (always the first and unique image - index 0 if batch_size = 1)

        
        return rpn_locs, rpn_scores, rois, roi_indices, anchor


def _enumerate_shifted_anchor(anchor_base, feat_stride, height, width):
    ''' 
        Fast Numpy CPU Matrix Implementation of generating 9 anchor boxes coordinates (from the first position) to all pixel position in the feature map (37 x 50)    
    
        anchor_base : 9 anchor boxes of the first position on the feature map
        feat_stride : 16 (subsampling ratio of VGG16)
        height, width : feature map (e.g. 37 x 50)
    '''
    # https://medium.com/@fractaldle/guide-to-build-faster-rcnn-in-pytorch-95b10c273439
    # Enumerate all shifted anchors:
    #
    # add A anchors (1, A, 4) to          #  A = 9 anchor BOXES at each anchor POINT
    # cell K shifts (K, 1, 4) to get      #  K = 1850 (= 37 * 50) anchor POINTS (on feature map)
    # shift anchors (K, A, 4)             #  (1850, 9, 4 coordinates)
    # reshape to (K*A, 4) shifted anchors
    # return (K*A, 4)                     #  (16650, 4) anchor BOXES

    # !TODO: add support for torch.CudaTensor
    # xp = cuda.get_array_module(anchor_base)
    # it seems that it can't be boosed using GPU
    import numpy as xp
    
    # Prepare all anchor POINTS positions -----------------------------------------------
    # Generate anchor POINTS width & height Vectors of original raw image
    shift_y = xp.arange(0, height * feat_stride, feat_stride)
    shift_x = xp.arange(0, width * feat_stride, feat_stride)

#    shift_y : 37 elements (height)   #  height sliding-window of 16 pixel anchor points correspondingly in the original raw image (height 600 x width 800)
#    array([  0,  16,  32,  48,  64,  80,  96, 112, 128, 144, 160, 176, 192,
#           208, 224, 240, 256, 272, 288, 304, 320, 336, 352, 368, 384, 400,
#           416, 432, 448, 464, 480, 496, 512, 528, 544, 560, 576])   
#
#    shift_x : 50 elements (width)    #  width sliding-window of 16 pixel anchor points correspondingly in the original raw image
#    array([  0,  16,  32,  48,  64,  80,  96, 112, 128, 144, 160, 176, 192,
#           208, 224, 240, 256, 272, 288, 304, 320, 336, 352, 368, 384, 400,
#           416, 432, 448, 464, 480, 496, 512, 528, 544, 560, 576, 592, 608,
#           624, 640, 656, 672, 688, 704, 720, 736, 752, 768, 784])           
    
    # Generate the corresponding anchor POINTS Matrix from shift_y, shift_x
    shift_x, shift_y = xp.meshgrid(shift_x, shift_y)  # Return coordinate matrices from coordinate vectors.
    
#    shift_x  : shape (37, 50)     :  Width 50 element values repeat down 37 rows
#    array([[  0,  16,  32, ..., 752, 768, 784],
#           [  0,  16,  32, ..., 752, 768, 784],
#           [  0,  16,  32, ..., 752, 768, 784],
#           ..., 
#           [  0,  16,  32, ..., 752, 768, 784],
#           [  0,  16,  32, ..., 752, 768, 784],
#           [  0,  16,  32, ..., 752, 768, 784]])
#
#    shift_y  : shape (37, 50)     :  Height 37 element values repeat to the right 50 columns
#    array([[  0,   0,   0, ...,   0,   0,   0],
#           [ 16,  16,  16, ...,  16,  16,  16],
#           [ 32,  32,  32, ...,  32,  32,  32],
#           ..., 
#           [544, 544, 544, ..., 544, 544, 544],
#           [560, 560, 560, ..., 560, 560, 560],
#           [576, 576, 576, ..., 576, 576, 576]])    
    
    # Generate bounding box 4 coordinates of each of 37 * 50 anchor POINTS (disjoint sliding window from raw image to feature map)
    # We list all 37 * 50 anchor POINTS -> (y-min, x-min) = (y-max, x-max) . Then, at each of these anchor POINTS, we will fill 9 anchor BOXES.
    shift = xp.stack((shift_y.ravel(), shift_x.ravel(),
                      shift_y.ravel(), shift_x.ravel()), axis=1)   #  numpy.ravel() : return a contiguous flattened array , equivalent to x.reshape(-1)

#    shift_y.ravel()    :  37 * 50 -> shape (1850, )      
#    array([  0,   0,   0, ..., 576, 576, 576])
#    
#    shift_x.ravel()    :  37 * 50 -> shape (1850, )     
#    array([  0,  16,  32, ..., 752, 768, 784])
#    
#    shift  : shape (1850, 4)
#    array([[  0,   0,   0,   0],            # 4 coordinates of bbox: height y-min, width x-min, y-max, x-max  (with y-min = y-max, x-min = x-max)
#           [  0,  16,   0,  16],
#           [  0,  32,   0,  32],
#           ..., 
#           [576, 752, 576, 752],
#           [576, 768, 576, 768],
#           [576, 784, 576, 784]])

    A = anchor_base.shape[0]  # 9 anchor boxes
    K = shift.shape[0]        # 37 * 50 = 1850 anchor POINTS (from feature map to raw image) 
    anchor = anchor_base.reshape((1, A, 4)) + shift.reshape((1, K, 4)).transpose((1, 0, 2))    # broadcasting anchor_base (9, 4) 1850 times. Each time, take coordinates of 9 anchor BOXES (9, 4) + coordinates of 1 anchor POINT (1, 4)

#    anchor_base.reshape((1, A, 4))                 ->   shape (1, 9, 4)    : 9 anchor BOXES at the first anchor POINT
#    array([[[ -37.25483322,  -82.50966644,   53.25483322,   98.50966644],
#            [ -82.50966644, -173.01933289,   98.50966644,  189.01933289],
#            [-173.01933289, -354.03866577,  189.01933289,  370.03866577],
#            [ -56.        ,  -56.        ,   72.        ,   72.        ],
#            [-120.        , -120.        ,  136.        ,  136.        ],
#            [-248.        , -248.        ,  264.        ,  264.        ],
#            [ -82.50966644,  -37.25483322,   98.50966644,   53.25483322],
#            [-173.01933289,  -82.50966644,  189.01933289,   98.50966644],
#            [-354.03866577, -173.01933289,  370.03866577,  189.01933289]]],
#    
#    shift.reshape((1, K, 4)).transpose((1, 0, 2))  ->   shape (1850, 1, 4)
#    array([[[  0,   0,   0,   0]],
#           [[  0,  16,   0,  16]],
#           [[  0,  32,   0,  32]],
#           ..., 
#           [[576, 752, 576, 752]],
#           [[576, 768, 576, 768]],
#           [[576, 784, 576, 784]]])
#    
#    anchor : shape  (1850, 9, 4)
#    array([[[  -37.25483322,   -82.50966644,    53.25483322,    98.50966644],
#            [  -82.50966644,  -173.01933289,    98.50966644,   189.01933289],
#            [ -173.01933289,  -354.03866577,   189.01933289,   370.03866577],
#            ..., 
#            [  -82.50966644,   -37.25483322,    98.50966644,    53.25483322],
#            [ -173.01933289,   -82.50966644,   189.01933289,    98.50966644],
#            [ -354.03866577,  -173.01933289,   370.03866577,   189.01933289]],
#    
#           [[  -37.25483322,   -66.50966644,    53.25483322,   114.50966644],
#            [  -82.50966644,  -157.01933289,    98.50966644,   205.01933289],
#            [ -173.01933289,  -338.03866577,   189.01933289,   386.03866577],
#            ..., 
#            [  -82.50966644,   -21.25483322,    98.50966644,    69.25483322],
#            [ -173.01933289,   -66.50966644,   189.01933289,   114.50966644],
#            [ -354.03866577,  -157.01933289,   370.03866577,   205.01933289]],
#    
#           [[  -37.25483322,   -50.50966644,    53.25483322,   130.50966644],
#            [  -82.50966644,  -141.01933289,    98.50966644,   221.01933289],
#            [ -173.01933289,  -322.03866577,   189.01933289,   402.03866577],
#            ..., 
#            [  -82.50966644,    -5.25483322,    98.50966644,    85.25483322],
#            [ -173.01933289,   -50.50966644,   189.01933289,   130.50966644],
#            [ -354.03866577,  -141.01933289,   370.03866577,   221.01933289]],
#    
#           ..., 
#           [[  538.74516678,   669.49033356,   629.25483322,   850.50966644],
#            [  493.49033356,   578.98066711,   674.50966644,   941.01933289],
#            [  402.98066711,   397.96133423,   765.01933289,  1122.03866577],
#            ..., 
#            [  493.49033356,   714.74516678,   674.50966644,   805.25483322],
#            [  402.98066711,   669.49033356,   765.01933289,   850.50966644],
#            [  221.96133423,   578.98066711,   946.03866577,   941.01933289]],
#    
#           [[  538.74516678,   685.49033356,   629.25483322,   866.50966644],
#            [  493.49033356,   594.98066711,   674.50966644,   957.01933289],
#            [  402.98066711,   413.96133423,   765.01933289,  1138.03866577],
#            ..., 
#            [  493.49033356,   730.74516678,   674.50966644,   821.25483322],
#            [  402.98066711,   685.49033356,   765.01933289,   866.50966644],
#            [  221.96133423,   594.98066711,   946.03866577,   957.01933289]],
#    
#           [[  538.74516678,   701.49033356,   629.25483322,   882.50966644],
#            [  493.49033356,   610.98066711,   674.50966644,   973.01933289],
#            [  402.98066711,   429.96133423,   765.01933289,  1154.03866577],
#            ..., 
#            [  493.49033356,   746.74516678,   674.50966644,   837.25483322],
#            [  402.98066711,   701.49033356,   765.01933289,   882.50966644],
#            [  221.96133423,   610.98066711,   946.03866577,   973.01933289]]])

        
    anchor = anchor.reshape((K * A, 4)).astype(np.float32)   # 1850 * 9 = 16650 all anchor BOXES

#    anchor  :  shape (16650, 4)      #  all anchor BOXES (1850 anchor POINTS * 9 anchor BOXES at each point) ordered SEQUENTIALLY
#    array([[ -37.25483322,  -82.50966644,   53.25483322,   98.50966644],
#           [ -82.50966644, -173.01933289,   98.50966644,  189.01933289],
#           [-173.01933289, -354.03866577,  189.01933289,  370.03866577],
#           ..., 
#           [ 493.49032593,  746.74517822,  674.50964355,  837.25482178],
#           [ 402.98065186,  701.49035645,  765.01934814,  882.50964355],
#           [ 221.96133423,  610.98065186,  946.03869629,  973.01934814]], dtype=float32)
    
    return anchor
    
    


def normal_init(m, mean, stddev, truncated=False):
    """
    weight initalizer: truncated normal and random normal.
    """
    # x is a parameter
    if truncated:
        m.weight.data.normal_().fmod_(2).mul_(stddev).add_(mean)  # not a perfect approximation
    else:
        m.weight.data.normal_(mean, stddev)
        m.bias.data.zero_()
        

#def _enumerate_shifted_anchor_torch(anchor_base, feat_stride, height, width):
#    # Enumerate all shifted anchors:
#    #
#    # add A anchors (1, A, 4) to
#    # cell K shifts (K, 1, 4) to get
#    # shift anchors (K, A, 4)
#    # reshape to (K*A, 4) shifted anchors
#    # return (K*A, 4)
#
#    # !TODO: add support for torch.CudaTensor
#    # xp = cuda.get_array_module(anchor_base)
#    import torch as t
#    shift_y = t.arange(0, height * feat_stride, feat_stride)
#    shift_x = t.arange(0, width * feat_stride, feat_stride)
#    shift_x, shift_y = xp.meshgrid(shift_x, shift_y)
#    shift = xp.stack((shift_y.ravel(), shift_x.ravel(),
#                      shift_y.ravel(), shift_x.ravel()), axis=1)
#
#    A = anchor_base.shape[0]
#    K = shift.shape[0]
#    anchor = anchor_base.reshape((1, A, 4)) + \
#             shift.reshape((1, K, 4)).transpose((1, 0, 2))
#    anchor = anchor.reshape((K * A, 4)).astype(np.float32)
#    return anchor



