from __future__ import  absolute_import
from __future__ import division
import torch as t
import numpy as np

from torchvision.ops import nms
#    Performs non-maximum suppression (NMS) on the boxes according to their intersection-over-union (IoU).
#    NMS iteratively removes lower scoring boxes which have an IoU greater than iou_threshold with another (higher scoring) box.
# from model.utils.nms import non_maximum_suppression
from torch import nn
from torch.nn import functional as F

from utils import array_tool as at
from utils.config import opt

from model.utils.bbox_tools import loc2bbox  # Decode bounding boxes from bounding box offsets and scales.

from data.dataset import preprocess


def nograd(f):
    def new_f(*args,**kwargs):
        with t.no_grad():
           return f(*args,**kwargs)
    return new_f

class FasterRCNN(nn.Module):
    """Base class for Faster R-CNN.

    This is a base class for Faster R-CNN links supporting object detection
    API [#]_. The following three stages constitute Faster R-CNN.

    1. **Feature extraction**: Images are taken and their \
        feature maps are calculated.
    2. **Region Proposal Networks**: Given the feature maps calculated in \
        the previous stage, produce set of RoIs around objects.
    3. **Localization and Classification Heads**: Using feature maps that \
        belong to the proposed RoIs, classify the categories of the objects \
        in the RoIs and improve localizations.

    Each stage is carried out by one of the callable
    :class:`torch.nn.Module` objects :obj:`feature`, :obj:`rpn` and :obj:`head`.

    There are two functions :meth:`predict` and :meth:`__call__` to conduct
    object detection.
    :meth:`predict` takes images and returns bounding boxes that are converted
    to image coordinates. This will be useful for a scenario when
    Faster R-CNN is treated as a black box function, for instance.
    :meth:`__call__` is provided for a scnerario when intermediate outputs
    are needed, for instance, for training and debugging.

    Links that support obejct detection API have method :meth:`predict` with
    the same interface. Please refer to :meth:`predict` for
    further details.

    .. [#] Shaoqing Ren, Kaiming He, Ross Girshick, Jian Sun. \
    Faster R-CNN: Towards Real-Time Object Detection with \
    Region Proposal Networks. NIPS 2015.

    Args:
        extractor (nn.Module): A module that takes a BCHW image
            array and returns feature maps.
        rpn (nn.Module): A module that has the same interface as
            :class:`model.region_proposal_network.RegionProposalNetwork`.
            Please refer to the documentation found there.
        head (nn.Module): A module that takes
            a BCHW variable, RoIs and batch indices for RoIs. This returns class
            dependent localization paramters and class scores.
        loc_normalize_mean (tuple of four floats): Mean values of
            localization estimates.
        loc_normalize_std (tupler of four floats): Standard deviation
            of localization estimates.

    """

    def __init__(self, extractor, rpn, head,
                loc_normalize_mean = (0., 0., 0., 0.),
                loc_normalize_std = (0.1, 0.1, 0.2, 0.2)
    ):
        super(FasterRCNN, self).__init__()
        self.extractor = extractor
        self.rpn = rpn
        self.head = head

        # mean and std
        self.loc_normalize_mean = loc_normalize_mean
        self.loc_normalize_std = loc_normalize_std
        self.use_preset('evaluate')

    @property
    def n_class(self):
        # Total number of classes including the background.
        return self.head.n_class

    def forward(self, x, scale=1.):    # ONLY USED AT TEST TIME (CALLED IN FUNCTION PREDICT BELOW)
        """Forward Faster R-CNN.

        Scaling paramter :obj:`scale` is used by RPN to determine the
        threshold to select small objects, which are going to be
        rejected irrespective of their confidence scores.

        Here are notations used.

        * :math:`N` is the number of batch size
        * :math:`R'` is the total number of RoIs produced across batches. \
            Given :math:`R_i` proposed RoIs from the :math:`i` th image, \
            :math:`R' = \\sum _{i=1} ^ N R_i`.
        * :math:`L` is the number of classes excluding the background.

        Classes are ordered by the background, the first class, ..., and
        the :math:`L` th class.

        Args:
            x (autograd.Variable): 4D image variable.
            scale (float): Amount of scaling applied to the raw image
                during preprocessing.

        Returns:
            Variable, Variable, array, array:
            Returns tuple of four values listed below.

            * **roi_cls_locs**: Offsets and scalings for the proposed RoIs. \
                Its shape is :math:`(R', (L + 1) \\times 4)`.
            * **roi_scores**: Class predictions for the proposed RoIs. \
                Its shape is :math:`(R', L + 1)`.
            * **rois**: RoIs proposed by RPN. Its shape is \
                :math:`(R', 4)`.
            * **roi_indices**: Batch indices of RoIs. Its shape is \
                :math:`(R',)`.

        """
        
#        x torch.Size([1, 3, 600, 800]) : batch, color channel, height, width (scaled to 600 pixels and normalized pixel values)
        img_size = x.shape[2:]  #  [600, 800]
        

        # Step 1: CNN features extraction (VGG16) ===========================================================
        h = self.extractor(x)
#        h torch.Size([1, 512, 37, 50])
        

        
        # Step 2: Region Proposal Network ===================================================================
        # We only need to predict, not computing RPN or ROI localisation + classification loss   ->  throw rpn_locs, rpn_scores and anchor
        # At test time, we select only MAX 300 region proposal after NMS (less than 2000 at training time for faster prediction)
        # This step, we can locate roughly the position of bbox (fixed anchor bbox + Incremental predicted coordinates by CNN)
        rpn_locs, rpn_scores, rois, roi_indices, anchor = self.rpn(h, img_size, scale)               

#        300 REGION PROPOSAL BBOX via CNN & NMS at TEST time (instead of Selective Search) --------
#
#        rois  (300, 4)                                                       # MAX 300 PREDICTED bounding-boxes Regions Proposal AT TEST TIME (Region of Interest ROI created by FIXED anchor bbox + INCREMENTAL dy, dx, dheight, dwidth PREDICTED by CNN) with HIGHEST PREDICTED objectness scores & Non-redundant via NMS  x  4 corresponding coordinates  . NOTE: maximum is 300, due to randomness, it can be less
#        [[  0.        33.292984 532.21045  370.43    ]
#         [ 54.261642   0.       400.79315  674.4544  ]
#         [398.0247   645.29407  495.81967  800.      ]
#         ...
#         [455.13147  545.55994  538.98364  726.38745 ]
#         [514.60236  139.05585  600.       260.01196 ]
#         [405.3222     0.       540.1906    82.876076]]
#
#        roi_indices  (300,) [0 0 0 ... 0 0 0]                                # index of image in batch (always the first and unique image - index 0 if batch_size = 1)
        


        # Step 3: Run ROI Pooling & Last VGG classifier on (Sample) ROI =====================================
        # This step serves for Bounding-box regressor : find the Incremental predicted coordinates of EACH CLASS from the SELECTED bbox ROI of RPN step
        # At test time, we don't need to sample 128 ROI samples any more (as we don't have ground-truth bbox to sample positive and negative bbox), we put all Max 300 Region Proposals into ROI Head
        roi_cls_locs, roi_scores = self.head(h, rois, roi_indices)
        
#        roi_score torch.Size([300, 21])                                       # for each bbox: we predict 21 object scores (20 object classes + background) OBJECT ROI selected bbox to ground-truth bbox 
#        tensor([[ 0.3237, -0.1683, -0.2037,  ...,  0.1305,  0.5009, -0.4061],
#                [ 0.0662, -0.0491, -0.0649,  ...,  0.1462,  0.3161, -0.2695],
#                [ 0.2649, -0.1429, -0.0971,  ...,  0.0496,  0.3100, -0.4186],
#                ...,
#                [-0.1920,  0.3956, -0.2486,  ..., -0.1070,  0.3637,  0.1624],
#                [ 0.0360,  0.0459,  0.0788,  ...,  0.0969, -0.2308, -0.2668],
#                [ 0.3036, -0.0374, -0.1368,  ...,  0.2855,  0.5802, -0.2827]],
#               device='cuda:0', grad_fn=<AddmmBackward>)
#
#        Note: we predict 4 coordinates of each of 21 object class separately (not unique 4 coordinates bbox like in RPN) because here, we're treating the multi-object prediction (not binary prediction object or not problem like in RPN !!!!)
#        
#        roi_cls_loc torch.Size([300, 84])                                     # for each bbox: we predict 4 INCREMENTAL coordinates of each of 21 classes (20 object classes + background) OBJECT ROI selected bbox to ground-truth bbox 
#        tensor([[ 2.3361e-02,  5.1721e-02, -9.4898e-03,  ..., -2.6796e-02, 2.7425e-03, -7.4335e-03],
#                [ 8.4832e-03,  4.4859e-02,  1.1071e-02,  ..., -2.4948e-02, 2.3907e-02, -6.5800e-03],
#                [ 1.4902e-02,  3.7563e-02, -8.6419e-03,  ..., -1.1015e-02,-8.2988e-05, -1.4083e-02],
#                ...,
#                [-1.7331e-02,  1.5235e-03, -3.1996e-02,  ...,  4.0901e-03, -1.6853e-02,  6.1920e-03],
#                [ 3.5230e-02,  9.9208e-03,  2.5442e-03,  ..., -3.2313e-02, 3.1963e-02, -2.6983e-02],
#                [ 3.9199e-03,  7.0513e-02, -4.1272e-02,  ..., -6.2037e-03, 2.6381e-02, -4.4130e-03]], device='cuda:0', grad_fn=<AddmmBackward>)
            
        return roi_cls_locs, roi_scores, rois, roi_indices

    def use_preset(self, preset):
        """Use the given preset during prediction.

        This method changes values of :obj:`self.nms_thresh` and
        :obj:`self.score_thresh`. These values are a threshold value
        used for non maximum suppression and a threshold value
        to discard low confidence proposals in :meth:`predict`,
        respectively.

        If the attributes need to be changed to something
        other than the values provided in the presets, please modify
        them by directly accessing the public attributes.

        Args:
            preset ({'visualize', 'evaluate'): A string to determine the
                preset to use.

        """
        if preset == 'visualize':
            self.nms_thresh = 0.3
            self.score_thresh = 0.7
        elif preset == 'evaluate':
            self.nms_thresh = 0.3
            self.score_thresh = 0.05
        else:
            raise ValueError('preset must be visualize or evaluate')

    def _suppress(self, raw_cls_bbox, raw_prob):
        """ NMS Second Time at Test time: perform Non-Maximum Suppression on EACH CLASS """
        
#        raw_cls_bbox [300, 84] : 4 unnormalized (and in the good range) coordinates * (20 object + background class) of 300 final ROI bbox (created by fixed anchor bbox + incremental predicted coordinates by CNN + incremental predicted coordinates by ROI pooling + Last VGG16 classifier)
#        
#        raw_prob [300, 21]     : softmax probability of 20 object + background class on 300 final ROI bbox
        
        bbox = list()
        label = list()
        score = list()
        
        # skip cls_id = 0 because it is the background class
        for l in range(1, self.n_class):        # Apply NMS on EACH CLASS !!!
            cls_bbox_l = raw_cls_bbox.reshape((-1, self.n_class, 4))[:, l, :]
#            cls_bbox_l torch.Size([300, 4])
            prob_l = raw_prob[:, l]
#            prob_l torch.Size([300])
            
            # ====================================================================
            # First filter : only keep ROI bbox with confidence score on each class > some threshold (score_thresh = 0.7 if visualize)  (otherwise, the model is not sure -> it predicts background class 0)
            # Note : we don't take argmax on each class of each 300 bbox because sometimes, argmax of 21 classes can be still very small (< 0.7 for ex) when the model is not sure and gives quite equal probability to each class -> we put a higher threshold than just argmax. This threshold score is thus very sensitive to the final result that we want to obtain !!!   -> Just for visualization        
            # we don't care about argmax on each bbox, we only care about the acceptable bbox among 300 bbox on each class pass            
            mask = prob_l > self.score_thresh   # score_thresh = 0.7 if visualize  (= 0.05 : very small for evaluation, even when the model is quite unsure !!!)
            cls_bbox_l = cls_bbox_l[mask]
            prob_l = prob_l[mask]
            
            # ====================================================================
            # Second filter : Apply NMS on remaining ROI bbox of EACH CLASS !!! (to remove the risk of multiple bbox on only 1 object. However, this can also eliminate 2 real bbox on two close objects -> we have quite big number of bbox 300, hopefully this can compensate this False Positive)
            # For each class : Greedily select the PREDICTED ROI BBOX with the HIGHEST SCORE. Remove the remaining PREDICTED ROI BBOX with large IoU (i.e. > 0.3 => large IoU threshold means that we're expecting each bbox very far from each other !!!) with previously SELECTED PREDICTED ROI BBOX. (not ground-truth, be careful !!!). Repeat these steps until there's no predicted ROI bbox left.
            keep = nms(cls_bbox_l, prob_l, self.nms_thresh)  # nms_thresh = 0.3

#            After training on sufficient number of times and evaluate :
#            l , keep  2 torch.Size([0])
#            l , keep  3 torch.Size([0])
#            l , keep  4 torch.Size([0])
#            l , keep  5 torch.Size([0])
#            l , keep  6 torch.Size([0])
#            l , keep  7 torch.Size([0])
#            l , keep  8 torch.Size([0])
#            l , keep  9 torch.Size([2]) ------------------------  2 predicted object with score > 0.7 and overlapping regions IoU < 0.3 among 300 bbox
#            l , keep  10 torch.Size([0])
#            l , keep  11 torch.Size([0])
#            l , keep  12 torch.Size([0])
#            l , keep  13 torch.Size([0])
#            l , keep  14 torch.Size([0])
#            l , keep  15 torch.Size([0])
#            l , keep  16 torch.Size([1]) ------------------------ only 1 predicted object with score > 0.7 among 300 bbox
#            l , keep  17 torch.Size([0])
#            l , keep  18 torch.Size([0])
#            l , keep  19 torch.Size([0])
#            l , keep  20 torch.Size([0])
            
            # import ipdb;ipdb.set_trace()
            # keep = cp.asnumpy(keep)
            bbox.append(cls_bbox_l[keep].cpu().numpy())
            # The labels are in [0, self.n_class - 2].
            label.append((l - 1) * np.ones((len(keep),)))
            score.append(prob_l[keep].cpu().numpy())
        
        # Concatenate sequentially by row into a long list
        bbox = np.concatenate(bbox, axis=0).astype(np.float32)
        label = np.concatenate(label, axis=0).astype(np.int32)
        score = np.concatenate(score, axis=0).astype(np.float32)

#        bbox (3, 4) 
#        [[120.592865 552.87976  600.       791.3197  ]
#         [335.23175   74.84369  592.2619   782.9062  ]
#         [ 24.74105  225.3293   164.25931  285.9275  ]]
#         
#        label (3,) 
#        [ 8  8 15]
#        
#        score (3,) 
#        [0.92127126 0.8380613  0.8809009 ]                 # all score > 0.7 (must be very confident. if all score < 0.7 : the model is not very sure about object -> it predicts the background class -> this list is empty)
        
        return bbox, label, score

    @nograd
    def predict(self, imgs, sizes=None, visualize=False):
        """Detect objects from images.
        This method predicts objects for each image.

        Args:
            - show predictions on *training* photos   : 
                ori_img_ (SCALED image + *unnormalized*) +  sizes (None)                                         + visualize (True)   
            - show predictions on *test* photos       : 
                imgs     (SCALED image + *normalized*)   +  sizes ([H, W] of original image before scaling)      + visualize (False)

        After transformation inside this function :
            - show predictions on *training* photos   : 
                ori_img_ (SCALED image + normalized)     +  sizes ([H, W] of *SCALED image* Possibly WRONG !!!)  + visualize (True)  (use score_threshold = 0.7)
            - show predictions on *test* photos       : 
                imgs     (SCALED image + normalized)     +  sizes ([H, W] of *original image before scaling*)    + visualize (False) (use score_threshold = 0.05)



        Returns:
           tuple of lists:
           This method returns a tuple of three lists,
           :obj:`(bboxes, labels, scores)`.

           * **bboxes**: A list of float arrays of shape :math:`(R, 4)`, \
               where :math:`R` is the number of bounding boxes in a image. \
               Each bouding box is organized by \
               :math:`(y_{min}, x_{min}, y_{max}, x_{max})` \
               in the second axis.
           * **labels** : A list of integer arrays of shape :math:`(R,)`. \
               Each value indicates the class of the bounding box. \
               Values are in range :math:`[0, L - 1]`, where :math:`L` is the \
               number of the foreground classes.
           * **scores** : A list of float arrays of shape :math:`(R,)`. \
               Each value indicates how confident the prediction is.

        """
        
        # imgs [3, 600, 800] : [channel, height, width] of SCALED image (shorter side to 600 pixel)        
        
        self.eval()     # switch to eval mode (no backprop)
        
        if visualize:   # show predictions on *training* photos   
            self.use_preset('visualize')              # change score_threshold from 0.05 to 0.7
            prepared_imgs = list()
            sizes = list()
            for img in imgs:
                size = img.shape[1:]                  # [600, 800]  :  SCALED image size (shorter side scaled to 600)
                img = preprocess(at.tonumpy(img))     # ALWAYS need to Renormalize SCALE photo image for training, predict, test calculations
                prepared_imgs.append(img)             
                sizes.append(size)                    # for visualization (or inspect_test_set) : [H, W] of SCALED image for both ground-truth and predicted bbox for plotting on the graph
        else:           # show predictions on *test* photos   (still use score_threshold = 0.05)
             #self.use_preset('visualize')            #TODO: test this                              
             prepared_imgs = imgs                     # normalized values in range [0, 1]
             # sizes : [H, W] of original image BEFORE SCALING    :  for computing IoU, mAP                    
             
             
        bboxes = list()
        labels = list()
        scores = list()
        for img, size in zip(prepared_imgs, sizes):   # this loop is for each photo in batch_size. In case batch_size = 1, we proceed only once
            
#            img (3, 600, 800)
#            size (600, 800)
            img = at.totensor(img[None]).float()      # add one more global dimension
#            img torch.Size([1, 3, 600, 800])
            scale = img.shape[3] / size[1]
#            scale 1.0                                # scale = 1 : this photo is already scaled during visualization. At evaluation time, we get back scaled image to original raw size
            
            # Call Forward function ===========================================================
            # At test time : Run extractor CNN, RPN NMS keep MAX 300 proposal bbox, ROI Head + Last VGG16 classifier on these 300 proposal bbox
            roi_cls_loc, roi_scores, rois, _ = self(img, scale=scale)          

#            REGION PROPOSAL BBOX by CNN + Fixed Anchor bbox, then NMS and Limit to top 300 ROI at TEST time (instead of Selective Search) -----------------
#    
#            rois  (300, 4)                                                       # MAX 300 PREDICTED bounding-boxes Regions Proposal AT TEST TIME (Region of Interest ROI created by FIXED anchor bbox + INCREMENTAL dy, dx, dheight, dwidth PREDICTED by CNN) with HIGHEST PREDICTED objectness scores & Non-redundant via NMS  x  4 corresponding coordinates  . NOTE: maximum is 300, due to randomness, it can be less
#            [[  0.        33.292984 532.21045  370.43    ]
#             [ 54.261642   0.       400.79315  674.4544  ]
#             [398.0247   645.29407  495.81967  800.      ]
#             ...
#             [455.13147  545.55994  538.98364  726.38745 ]
#             [514.60236  139.05585  600.       260.01196 ]
#             [405.3222     0.       540.1906    82.876076]]
#
#            Run ROI Pooling & Last VGG classifier on (Sample) ROI ----------------------
#            At test time, we don't need to sample 128 ROI samples any more (as we don't have ground-truth bbox to sample positive and negative bbox), we put all Max 300 Region Proposals into ROI Head
#
#            roi_score torch.Size([300, 21])                                       # for each bbox: we predict 21 object scores (20 object classes + background) OBJECT ROI selected bbox to ground-truth bbox 
#            tensor([[ 0.3237, -0.1683, -0.2037,  ...,  0.1305,  0.5009, -0.4061],
#                    [ 0.0662, -0.0491, -0.0649,  ...,  0.1462,  0.3161, -0.2695],
#                    [ 0.2649, -0.1429, -0.0971,  ...,  0.0496,  0.3100, -0.4186],
#                    ...,
#                    [-0.1920,  0.3956, -0.2486,  ..., -0.1070,  0.3637,  0.1624],
#                    [ 0.0360,  0.0459,  0.0788,  ...,  0.0969, -0.2308, -0.2668],
#                    [ 0.3036, -0.0374, -0.1368,  ...,  0.2855,  0.5802, -0.2827]],
#                   device='cuda:0', grad_fn=<AddmmBackward>)
#    
#            roi_cls_loc torch.Size([300, 84])                                     # for each bbox: we predict 4 INCREMENTAL coordinates of each of 21 classes (20 object classes + background) OBJECT ROI selected bbox to ground-truth bbox 
#            tensor([[ 2.3361e-02,  5.1721e-02, -9.4898e-03,  ..., -2.6796e-02, 2.7425e-03, -7.4335e-03],
#                    [ 8.4832e-03,  4.4859e-02,  1.1071e-02,  ..., -2.4948e-02, 2.3907e-02, -6.5800e-03],
#                    [ 1.4902e-02,  3.7563e-02, -8.6419e-03,  ..., -1.1015e-02,-8.2988e-05, -1.4083e-02],
#                    ...,
#                    [-1.7331e-02,  1.5235e-03, -3.1996e-02,  ...,  4.0901e-03, -1.6853e-02,  6.1920e-03],
#                    [ 3.5230e-02,  9.9208e-03,  2.5442e-03,  ..., -3.2313e-02, 3.1963e-02, -2.6983e-02],
#                    [ 3.9199e-03,  7.0513e-02, -4.1272e-02,  ..., -6.2037e-03, 2.6381e-02, -4.4130e-03]], device='cuda:0', grad_fn=<AddmmBackward>)
            
            # We are assuming that batch size is 1.
            roi_score = roi_scores.data
            roi_cls_loc = roi_cls_loc.data
            roi = at.totensor(rois) / scale    #  default: get back pixel values before scaling to 600 if the input is raw image (however, if the input is already scaled image -> this line does not change any value)


            # ==================================================================================
            #  UNNORMALIZE 4 coordinates prediction values of ROI because gt_roi_loc are normalized during training !!! 

            mean = t.Tensor(self.loc_normalize_mean).cuda().repeat(self.n_class)[None]
            std = t.Tensor(self.loc_normalize_std).cuda().repeat(self.n_class)[None]
            
#            mean torch.Size([1, 84]) 
#            tensor([[0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
#                     0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
#                     0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
#                     0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.]], device='cuda:0')
#                     
#            std torch.Size([1, 84]) 
#            tensor([[0.1000, 0.1000, 0.2000, 0.2000, 
#                     0.1000, 0.1000, 0.2000, 0.2000, 
#                     0.1000, 0.1000, 0.2000, 0.2000, 
#                     0.1000, 0.1000, 0.2000, 0.2000,            
#                     0.1000, 0.1000, 0.2000, 0.2000,
#                     0.1000, 0.1000, 0.2000, 0.2000,
#                     0.1000, 0.1000, 0.2000, 0.2000,
#                     0.1000, 0.1000, 0.2000, 0.2000,
#                     ...            
            
            roi_cls_loc = (roi_cls_loc * std + mean)      #  UNNORMALIZE 4 coordinates prediction values of ROI because gt_roi_loc are normalized during training !!! 

#            roi_cls_loc torch.Size([300, 84]) 
#            tensor([[ 5.2292e-05, -2.9237e-06, -1.4452e-03,  ..., -1.6048e-03, -4.1282e-03, -1.4246e-03],
#                    [-1.4371e-04, -1.4369e-03, -2.7011e-03,  ..., -4.3373e-03, -1.3809e-03,  5.9839e-03],
#                    [-2.1440e-03, -1.4849e-04, -3.7569e-03,  ..., -4.2541e-03, -1.7003e-03, -3.7407e-03],
#                    ...,
#                    [ 1.6233e-03,  9.6598e-04, -4.2455e-04,  ..., -1.6598e-03, -1.3453e-03,  3.0771e-03],
#                    [-1.5599e-03,  3.9923e-04, -1.5497e-03,  ..., -1.4103e-03,  2.3335e-03,  2.3217e-03],
#                    [ 3.0052e-03, -1.6733e-03, -6.3704e-03,  ..., -4.2970e-03,  4.4353e-03, -6.5138e-03]], device='cuda:0')

            roi_cls_loc = roi_cls_loc.view(-1, self.n_class, 4)

#            roi_cls_loc torch.Size([300, 21, 4]) 
#            tensor([[[ 5.2292e-05, -2.9237e-06, -1.4452e-03, -1.1092e-03],
#                     [ 8.9462e-04, -3.5587e-03,  1.2932e-02,  4.3206e-03],
#                     [ 2.4730e-03,  2.7065e-03, -4.5513e-03,  3.4038e-03],
#                     ...,
#                     [ 1.6049e-03,  4.6472e-04,  8.7082e-04, -8.7471e-03],
#                     [-2.3960e-03, -4.5218e-03,  1.4736e-03,  1.1508e-03],
#                     [-2.7855e-03, -1.6048e-03, -4.1282e-03, -1.4246e-03]],
#                     ...

            roi = roi.view(-1, 1, 4).expand_as(roi_cls_loc)

#            roi torch.Size([300, 21, 4])                                      # the same predicted bbox by RPN for each class
#            tensor([[[  0.0000,  33.2930, 532.2103, 370.4300],
#                     [  0.0000,  33.2930, 532.2103, 370.4300],
#                     [  0.0000,  33.2930, 532.2103, 370.4300],
#                     ...,
#                     [  0.0000,  33.2930, 532.2103, 370.4300],
#                     [  0.0000,  33.2930, 532.2103, 370.4300],
#                     [  0.0000,  33.2930, 532.2103, 370.4300]],
#
#                    [[ 54.2617,   0.0000, 400.7932, 674.4543],
#                     [ 54.2617,   0.0000, 400.7932, 674.4543],
#                     [ 54.2617,   0.0000, 400.7932, 674.4543],
#                     ...,
#                     [ 54.2617,   0.0000, 400.7932, 674.4543],
#                     [ 54.2617,   0.0000, 400.7932, 674.4543],
#                     [ 54.2617,   0.0000, 400.7932, 674.4543]],
#                      
#                     ... 
            
            # ==================================================================================
            # Convert predictions to bounding boxes in image coordinates.
            # Bounding boxes are scaled to the scale of the input images.
            
            cls_bbox = loc2bbox(at.tonumpy(roi).reshape((-1, 4)),
                                at.tonumpy(roi_cls_loc).reshape((-1, 4)))
#            cls_bbox (6300, 4)  
            cls_bbox = at.totensor(cls_bbox)
            cls_bbox = cls_bbox.view(-1, self.n_class * 4)
#            cls_bbox torch.Size([300, 84])
            
            # clip bounding box if any pixel values go beyond the image size limit
            cls_bbox[:, 0::2] = (cls_bbox[:, 0::2]).clamp(min=0, max=size[0])  # clip height pixel values y-max, y-min in range [0, 600]
            cls_bbox[:, 1::2] = (cls_bbox[:, 1::2]).clamp(min=0, max=size[1])  # clip width pixel values x-max, x-min in range [0, 800]

            prob = (F.softmax(at.totensor(roi_score), dim=1))                  # softmax on each of 20 object + background class

            # Suppress =========================================================================
            # NMS : perform Non-Maximum Suppression Second Time on EACH CLASS (this is different with the NMS the First Time in RPN : select the predicted bbox with highest objectness score from 16650 and perform Non-Maximum Suprresion ITERATIVELY to reduce the number of predicted bbox to Max 2000 -> reduce the object proposals, we haven't intervened with each class here !!!)
            bbox, label, score = self._suppress(cls_bbox, prob)
            
            bboxes.append(bbox)
            labels.append(label)
            scores.append(score)


        self.use_preset('evaluate')
        self.train()         # return back to training mode (with backprop)
        
        return bboxes, labels, scores

    def get_optimizer(self):
        """
        return optimizer, It could be overwriten if you want to specify 
        special optimizer
        """
        lr = opt.lr
        params = []
        for key, value in dict(self.named_parameters()).items():
            if value.requires_grad:
                if 'bias' in key:
                    params += [{'params': [value], 'lr': lr * 2, 'weight_decay': 0}]
                else:
                    params += [{'params': [value], 'lr': lr, 'weight_decay': opt.weight_decay}]
        if opt.use_adam:
            self.optimizer = t.optim.Adam(params)
        else:
            self.optimizer = t.optim.SGD(params, momentum=0.9)
        return self.optimizer

    def scale_lr(self, decay=0.1):
        for param_group in self.optimizer.param_groups:
            param_group['lr'] *= decay
        return self.optimizer