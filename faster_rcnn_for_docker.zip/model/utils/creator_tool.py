import numpy as np
import torch
from torchvision.ops import nms
from model.utils.bbox_tools import bbox2loc, bbox_iou, loc2bbox
import collections


class ProposalTargetCreator(object):
    """Assign ground truth bounding boxes to given RoIs.

    The :meth:`__call__` of this class generates training targets
    for each object proposal.
    This is used to train Faster RCNN [#]_.

    .. [#] Shaoqing Ren, Kaiming He, Ross Girshick, Jian Sun. \
    Faster R-CNN: Towards Real-Time Object Detection with \
    Region Proposal Networks. NIPS 2015.

    Args:
        n_sample (int): The number of sampled regions.
        pos_ratio (float): Fraction of regions that is labeled as a foreground.
        pos_iou_thresh (float): IoU threshold for a RoI to be considered as a foreground.
        neg_iou_thresh_hi (float): RoI is considered to be the background
            if IoU is in [:obj:`neg_iou_thresh_hi`, :obj:`neg_iou_thresh_hi`).
        neg_iou_thresh_lo (float): See above.

    """

    def __init__(self,
                 n_sample=128,
                 pos_ratio=0.25, pos_iou_thresh=0.5,
                 neg_iou_thresh_hi=0.5, neg_iou_thresh_lo=0.0
                 ):
        self.n_sample = n_sample
        self.pos_ratio = pos_ratio
        self.pos_iou_thresh = pos_iou_thresh
        self.neg_iou_thresh_hi = neg_iou_thresh_hi
        self.neg_iou_thresh_lo = neg_iou_thresh_lo  # NOTE:default 0.1 in py-faster-rcnn

    def __call__(self, roi, bbox, label,
                 loc_normalize_mean=(0., 0., 0., 0.),        # y-min, x-min, y-max, x-max
                 loc_normalize_std=(0.1, 0.1, 0.2, 0.2)):
        """Assigns ground truth to sampled proposals.

        This function samples total of :obj:`self.n_sample` RoIs
        from the combination of :obj:`roi` and :obj:`bbox`.
        The RoIs are assigned with the ground truth class labels as well as
        bounding box offsets and scales to match the ground truth bounding
        boxes. As many as :obj:`pos_ratio * self.n_sample` RoIs are
        sampled as foregrounds.

        Offsets and scales of bounding boxes are calculated using
        :func:`model.utils.bbox_tools.bbox2loc`.
        Also, types of input arrays and output arrays are same.

        Here are notations.

        * :math:`S` is the total number of sampled RoIs, which equals \
            :obj:`self.n_sample`.
        * :math:`L` is number of object classes possibly including the \
            background.

        Args:
            roi (array): Region of Interests (RoIs) from which we sample.
                Its shape is :math:`(R, 4)`
            bbox (array): The coordinates of ground truth bounding boxes.
                Its shape is :math:`(R', 4)`.
            label (array): Ground truth bounding box labels. Its shape
                is :math:`(R',)`. Its range is :math:`[0, L - 1]`, where
                :math:`L` is the number of foreground classes.
            loc_normalize_mean (tuple of four floats): Mean values to normalize
                coordinates of bouding boxes.
            loc_normalize_std (tupler of four floats): Standard deviation of
                the coordinates of bounding boxes.

        Returns:
            (array, array, array):

            * **sample_roi**: Regions of interests that are sampled. \
                Its shape is :math:`(S, 4)`.
            * **gt_roi_loc**: Offsets and scales to match \
                the sampled RoIs to the ground truth bounding boxes. \
                Its shape is :math:`(S, 4)`.
            * **gt_roi_label**: Labels assigned to sampled RoIs. Its shape is \
                :math:`(S,)`. Its range is :math:`[0, L]`. The label with \
                value 0 is the background.

        """
        
#        roi  (1724, 4)                                     # MAX 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI) with HIGHEST PREDICTED objectness scores & Non-redundant via NMS x  4 corresponding coordinates  . NOTE: maximum is 2000, due to randomness, it can be less (1940 for ex)
#        [[  0.        42.739    528.5074   376.7633  ]
#         [283.63934    0.       420.3711   103.96875 ]
#         [ 56.598816   0.       405.03427  668.30994 ]
#         ...
#         [446.4488   353.54617  600.       440.49185 ]
#         [287.0526   375.04297  378.7989   551.0982  ]
#         [282.63702  578.0259   410.42755  710.7428  ]]

#        bbox: [number_bbox, 4 coordinates]                 # ground-truth (rescaled) bounding-box 
#        tensor([[336.0000, 283.2000, 540.8000, 380.8000],
#                [420.8000, 396.8000, 593.6000, 537.6000],
#                [308.8000, 329.6000, 476.8000, 416.0000]], device='cuda:0')
#        
#        label: [number of ground-truth classes which correspond to number_bbox]       # ground-truth label, ex: 3 object:
#        tensor([8, 8, 8], device='cuda:0', dtype=torch.int32)
        
        n_bbox, _ = bbox.shape
        roi = np.concatenate((roi, bbox), axis=0)    # add ground-truth bbox to the end of predicted bbox

        pos_roi_per_image = np.round(self.n_sample * self.pos_ratio) # 128 * 0.25 = 32 (Number of sampled regions * Fraction of regions that is labeled as a foreground)
        # compute IoU ratio between each PREDICTED bbox with each GROUND-TRUTH BBOX        
        iou = bbox_iou(roi, bbox)                    # IoU between [1727 predicted bbox, 3 ground-truth bbox]
#        iou (1727, 3) 
#        [[ 0.10089915 -0.          0.04326765]
#         [-0.          0.         -0.        ]
#         [ 0.02737656 -0.          0.03478005]
#         ...
#         [ 1.         -0.          0.26411557]      # 3 GROUND-TRUTH BBOX
#         [-0.          1.          0.02846688]
#         [ 0.26411557  0.02846688  1.        ]]
        
        # -----------------------------------------
        # -----------------------------------------
        # One predicted bbox can belong to ONLY ONE ground-truth bbox -> we have no choice than ASSIGNING the PREDICTED bbox to GROUND-TRUTH bbox that it has the LARGEST OVERLAPPING region
        # From the paper: 
        # "Care must be taken when selecting which training pairs (P, G) to use. 
        # Intuitively, if P is far from all ground-truth boxes, then the task of transforming P to a ground-truth box G does not make sense. 
        # Using examples like P would lead to a hopeless learning problem.
        # Therefore, we only learn from a proposal P if it is nearby at least one ground-truth box. 
        # We implement “nearness” by assigning P to the ground-truth box G with which it has maximum IoU overlap (in case it overlaps more than one) 
        # if and only if the overlap is greater than a threshold (which we set to 0.5). 
        # All unassigned proposals are discarded. 
        # We do this once for each object class in order to learn a set of class-specific bounding-box regressors"

        gt_assignment = iou.argmax(axis=1)           
        max_iou = iou.max(axis=1)

#        gt_assignment  (1727,) 
#        [0 0 2 ... ** 0 1 2 ** (3 GROUND-TRUTH BBOX)]
#
#        max_iou (1727,) 
#        [ 0.10089915 -0.          0.03478005 ...  ** 1.          1.       1. ** (3 GROUND-TRUTH BBOX) ]        
        
        # Offset range of classes from [0, n_fg_class - 1] to [1, n_fg_class].
        # The label with value 0 is the BACKGROUND.
        gt_roi_label = label[gt_assignment] + 1
        
#        label[gt_assignment] (1727,) 
#        [8 8 8 ... 8 8 8]
#        gt_roi_label (1727,) 
#        [9 9 9 ... 9 9 9]

        # -------------------------------
        # Select FOREGROUND RoIs as those with >= pos_iou_thresh IoU (= 0.5).
        pos_index = np.where(max_iou >= self.pos_iou_thresh)[0]                # keep only MOST OVERLAPPED predicted bbox that has overlapping regions large enough (> certain threshold, e.g. IoU > 0.5)  
        pos_roi_per_this_image = int(min(pos_roi_per_image, pos_index.size))   # pos_roi_per_image : 32 (= 128 * 0.25)  ,  min (32, 20) = 20
        
#        pos_index (20)                              # e.g. 20 *quite different* (NMS has removed redundant a lot of predicted bbox) predicted bbox around (possibly ALL) 3 ground-truth bbox
#        [ 135  235  385  463  538  587  786  848  890  974 1238 1270 1373 1452 1526 1575 1688 ** 1724 1725 1726 ** (3 GROUND-TRUTH BBOX)]
#        pos_roi_per_this_image 
#        20
        
        if pos_index.size > 0:
            pos_index = np.random.choice( pos_index, size=pos_roi_per_this_image, replace=False )          #   Randomly select MAXIMUM 32 predicted bbox (or all remaining bbox) from those remaining predicted bbox which has overlapping regions large enough (> certain threshold, e.g. IoU > 0.5)

#        pos_index (20)
#        [ 786 1238  135  463 1270  587  974 1726 1725  235 1724 1688  848  385 1575 1373  538 1452 1526  890]

        # -------------------------------
        # Select BACKGROUND RoIs as those within [neg_iou_thresh_lo = 0 <= PREDICTED BBOX < neg_iou_thresh_hi = 0.5).
        neg_index = np.where((max_iou < self.neg_iou_thresh_hi) &              # small or non-overlapping regions predicted bbox (ALREADY MOST OVERLAPPED PREDICTED REGIONS w.r.t any GROUND-TRUTH) w.r.t any ground-truth
                             (max_iou >= self.neg_iou_thresh_lo))[0]
#        neg_index (1707,) 
#        [   0    1    2 ... 1721 1722 1723]
        
        neg_roi_per_this_image = self.n_sample - pos_roi_per_this_image        # e.g. 128 - 20 (in this example) = 108 negative samples 
        neg_roi_per_this_image = int( min(neg_roi_per_this_image, neg_index.size) )     #  min (108, 1707) = 108
        if neg_index.size > 0:
            neg_index = np.random.choice( neg_index, size=neg_roi_per_this_image, replace=False )

#        neg_index (108,)                                                      # at least 96 negative samples (= 128 - max 32) : 3/4 of 128 samples are negative, 1/4 (= max 32 samples) is positive (as there are not so many ground-truth bbox in a photo)
#        [ 695  722   59 1665  327  864 1370  246  338  765 1671 1287  712 1385
#          859 1646  495  339  451 1517  536 1552  840  414 1487  567 1322  947
#         1056 1071 1712 1590   68 1583 1025  411  176 1392  909 1478   20  881
#          850  291  470  860 1560 1420  594 1407  853 1108 1143    0  332   94
#          236  603  237   84 1506 1627   23 1573  971  466  912 1654  133 1636
#         1115 1307 1281  766 1131 1243  120  487 1641 1668  704   12  680  323
#         1445  213  109 1220 1167 1250  318 1005  970  524 1346  819 1258 1446
#         1722 1197 1472 1670  545 1290  810  660 1630 1467]

        # The indices that we're selecting (both positive and negative). ----------------------------------------------
        keep_index = np.append(pos_index, neg_index)                           # [128] predicted bbox 
        
        # Labels of 128 sample predicted bbox (~1/4 highest IoU positive, ~3/4 negative predicted bbox that MATCH ANY ground-truth bbox - LABELS OF NEGATIVE PREDICTED BBOX are 0)       
        gt_roi_label = gt_roi_label[keep_index]                                # [128]
        gt_roi_label[pos_roi_per_this_image:] = 0                              # LABELS OF NEGATIVE PREDICTED BBOX are 0
        
#        gt_roi_label (128,) 
#        [9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#         0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#         0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
#         0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]
        
        sample_roi = roi[keep_index]                                           # [128, 4] 4 coordinates of 128 POSITIVE and NEGATIVE BBOX SAMPLES from Max 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI) that has the HIGHEST OVERLAPPING REGION > (or <=) 0.5 w.r.t GROUND-TRUTH BBOX

#        sample_roi (128, 4) 
#        [[383.26605   377.29407   600.        559.4009   ]
#         [435.51804   455.8985    600.        540.8511   ]
#         [407.90097   321.36078   600.        561.5512   ]
#         [321.29504   308.42358   453.60413   433.7323   ]
#         [339.50854   326.33182   470.59094   450.54117  ]
#         [416.9333    372.28577   524.9664    529.8954   ]
#         [411.02887   400.4822    600.        588.9612   ]
#         [308.80002   329.6       476.80002   416.       ]
#         [420.80002   396.8       593.60004   537.6      ]
#         [336.89325   255.24194   472.21466   378.19446  ]
#         [336.        283.2       540.8       380.8      ]
#         ...

        # BOUNDING-BOX REGRESSOR (compute the difference dcenter_x, dcenter_y, dheight, dwidth between 128 PREDICTED SAMPLE & GROUND-TRUTH BBOX) ---------------------------------
        # Compute offsets and scales to match sampled RoIs to the GTs.
        gt_roi_loc = bbox2loc(sample_roi, bbox[gt_assignment[keep_index]])

#        bbox: [number_bbox, 4 coordinates]                 # ground-truth (rescaled) bounding-box 
#        tensor([[336.0000, 283.2000, 540.8000, 380.8000],
#                [420.8000, 396.8000, 593.6000, 537.6000],
#                [308.8000, 329.6000, 476.8000, 416.0000]], device='cuda:0')
#        
#        gt_assignment[keep_index] (128,) 
#        [1 1 1 2 2 1 1 2 1 0 0 1 1 1 1 2 1 1 0 2 1 0 0 0 0 0 0 0 1 0 0 1 0 0 0 2 0
#         0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 2 0 1 0 0 0 1 0 0 0
#         0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1 0 0 0 0 0 0 0 0 1 0 2 0 0 1 1 2 0 0
#         0 0 0 0 0 0 0 2 0 0 0 1 0 0 2 0 1]
#
#        bbox[gt_assignment[keep_index]] (128, 4) 
#        [[420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [308.80002 329.6     476.80002 416.     ]
#         [308.80002 329.6     476.80002 416.     ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [308.80002 329.6     476.80002 416.     ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [336.      283.2     540.8     380.8    ]
#         [336.      283.2     540.8     380.8    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [308.80002 329.6     476.80002 416.     ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [420.80002 396.8     593.60004 537.6    ]
#         [336.      283.2     540.8     380.8    ]
#         ...
#         
#        gt_roi_loc (128, 4) 
#        [[ 7.18253255e-02 -6.30120002e-03 -2.26535559e-01 -2.57253051e-01]
#         [-6.41956180e-02 -3.66967142e-01  4.93340231e-02  5.05247176e-01]
#         [ 1.69158150e-02  1.07181571e-01 -1.05876058e-01 -5.34091711e-01]
#         [ 4.04388979e-02  1.37424273e-02  2.38823220e-01 -3.71792853e-01]
#         [-9.34505761e-02 -1.25888303e-01  2.48137847e-01 -3.62980872e-01]
#         [ 3.35547060e-01  1.02210805e-01  4.69697475e-01 -1.12780832e-01]
#         [ 8.91976152e-03 -1.46019995e-01 -8.94592851e-02 -2.91646093e-01]
#         [ 0.00000000e+00  0.00000000e+00  0.00000000e+00  0.00000000e+00]
#         [ 0.00000000e+00  0.00000000e+00  0.00000000e+00  0.00000000e+00]
#         [ 2.50115931e-01  1.24290258e-01  4.14381027e-01 -2.30920985e-01]
#         ...

        gt_roi_loc = ((gt_roi_loc - np.array(loc_normalize_mean, np.float32)   # loc_normalize_mean=(0., 0., 0., 0.)      # y-min, x-min, y-max, x-max   # mentionned in Page 3 in this paper: https://arxiv.org/pdf/1504.08083.pdf
                       ) / np.array(loc_normalize_std, np.float32))            # loc_normalize_std=(0.1, 0.1, 0.2, 0.2)   # normalized difference dcenter_y, dcenter_x, dheight, dwidth between ground-truth and predicted sample bbox

#        gt_roi_loc (128, 4) 
#        [[ 7.18253255e-01 -6.30119964e-02 -1.13267779e+00 -1.28626525e+00]
#         [-6.41956151e-01 -3.66967130e+00  2.46670112e-01  2.52623582e+00]
#         [ 1.69158146e-01  1.07181573e+00 -5.29380262e-01 -2.67045856e+00]
#         [ 4.04388964e-01  1.37424275e-01  1.19411612e+00 -1.85896420e+00]
#         [-9.34505761e-01 -1.25888300e+00  1.24068916e+00 -1.81490433e+00]
#         [ 3.35547066e+00  1.02210808e+00  2.34848738e+00 -5.63904166e-01]
#         [ 8.91976133e-02 -1.46019995e+00 -4.47296411e-01 -1.45823050e+00]
#         ...
#         [ 1.74070892e+01 -8.66320324e+00  2.28472009e-01 -3.08015609e+00]
#         [ 3.28212509e+01  1.13312740e+01  4.22831488e+00 -3.05706358e+00]
#         [ 1.18478956e+01 -2.91177607e+00  2.37985134e+00 -3.86248040e+00]
#         [ 4.67760038e+00 -3.27569885e+01  6.76378071e-01  5.99376082e-01]
#         [ 2.45431709e+00  1.67006481e+00 -3.73248911e+00 -1.21479452e+00]]

        return sample_roi, gt_roi_loc, gt_roi_label


class AnchorTargetCreator(object):
    """Assign the ground truth bounding boxes to anchors.

    Assigns the ground truth bounding boxes to anchors for training Region
    Proposal Networks introduced in Faster R-CNN [#]_.

    Offsets and scales to match anchors to the ground truth are
    calculated using the encoding scheme of
    :func:`model.utils.bbox_tools.bbox2loc`.

    .. [#] Shaoqing Ren, Kaiming He, Ross Girshick, Jian Sun. \
    Faster R-CNN: Towards Real-Time Object Detection with \
    Region Proposal Networks. NIPS 2015.

    Args:
        n_sample (int): The number of regions to produce.
        pos_iou_thresh (float): Anchors with IoU above this
            threshold will be assigned as positive.
        neg_iou_thresh (float): Anchors with IoU below this
            threshold will be assigned as negative.
        pos_ratio (float): Ratio of positive regions in the
            sampled regions.

    """

    def __init__(self,
                 n_sample=256,
                 pos_iou_thresh=0.7, neg_iou_thresh=0.3,
                 pos_ratio=0.5):
        self.n_sample = n_sample
        self.pos_iou_thresh = pos_iou_thresh
        self.neg_iou_thresh = neg_iou_thresh
        self.pos_ratio = pos_ratio

    def __call__(self, bbox, anchor, img_size):
        """Assign ground truth supervision to sampled subset of anchors.
        Types of input arrays and output arrays are same.

        Here are notations.

        * :math:`S` is the number of anchors.
        * :math:`R` is the number of bounding boxes.

        Args:
            bbox (array): Coordinates of bounding boxes. Its shape is
                :math:`(R, 4)`.
            anchor (array): Coordinates of anchors. Its shape is
                :math:`(S, 4)`.
            img_size (tuple of ints): A tuple :obj:`H, W`, which
                is a tuple of height and width of an image.

        Returns:
            (array, array):

            #NOTE: it's scale not only  offset
            * **loc**: Offsets and scales to match the anchors to \
                the ground truth bounding boxes. Its shape is :math:`(S, 4)`.
            * **label**: Labels of anchors with values \
                :obj:`(1=positive, 0=negative, -1=ignore)`. Its shape \
                is :math:`(S,)`.

        """

#        bbox : [3, 4] ground-truth (rescaled) bbox 4 coordinates
#        tensor([[336.0000, 283.2000, 540.8000, 380.8000],
#                [420.8000, 396.8000, 593.6000, 537.6000],
#                [308.8000, 329.6000, 476.8000, 416.0000]], device='cuda:0')
#
#        anchor :  (16650, 4)  (fixed) list of 37 * 50 * 9 anchor BOXES coordinates                                                   
#         [[ -37.254833  -82.50967    53.254833   98.50967 ]
#         [ -82.50967  -173.01933    98.50967   189.01933 ]
#         [-173.01933  -354.03867   189.01933   370.03867 ]
#         ...
#         [ 493.49033   746.7452    674.50964   837.2548  ]
#         [ 402.98065   701.49036   765.01935   882.50964 ]
#         [ 221.96133   610.98065   946.0387    973.01935 ]]
#
#         img_size : [600, 800] scaled raw image  

        img_H, img_W = img_size
        n_anchor = len(anchor)  # 16650
        
        # FILTER OUT BBOX that has any width, heigh x, y value outside the scaled raw image (height in [0..600], width in [0..800]) --------------------------------
        # This is quite strict ! Why don't we just clip the bbox to these limits like in RPN ???
        inside_index = _get_inside_index(anchor, img_H, img_W)    
        anchor = anchor[inside_index]
        
#        inside_index (5834,)                                     # eliminate 10816 anchor bbox that has any width, heigh x, y value outside the scaled raw image (height in [0..600], width in [0..800]) !!!
#        [ 1404  1413  1422 ... 15669 15678 15687]
#        
#        anchor (5834, 4)                                  
#        [[ 10.745167  13.490334 101.25484  194.50967 ]
#         [ 10.745167  29.490334 101.25484  210.50967 ]
#         [ 10.745167  45.490334 101.25484  226.50967 ]
#         ...
#         [506.74518  573.49036  597.2548   754.50964 ]
#         [506.74518  589.49036  597.2548   770.50964 ]
#         [506.74518  605.49036  597.2548   786.50964 ]]

        # ----------------------------------------------------------------------------------
        # Compute IoU between FIXED ANCHOR BBOX w.r.t ground-truth bbox and SAMPLE POSITIVE and NEGATIVE LABEL FIXED anchor bbox (256 in total, do not divide by 1/4 positive & 3/4 negative like RPN)
        argmax_ious, label = self._create_label(inside_index, anchor, bbox)    # inside_index is not much useful in this function
        
#        argmax_ious (5834,)                                      # Assign each anchor box to ground-truth bbox which has the largest overlapping region (in case if this anchor box overlaps more than one ground-truth bbox)
#        [0 0 0 ... 0 0 0]
#        
#        label (5834,) 
#        [-1 -1 -1 ... -1 -1 -1]
#
#        print(collections.Counter(label))
#        Counter({-1: 5578, 0: 247, 1: 9})                        # Subsampling: 247 negative label (max_ious anchor bbox w.r.t ground-truth < 0.3), 9 positive label (max_IoUs anchor bbox w.r.t ground-truth > 0.7 OR for each grouth-truth, anchor with highest IoU, in case if max_IoUs can not be > 0.7). Sum positive + negative samples = 256. Remaining: 5578 ignored labels (REMAINING POSITIVE or NEGATIVE SAMPLES AFTER SAMPLING + all the fixed anchor bbox in the middle, max_IoU between [0.3, 0.7])


        # Compute bounding box regression targets ----------------------------------------------------------------------------------
        loc = bbox2loc(anchor, bbox[argmax_ious])                 # why don't we just use 256 sampling positive and negative FIXED anchor bbox to compute difference here (like in RPN, to accelerate the speed of computation ?)
        
#        bbox[argmax_ious] (5834, 4) 
#        [[336.  283.2 540.8 380.8]
#         [336.  283.2 540.8 380.8]
#         [336.  283.2 540.8 380.8]
#         ...
#         [336.  283.2 540.8 380.8]
#         [336.  283.2 540.8 380.8]
#         [336.  283.2 540.8 380.8]]
#         
#        
#        loc (5834, 4)                                            # because these are FIXED anchor bbox, they are quite far from ground-truth bbox -> these difference dy, dx, dheight, dwidth between fixed anchor bbox and ground-truth are quite high !
#        [[ 4.2249627  1.2595339  0.8165771 -0.6177266]
#         [ 4.2249627  1.1711456  0.8165771 -0.6177266]
#         [ 4.2249627  1.0827572  0.8165771 -0.6177266]
#         ...
#         [-1.2551149 -1.8340588  0.8165775 -0.6177263]
#         [-1.2551149 -1.9224471  0.8165775 -0.6177263]
#         [-1.2551149 -2.0108354  0.8165775 -0.6177263]]

        # Map up to original set of anchors ----------------------------------------------------------------------------------
        # Unmap a subset of item (data) back to the original set of items (of size count = 16650 fixed anchor bbox)
        label = _unmap(label, n_anchor, inside_index, fill=-1)    # Fill 5834 inside fixed anchor bbox with 256 positive and negative sampling fixed anchor bbox (247 negative label 0, 9 positive label 1, the rest are igore label -1)
        
#        label (16650,) 
#        [-1 -1 -1 ... -1 -1 -1]
#        
#        print(collections.Counter(label))
#        Counter({-1: 16394, 0: 247, 1: 9})

        
        loc = _unmap(loc, n_anchor, inside_index, fill=0)         # Fill 5834 inside fixed anchor bbox DIFFERENCE dy, dx, dheight, dwidth to ground-truth coordinates
        
#        loc (16650, 4) 
#        [[0. 0. 0. 0.]
#         [0. 0. 0. 0.]
#         [0. 0. 0. 0.]
#         ...
#         [0. 0. 0. 0.]
#         [0. 0. 0. 0.]
#         [0. 0. 0. 0.]]

        return loc, label

    def _create_label(self, inside_index, anchor, bbox):

#        inside_index (5834,)                              # eliminate 10816 anchor bbox that has any width, heigh x, y value outside the scaled raw image (height in [0..600], width in [0..800]) !!!
#        [ 1404  1413  1422 ... 15669 15678 15687]
#        
#        anchor (5834, 4)                                  #
#        [[ 10.745167  13.490334 101.25484  194.50967 ]
#         [ 10.745167  29.490334 101.25484  210.50967 ]
#         [ 10.745167  45.490334 101.25484  226.50967 ]
#         ...
#         [506.74518  573.49036  597.2548   754.50964 ]
#         [506.74518  589.49036  597.2548   770.50964 ]
#         [506.74518  605.49036  597.2548   786.50964 ]]        
#
#        bbox : [3, 4] ground-truth (rescaled) bbox 4 coordinates
#        tensor([[336.0000, 283.2000, 540.8000, 380.8000],
#                [420.8000, 396.8000, 593.6000, 537.6000],
#                [308.8000, 329.6000, 476.8000, 416.0000]], device='cuda:0')
        
        # label: 1 is positive, 0 is negative, -1 is dont care
        label = np.empty((len(inside_index),), dtype=np.int32)
        label.fill(-1)                                # Ignore label -1
        
#        label (5834,) 
#        [-1 -1 -1 ... -1 -1 -1]

        # Compute IoU between each fixed anchor box w.r.t ground-truth bbox ------------------------------------------------
        argmax_ious, max_ious, gt_argmax_ious = self._calc_ious(anchor, bbox, inside_index)           

#        argmax_ious (5834,)              # Assign each anchor box to ground-truth bbox which has the largest overlapping region (in case if this anchor box overlaps more than one ground-truth bbox)
#        [0 0 0 ... 0 0 0]
#
#        max_ious (5834,)                 # Max IoU values of each fixed anchor bbox w.r.t ground-truth bbox (IoU MOSTLY 0 because these are FIXED anchor bbox, different than PREDICTED bbox by CNN)
#        [ 0.  0.  0. ... -0. -0. -0.]
#
#        gt_argmax_ious (5,)              # Point out the anchor box (among 5834 remaining fixed anchor bbox) that MOSTLY MATCH EACH ground-truth bbox. With the same max value, there can be more than fixed anchor bbox (5 e.g.) than the number of ground-truth bbox (3)
#        [4237 4846 5426 5578 5685]




        # assign negative labels first so that positive labels can clobber them ------------------------------------------------
        label[max_ious < self.neg_iou_thresh] = 0     # Negative label 0 : max_ious of each fixed anchor bbox w.r.t a ground-truth bbox < 0.3 
        
#        label[max_ious < self.neg_iou_thresh] 
#        (5386,)

        # positive label: for each grount-truth, anchor with highest iou
        label[gt_argmax_ious] = 1                     # Positive label 1 : for each grount-truth, anchor with highest iou

#        label[gt_argmax_ious] 
#        (5,)

        # positive label: above threshold IOU
        label[max_ious >= self.pos_iou_thresh] = 1    # Negative label 1 : + max_ious of each fixed anchor bbox w.r.t a ground-truth bbox >= 0.7

#        label[max_ious >= self.pos_iou_thresh] 
#        (6,)
#
#        print(collections.Counter(label))            # 5386 negative label (max_ious anchor bbox w.r.t ground-truth < 0.3), 9 positive label (max_IoUs anchor bbox w.r.t ground-truth > 0.7 OR for each grouth-truth, anchor with highest IoU, in case if max_IoUs can not be > 0.7), 439 ignored labels (all the fixed anchor bbox in the middle, max_IoU between [0.3, 0.7])
#        Counter({0: 5386, -1: 439, 1: 9})



        # Subsample to 256 fixed anchor bbox to accelerate the training speed as 5386 fixed anchor bbox are too many, too slow to compute !!!
        # subsample positive labels if we have too many ------------------------------------------------
        n_pos = int(self.pos_ratio * self.n_sample)   # 0.5 * 256 = 128 positive samples
        pos_index = np.where(label == 1)[0]
        
#        pos_index 
#        (9,)
        
        if len(pos_index) > n_pos:
            disable_index = np.random.choice( pos_index, size=(len(pos_index) - n_pos), replace=False )
            label[disable_index] = -1

        # subsample negative labels if we have too many ------------------------------------------------
        n_neg = self.n_sample - np.sum(label == 1)    # 256 - 9 = 247 negative samples
        neg_index = np.where(label == 0)[0]
        
#        neg_index 
#        (5386,)
        
        if len(neg_index) > n_neg:
            disable_index = np.random.choice( neg_index, size=(len(neg_index) - n_neg), replace=False )
            label[disable_index] = -1                 # reset 5386 - 247 = 5139 remaining negative samples to label -1 ignore 

#        print(collections.Counter(label))
#        Counter({-1: 5578, 0: 247, 1: 9})           # Subsampling: 247 negative label (max_ious anchor bbox w.r.t ground-truth < 0.3), 9 positive label (max_IoUs anchor bbox w.r.t ground-truth > 0.7 OR for each grouth-truth, anchor with highest IoU, in case if max_IoUs can not be > 0.7). Sum positive + negative samples = 256. Remaining: 5578 ignored labels (REMAINING POSITIVE or NEGATIVE SAMPLES AFTER SAMPLING + all the fixed anchor bbox in the middle, max_IoU between [0.3, 0.7])

        return argmax_ious, label



    def _calc_ious(self, anchor, bbox, inside_index):
        # ious between the anchors and the gt boxes
        ious = bbox_iou(anchor, bbox)

#        ious (5834, 3)                               # IoU between 5834 remaining fixed anchor bbox and 3 ground-truth bbox
#        [[ 0.  0.  0.]
#         [ 0.  0.  0.]
#         [ 0.  0.  0.]
#         ...
#         [-0. -0.  0.]
#         [-0. -0.  0.]
#         [-0. -0.  0.]]

        argmax_ious = ious.argmax(axis=1)             # Assign each anchor box to ground-truth bbox which has the largest overlapping region (in case if this anchor box overlaps more than one ground-truth bbox)

#        argmax_ious (5834,)                          
#        [0 0 0 ... 0 0 0]
        
        max_ious = ious[np.arange(len(inside_index)), argmax_ious]   # max IoU values of each fixed anchor bbox w.r.t ground-truth bbox

#        max_ious (5834,) 
#        [ 0.  0.  0. ... -0. -0. -0.]        
        
        gt_argmax_ious = ious.argmax(axis=0)          # Point out the anchor box (among 5834 remaining fixed anchor bbox) that has the largest overlapping with each ground-truth bbox

#        gt_argmax_ious (3,) 
#        [4846 5426 4237]

        gt_max_ious = ious[gt_argmax_ious, np.arange(ious.shape[1])]           

#        ious[gt_argmax_ious] (3, 3) 
#        [[ 0.81220746 -0.          0.21931136]
#         [-0.          0.67340064  0.01385973]
#         [ 0.25254053  0.03849239  0.86404914]]
#         
#        gt_max_ious (3,)                             # special broadcasting : max on each ground-truth bbox (column)
#        [0.81220746 0.67340064 0.86404914]       
        
        gt_argmax_ious = np.where(ious == gt_max_ious)[0]
        
#        gt_argmax_ious (5,)                          # special broadcasting : find any fixed anchor bbox (row) that has the same IoU with any ground-truth bbox in these maximum IoU of each ground-truth bbox. With the same max value, there can be more than fixed anchor bbox (5 e.g.) than the number of ground-truth bbox (3)
#        [4237 4846 5426 5578 5685]
#        
#        ious[gt_argmax_ious] (5, 3)                
#        [[ 0.25254053  0.03849239  0.86404914]
#         [ 0.81220746 -0.          0.21931136]
#         [-0.          0.67340064  0.01385973]
#         [-0.          0.67340064  0.00961941]
#         [-0.          0.67340064  0.00541442]]

        return argmax_ious, max_ious, gt_argmax_ious


def _unmap(data, count, index, fill=0):
    # Unmap a subset of item (data) back to the original set of items (of size count)

#        data : label (5834,)       +  fill = -1
#        [-1 -1 -1 ... -1 -1 -1]
#
#        print(collections.Counter(label))
#        Counter({-1: 5578, 0: 247, 1: 9})                        # Subsampling: 247 negative label (max_ious anchor bbox w.r.t ground-truth < 0.3), 9 positive label (max_IoUs anchor bbox w.r.t ground-truth > 0.7 OR for each grouth-truth, anchor with highest IoU, in case if max_IoUs can not be > 0.7). Sum positive + negative samples = 256. Remaining: 5578 ignored labels (REMAINING POSITIVE or NEGATIVE SAMPLES AFTER SAMPLING + all the fixed anchor bbox in the middle, max_IoU between [0.3, 0.7])

#        or data : loc (5834, 4)    +  fill = 0                   # because these are FIXED anchor bbox, they are quite far from ground-truth bbox -> these difference dy, dx, dheight, dwidth between fixed anchor bbox and ground-truth are quite high !
#        [[ 4.2249627  1.2595339  0.8165771 -0.6177266]
#         [ 4.2249627  1.1711456  0.8165771 -0.6177266]
#         [ 4.2249627  1.0827572  0.8165771 -0.6177266]
#         ...
#         [-1.2551149 -1.8340588  0.8165775 -0.6177263]
#         [-1.2551149 -1.9224471  0.8165775 -0.6177263]
#         [-1.2551149 -2.0108354  0.8165775 -0.6177263]]

#        count : n_anchor = 16650
#
#        index : inside_index (5834,)                             # eliminate 10816 anchor bbox that has any width, heigh x, y value outside the scaled raw image (height in [0..600], width in [0..800]) !!!
#        [ 1404  1413  1422 ... 15669 15678 15687]

    if len(data.shape) == 1:  # data : label (5834,)    +  fill = -1
        ret = np.empty((count,), dtype=data.dtype)
        ret.fill(fill)
        ret[index] = data
        
#        label (16650,) 
#        [-1 -1 -1 ... -1 -1 -1]
#        
#        print(collections.Counter(label))
#        Counter({-1: 16394, 0: 247, 1: 9})
        
    else:                     # data : loc (5834, 4)    +  fill = 0
        ret = np.empty((count,) + data.shape[1:], dtype=data.dtype)
        ret.fill(fill)
        ret[index, :] = data

#        loc (16650, 4) 
#        [[0. 0. 0. 0.]
#         [0. 0. 0. 0.]
#         [0. 0. 0. 0.]
#         ...
#         [0. 0. 0. 0.]
#         [0. 0. 0. 0.]
#         [0. 0. 0. 0.]]        
        
    return ret


def _get_inside_index(anchor, H, W):
    # Calc indicies of anchors which are located completely inside of the image
    # whose size is speficied.
    index_inside = np.where(
        (anchor[:, 0] >= 0) &
        (anchor[:, 1] >= 0) &
        (anchor[:, 2] <= H) &
        (anchor[:, 3] <= W)
    )[0]
    return index_inside






class ProposalCreator:
    # unNOTE: I'll make it undifferential
    # unTODO: make sure it's ok
    # It's ok
    """Proposal regions are generated by calling this object.

    The :meth:`__call__` of this object outputs object detection proposals by
    applying estimated bounding box offsets
    to a set of anchors.

    This class takes parameters to control number of bounding boxes to
    pass to NMS and keep after NMS.
    If the paramters are negative, it uses all the bounding boxes supplied
    or keep all the bounding boxes returned by NMS.

    This class is used for Region Proposal Networks introduced in
    Faster R-CNN [#]_.

    .. [#] Shaoqing Ren, Kaiming He, Ross Girshick, Jian Sun. \
    Faster R-CNN: Towards Real-Time Object Detection with \
    Region Proposal Networks. NIPS 2015.

    Args:
        nms_thresh (float): Threshold value used when calling NMS.
        n_train_pre_nms (int): Number of top scored bounding boxes
            to keep before passing to NMS in train mode.
        n_train_post_nms (int): Number of top scored bounding boxes
            to keep after passing to NMS in train mode.
        n_test_pre_nms (int): Number of top scored bounding boxes
            to keep before passing to NMS in test mode.
        n_test_post_nms (int): Number of top scored bounding boxes
            to keep after passing to NMS in test mode.
        force_cpu_nms (bool): If this is :obj:`True`,
            always use NMS in CPU mode. If :obj:`False`,
            the NMS mode is selected based on the type of inputs.
        min_size (int): A paramter to determine the threshold on
            discarding bounding boxes based on their sizes.

    """

    def __init__(self,
                 parent_model,
                 nms_thresh=0.7,
                 n_train_pre_nms=12000,
                 n_train_post_nms=2000,
                 n_test_pre_nms=6000,
                 n_test_post_nms=300,
                 min_size=16
                 ):
        self.parent_model = parent_model
        self.nms_thresh = nms_thresh
        self.n_train_pre_nms = n_train_pre_nms
        self.n_train_post_nms = n_train_post_nms
        self.n_test_pre_nms = n_test_pre_nms
        self.n_test_post_nms = n_test_post_nms
        self.min_size = min_size                   #  downsampling ratio image by VGG16

    def __call__(self, loc, score, anchor, img_size, scale=1.):
        """input should  be ndarray
        Propose RoIs.

        Inputs :obj:`loc, score, anchor` refer to the same anchor when indexed
        by the same index.

        On notations, :math:`R` is the total number of anchors. This is equal
        to product of the height and the width of an image and the number of
        anchor bases per pixel.

        Type of the output is same as the inputs.

        Args:
            loc (array): Predicted offsets and scaling to anchors.
                Its shape is :math:`(R, 4)`.
            score (array): Predicted foreground probability for anchors.
                Its shape is :math:`(R,)`.
            anchor (array): Coordinates of anchors. Its shape is
                :math:`(R, 4)`.
            img_size (tuple of ints): A tuple :obj:`height, width`,
                which contains image size after scaling.
            scale (float): The scaling factor used to scale an image after
                reading it from a file.

        My explanations:
            loc :        #  predicted RPN box coordinates by CNN : torch.Size([37 height * 50 width * 9 = 16650 anchor BOXES, 4 coordinates])
            score :      #  predicted RPN objectness score by CNN : torch.Size([16650 = 37 * 50 * 9])  objectiveness score
            anchor :     #  (fixed) list of all anchor BOXES coordinates (37 height * 50 width * 9 = 16650 anchor BOXES, 4 coordinates)
            img_size :   #  SCALED image size (600, 800) e.g.
            scale :      #  scaled ratio of the shorter side (among width, height) of original image to 600 pixels: 1.6 e.g. for this photo
                
        Returns:
            array:
            An array of coordinates of proposal boxes.
            Its shape is :math:`(S, 4)`. :math:`S` is less than
            :obj:`self.n_test_post_nms` in test time and less than
            :obj:`self.n_train_post_nms` in train time. :math:`S` depends on
            the size of the predicted bounding boxes and the number of
            bounding boxes discarded by NMS.

        """
        # NOTE: when test, remember
        # faster_rcnn.eval()
        # to set self.traing = False
        if self.parent_model.training:                     # when we switch .train()
            n_pre_nms = self.n_train_pre_nms    # 12000
            n_post_nms = self.n_train_post_nms  # 2000
        else:
            n_pre_nms = self.n_test_pre_nms     # 6000
            n_post_nms = self.n_test_post_nms   # 300

        # 1. COMPUTE NEW bounding-box coordinates PROPOSALS -----------------------------------------------------------------------
        # COMBINE the hard-coded anchor list (16650, 4) + 4 INCREMENTAL (DX-MIN, DY-MIN, DWIDTH, DHEIGHT) coordinate values PREDICTED by Image & CNN
        roi = loc2bbox(anchor, loc)  
        
#        roi  (16650, 4)                                                   #  4 coordinates of bbox: height y-min, width x-min, y-max, x-max 
#        [[ -34.621536  -75.710754   56.249886   97.67726 ]
#         [ -86.9774   -169.53395    96.3109    184.67094 ]
#         [-179.45578  -405.40588   171.3389    380.31927 ]
#         ...
#         [ 497.32355   750.606     678.4274    835.22784 ]
#         [ 389.41406   701.22833   757.661     887.60016 ]
#         [ 252.67581   613.16864   936.0709    975.3143  ]]    
        

        # 2. CLIP predicted coordinates (height, width) VALUES of boxes to fit the image size  -------------------------------------------
        # -> This will create very diverse bbox size at 4 borders  
        # slice(start, stop, step),  slice(0, 4, 2) : [0, 2] ,  slice(1, 4, 2) : [1, 3]
        # numpy.clip(a, a_min, a_max) : clip (limit) the values in an array
        # img_size : SCALED image size (600, 800) e.g.
        roi[:, slice(0, 4, 2)] = np.clip( roi[:, slice(0, 4, 2)], 0, img_size[0] )  #  clip bbox coordinates y-height values that surpass the photo height

#        roi  (16650, 4)
#        [[   0.        -75.710754   56.249886   97.67726 ]
#         [   0.       -169.53395    96.3109    184.67094 ]
#         [   0.       -405.40588   171.3389    380.31927 ]
#         ...
#         [ 497.32355   750.606     600.        835.22784 ]
#         [ 389.41406   701.22833   600.        887.60016 ]
#         [ 252.67581   613.16864   600.        975.3143  ]]

        roi[:, slice(1, 4, 2)] = np.clip( roi[:, slice(1, 4, 2)], 0, img_size[1] ) #  clip bbox coordinates x-width values that surpass the photo width

#        roi  (16650, 4)
#        [[  0.         0.        56.249886  97.67726 ]
#         [  0.         0.        96.3109   184.67094 ]
#         [  0.         0.       171.3389   380.31927 ]
#         ...
#         [497.32355  750.606    600.       800.      ]
#         [389.41406  701.22833  600.       800.      ]
#         [252.67581  613.16864  600.       800.      ]]
 
 
 

        # 3. REMOVE too small PREDICTED boxes (& its objectness score)  ------------------------------------------------------------
        # KEEP only bbox with both PREDICTED height or width bbox > threshold (subsampling ratio VGG16 16 * scaled ratio 1.6 of the image)
        min_size = self.min_size * scale  # min_size = 16 , scale = 1.6 e.g (scaled ratio of the shorter side (among width, height) of original image to 600 pixels)
        hs = roi[:, 2] - roi[:, 0]    #  height = y_max - y_min
#        hs  (16650,) [ 56.249886  96.3109   171.3389   ... 102.67645  210.58594  347.3242  ]
        ws = roi[:, 3] - roi[:, 1]    #  width = x_max - x_min
#        ws  (16650,) [ 97.67726  184.67094  380.31927  ...  49.393982  98.77167  186.83136 ]
        keep = np.where((hs >= min_size) & (ws >= min_size))[0]
#        keep  (16650,) [    0     1     2 ... 16647 16648 16649]
        roi = roi[keep, :]
#        roi  (16650, 4) 
#        [[  0.         0.        56.249886  97.67726 ]
#         [  0.         0.        96.3109   184.67094 ]
#         [  0.         0.       171.3389   380.31927 ]
#         ...
#         [497.32355  750.606    600.       800.      ]
#         [389.41406  701.22833  600.       800.      ]
#         [252.67581  613.16864  600.       800.      ]]
        score = score[keep]
#        score  (16650,) [0.49977374 0.4967148  0.5062311  ... 0.48666537 0.49712998 0.50011235]
        
        
        # 4. KEEP only TOP 12000 bbox for training (6000 for testing) with HIGHEST PREDICTED objectness score from ~ all 16650 bbox -----------------------------------------------
        # SORT all (PROPOSAL, SCORE) pairs by predicted objectness score from highest to lowest. 
        order = score.ravel().argsort()[::-1]  # .argsort() : get the index position of sorted array in ascending probability order by default
#        order  (16650,) [ 9150  9141 10162 ...  9911  7753  8705]
        if n_pre_nms > 0:
            order = order[:n_pre_nms]            #  during training, KEEP only 12000 bbox with highest objectness predicted score (by Image & CNN). At test time, for faster inference time & more precise result, we take only 6000 bbox
#            order  (12000,) [ 9150  9141 10162 ... 16625 16283 11968]
        roi = roi[order, :]
#        roi  (12000, 4)                                       #   in decreasing order of predicted objectness score
#        [[235.07632 217.17781 427.34695 312.55505]
#         [220.58783 198.79443 417.54596 292.80673]
#         [294.4995  280.24133 454.24347 670.1232 ]
#         ...
#         [395.4914  406.45807 600.      800.     ]
#         [390.41907   0.      600.      553.4531 ]
#         [253.26155 375.65833 600.      545.9493 ]]
        score = score[order]
#        score  (12000,) [0.5792446  0.57720155 0.57507735 ... 0.4911828  0.49118003 0.49117813]



        # 5. APPLY NMS to reduce proposals redundancy: from 12000 training bbox to ~ 2000 bbox with highest objectness score (with IoU threshold = 0.7) ---------------------------------------------------------
        # Some RPN proposals highly overlap with each other. To reduce redundancy, we adopt non-maximum suppression (NMS) on the proposal regions based on their cls scores. 
        # We fix the IoU threshold for NMS at 0.7, which leaves us about 2000 proposal regions per image. 
        # As we will show, NMS does not harm the ultimate detection accuracy, but substantially reduces the number of proposals
        #
        # Greedily select the PREDICTED BBOX with the HIGHEST SCORE. Remove the remaining PREDICTED BBOX with high IoU (i.e. > 0.7) with previously SELECTED PREDICTED BBOX. (not ground-truth, be careful !!!). Repeat these steps until there's no bbox left.
        # https://www.analyticsvidhya.com/blog/2020/08/selecting-the-right-bounding-box-using-non-max-suppression-with-implementation/

        # unNOTE: something is wrong here!
        # TODO: remove cuda.to_gpu
        keep = nms(                             
            torch.from_numpy(roi).cuda(),
            torch.from_numpy(score).cuda(),
            self.nms_thresh)  #   nms_thresh = 0.7

#        keep  torch.Size([2009])    : NMS is a random function, it can give any array size (1612, 1966, 2009... e.g.) , 
#                                      int64 tensor with the INDICES of the elements that have been KEPT by NMS, sorted in DECREASING order of SCORES
#        tensor([    0,     2,     4,  ..., 11976, 11987, 11991], device='cuda:0')
            
        if n_post_nms > 0:
            keep = keep[:n_post_nms]    # training time: keep MAXIMUM 2000 bbox after NMS fusion operation, test-time: keep MAXIMUM 300 bbox
#            keep  torch.Size([2000]) tensor([    0,     4,     8,  ..., 11646, 11656, 11658], device='cuda:0')     #    keep at most 2000 bbox
            
        roi = roi[keep.cpu().numpy()]

#        roi  (1724, 4)                                                       # MAX 2000 bounding-boxes Regions Proposal (Region of Interest ROI)  x  4 corresponding coordinates  . NOTE: maximum is 2000, due to randomness, it can be less (1940 for ex)
#        [[  0.        42.739    528.5074   376.7633  ]
#         [283.63934    0.       420.3711   103.96875 ]
#         [ 56.598816   0.       405.03427  668.30994 ]
#         ...
#         [446.4488   353.54617  600.       440.49185 ]
#         [287.0526   375.04297  378.7989   551.0982  ]
#         [282.63702  578.0259   410.42755  710.7428  ]]
        
        return roi
