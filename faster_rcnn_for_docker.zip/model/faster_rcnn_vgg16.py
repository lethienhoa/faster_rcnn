from __future__ import  absolute_import
import torch as t
from torch import nn
from torchvision.models import vgg16
from torchvision.ops import RoIPool  # Performs Region of Interest (RoI) Pool operator described in Fast R-CNN

from utils import array_tool as at
from utils.config import opt

from model.region_proposal_network import RegionProposalNetwork  #
from model.faster_rcnn import FasterRCNN                         #

# This file only contain the wrapper VGG16 of Faster RCNN

def decom_vgg16():
    # the 30th layer of features is relu of conv5_3
    if opt.caffe_pretrain:
        model = vgg16(pretrained=False)
        if not opt.load_path:
            model.load_state_dict(t.load(opt.caffe_pretrain_path))
    else:
        model = vgg16(not opt.load_path)

    features = list(model.features)[:30]
    classifier = model.classifier

    classifier = list(classifier)
    del classifier[6]
    if not opt.use_drop:
        del classifier[5]
        del classifier[2]
    classifier = nn.Sequential(*classifier)

    # freeze top4 conv                    #
    for layer in features[:10]:
        for p in layer.parameters():
            p.requires_grad = False

    return nn.Sequential(*features), classifier


class FasterRCNNVGG16(FasterRCNN):
    """Faster R-CNN based on VGG-16.
    For descriptions on the interface of this model, please refer to
    :class:`model.faster_rcnn.FasterRCNN`.

    Args:
        n_fg_class (int): The number of classes excluding the background.
        ratios (list of floats): This is ratios of width to height of
            the anchors.
        anchor_scales (list of numbers): This is areas of anchors.
            Those areas will be the product of the square of an element in
            :obj:`anchor_scales` and the original area of the reference
            window.

    """

    feat_stride = 16  # downsample 16x for output of conv5 in vgg16 (subsampling ratio)

    def __init__(self,
                 n_fg_class=20,
                 ratios=[0.5, 1, 2],       #
                 anchor_scales=[8, 16, 32] #
                 ):
                 
        extractor, classifier = decom_vgg16()                                  # feature extractor & classifier

        rpn = RegionProposalNetwork(                                           #
            512, 512,
            ratios=ratios,
            anchor_scales=anchor_scales,
            feat_stride=self.feat_stride,
        )

        head = VGG16RoIHead(                                                   #
            n_class=n_fg_class + 1,
            roi_size=7,
            spatial_scale=(1. / self.feat_stride),
            classifier=classifier
        )

        super(FasterRCNNVGG16, self).__init__(
            extractor,
            rpn,
            head,
        )


class VGG16RoIHead(nn.Module):
    """Faster R-CNN Head for VGG-16 based implementation.
    This class is used as a head for Faster R-CNN.
    This outputs class-wise localizations and classification based on feature
    maps in the given RoIs.
    
    Args:
        n_class (int): The number of classes possibly including the background.    # n_class = 21 (20 object classes + background)
        roi_size (int): Height and width of the feature maps after RoI-pooling.    # roi_size = 7
        spatial_scale (float): Scale of the roi is resized.                        # spatial_scale = 0.0625 = 1/16 (1/subsampling_ratio)
        classifier (nn.Module): Two layer Linear ported from vgg16
    """

    def __init__(self, n_class, roi_size, spatial_scale, classifier):
        # n_class includes the background
        super(VGG16RoIHead, self).__init__()

        self.classifier = classifier
        self.cls_loc = nn.Linear(4096, n_class * 4)  # n_class = 21 (20 object classes + background)
        self.score = nn.Linear(4096, n_class)

        normal_init(self.cls_loc, 0, 0.001)
        normal_init(self.score, 0, 0.01)

        self.n_class = n_class
        self.roi_size = roi_size
        self.spatial_scale = spatial_scale
        
        # Performs Region of Interest (RoI) Pool operator described in Fast R-CNN
        # RoIPool: FIXED FEATURES output_size for FEEDFORWARD NETWORKS = (7, 7) Equal Region Spatial Pyramid pooling on both Width & Height (not common sliding window pooling)
        # spatial_scale = 1/16 (from COORDINATES of predicted sample bbox of SCALED RAW IMAGE to 'COORDINATES' in FEATURES MAP SIZE 37 * 50)
        self.roi = RoIPool( (self.roi_size, self.roi_size), self.spatial_scale)    


    def forward(self, x, rois, roi_indices):
        """Forward the chain.

        We assume that there are :math:`N` batches.

        Args:
            x (Variable): 4D image variable.
            rois (Tensor): A bounding box array containing coordinates of
                proposal boxes.  This is a concatenation of bounding box
                arrays from multiple images in the batch.
                Its shape is :math:`(R', 4)`. Given :math:`R_i` proposed
                RoIs from the :math:`i` th image,
                :math:`R' = \\sum _{i=1} ^ N R_i`.
            roi_indices (Tensor): An array containing indices of images to
                which bounding boxes correspond to. Its shape is :math:`(R',)`.

        """

#        x : [1, 512, 37, 50]  *features* obtained by CNN (VGG16)
#
#
#
#        rois : sample_roi  (128, 4)    # [128, 4] 4 coordinates of 128 POSITIVE and NEGATIVE BBOX SAMPLES from Max 2000 PREDICTED bounding-boxes Regions Proposal (Region of Interest ROI) that has the HIGHEST OVERLAPPING REGION > (or <=) 0.5 w.r.t GROUND-TRUTH BBOX
#        [[383.26605   377.29407   600.        559.4009   ]
#         [435.51804   455.8985    600.        540.8511   ]
#         [407.90097   321.36078   600.        561.5512   ]
#         [321.29504   308.42358   453.60413   433.7323   ]
#         [339.50854   326.33182   470.59094   450.54117  ]
#         [416.9333    372.28577   524.9664    529.8954   ]
#         [411.02887   400.4822    600.        588.9612   ]
#         [308.80002   329.6       476.80002   416.       ]
#         [420.80002   396.8       593.60004   537.6      ]
#         [336.89325   255.24194   472.21466   378.19446  ]
#         [336.        283.2       540.8       380.8      ]
#         ...        
#
#        roi_indices: sample_roi_index  torch.Size([128])                      # id of image in batch_size, here batch_size = 1 => 128 bbox all have id = 0
#        tensor([0., 0., 0., 0., 0., 0., 0.,.....        
        
        # in case roi_indices is  ndarray
        roi_indices = at.totensor(roi_indices).float()
        rois = at.totensor(rois).float()
        indices_and_rois = t.cat([roi_indices[:, None], rois], dim=1)
        
#        indices_and_rois torch.Size([128, 5])                                 # roi_indices (all zeros - id photo) & 4 coordinates of 128 sample positive & negative bbox
#        tensor([[  0.0000, 383.2661, 377.2941, 600.0000, 559.4009],
#                [  0.0000, 435.5180, 455.8985, 600.0000, 540.8511],
#                [  0.0000, 407.9010, 321.3608, 600.0000, 561.5512],
#                [  0.0000, 321.2950, 308.4236, 453.6041, 433.7323],
#                [  0.0000, 339.5085, 326.3318, 470.5909, 450.5412],
#                [  0.0000, 416.9333, 372.2858, 524.9664, 529.8954],
#                [  0.0000, 411.0289, 400.4822, 600.0000, 588.9612],

        # NOTE: important: yx->xy
        xy_indices_and_rois = indices_and_rois[:, [0, 2, 1, 4, 3]]             # [128, 5] : 5 columns: roi_indices (all zeros - id photo) & (width x-min, height y-min, x-max, y-max)

#        xy_indices_and_rois torch.Size([128, 5]) 
#        tensor([[  0.0000, 377.2941, 383.2661, 559.4009, 600.0000],
#                [  0.0000, 455.8985, 435.5180, 540.8511, 600.0000],
#                [  0.0000, 321.3608, 407.9010, 561.5512, 600.0000],
#                [  0.0000, 308.4236, 321.2950, 433.7323, 453.6041],
#                [  0.0000, 326.3318, 339.5085, 450.5412, 470.5909],
#                [  0.0000, 372.2858, 416.9333, 529.8954, 524.9664],
#                [  0.0000, 400.4822, 411.0289, 588.9612, 600.0000],
#                [  0.0000, 329.6000, 308.8000, 416.0000, 476.8000],

        indices_and_rois =  xy_indices_and_rois.contiguous()

        # Apply 128 positive and negative predicted samples ROI bbox again on CNN features & perform ROI Pooling to get FIXED SIZE for FEEDFORWARD NEURAL NETWORK ============================
        # Then, compute 21 classes (20 objects + background) score & 4 coordinates of each object class (4 * 21 = 84) =========================================
        # https://medium.com/@andrewjong/how-to-use-roi-pool-and-roi-align-in-your-neural-networks-pytorch-1-0-b43e3d22d073
        #
        # x                 : [1, 512, 37, 50]  *features* obtained by CNN (VGG16)
        # indices_and_rois  : [128, 5]          5 columns: roi_indices (all zeros) & (x-min, y-min, x-max, y-max)
        pool = self.roi(x, indices_and_rois)

#        pool torch.Size([128, 512, 7, 7])      #  for each of 128 predicted positive and negative samples bbox : we have a bbox slice of 512 FIXED channels, 7x7 FIXED FEATURES height*weight  FROM [512, 37, 50] features
#        tensor([[[[0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                  [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                  [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                  ...,
#                  [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                  [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                  [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000]],
#        
#                 [[0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                  [0.0000, 0.0540, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                  [1.7878, 1.7878, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                  ...,
#                  [0.0000, 0.3212, 1.5838,  ..., 0.2014, 0.0000, 0.0000],
#                  [0.0000, 0.0000, 1.2419,  ..., 0.0000, 0.0000, 0.0000],
#                  [0.0000, 0.0000, 0.1657,  ..., 0.0000, 0.0000, 0.0000]],

        pool = pool.view(pool.size(0), -1)

#        pool torch.Size([128, 25088]) 
#        tensor([[0., 0., 0.,  ..., 0., 0., 0.],
#                [0., 0., 0.,  ..., 0., 0., 0.],
#                [0., 0., 0.,  ..., 0., 0., 0.],
#                ...,
#                [0., 0., 0.,  ..., 0., 0., 0.],
#                [0., 0., 0.,  ..., 0., 0., 0.],
#                [0., 0., 0.,  ..., 0., 0., 0.]], device='cuda:0',
#               grad_fn=<ViewBackward>)

        fc7 = self.classifier(pool)         # second last classifier of VGG16

#        fc7 torch.Size([128, 4096]) 
#        tensor([[0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0000],
#                ...,
#                [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0879, 0.1543],
#                [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.0837],
#                [0.0000, 0.0000, 0.0000,  ..., 0.0000, 0.0000, 0.3240]],
#               device='cuda:0', grad_fn=<ReluBackward1>)

        roi_cls_locs = self.cls_loc(fc7)

#        roi_cls_locs torch.Size([128, 84])                                    # 21 classes (20 object classes + background) * 4 INCREMENTAL coordinates  OBJECT ROI sample bbox to ground-truth bbox 
#        tensor([[ 2.3361e-02,  5.1721e-02, -9.4898e-03,  ..., -2.6796e-02, 2.7425e-03, -7.4335e-03],
#                [ 8.4832e-03,  4.4859e-02,  1.1071e-02,  ..., -2.4948e-02, 2.3907e-02, -6.5800e-03],
#                [ 1.4902e-02,  3.7563e-02, -8.6419e-03,  ..., -1.1015e-02,-8.2988e-05, -1.4083e-02],
#                ...,
#                [-1.7331e-02,  1.5235e-03, -3.1996e-02,  ...,  4.0901e-03, -1.6853e-02,  6.1920e-03],
#                [ 3.5230e-02,  9.9208e-03,  2.5442e-03,  ..., -3.2313e-02, 3.1963e-02, -2.6983e-02],
#                [ 3.9199e-03,  7.0513e-02, -4.1272e-02,  ..., -6.2037e-03, 2.6381e-02, -4.4130e-03]], device='cuda:0', grad_fn=<AddmmBackward>)

        roi_scores = self.score(fc7)

#        roi_scores torch.Size([128, 21])                                      # 21 object scores (20 object classes + background)
#        tensor([[ 0.3237, -0.1683, -0.2037,  ...,  0.1305,  0.5009, -0.4061],
#                [ 0.0662, -0.0491, -0.0649,  ...,  0.1462,  0.3161, -0.2695],
#                [ 0.2649, -0.1429, -0.0971,  ...,  0.0496,  0.3100, -0.4186],
#                ...,
#                [-0.1920,  0.3956, -0.2486,  ..., -0.1070,  0.3637,  0.1624],
#                [ 0.0360,  0.0459,  0.0788,  ...,  0.0969, -0.2308, -0.2668],
#                [ 0.3036, -0.0374, -0.1368,  ...,  0.2855,  0.5802, -0.2827]],
#               device='cuda:0', grad_fn=<AddmmBackward>)
        
        return roi_cls_locs, roi_scores


def normal_init(m, mean, stddev, truncated=False):
    """
    weight initalizer: truncated normal and random normal.
    """
    # x is a parameter
    if truncated:
        m.weight.data.normal_().fmod_(2).mul_(stddev).add_(mean)  # not a perfect approximation
    else:
        m.weight.data.normal_(mean, stddev)
        m.bias.data.zero_()
