import os
import xml.etree.ElementTree as ET
import numpy as np
import json

from .util import read_image


class VOCBboxDataset:
    """Bounding box dataset for PASCAL `VOC`_.

    .. _`VOC`: http://host.robots.ox.ac.uk/pascal/VOC/voc2012/

    The index corresponds to each image.

    When queried by an index, if :obj:`return_difficult == False`,
    this dataset returns a corresponding
    :obj:`img, bbox, label`, a tuple of an image, bounding boxes and labels.
    This is the default behaviour.
    If :obj:`return_difficult == True`, this dataset returns corresponding
    :obj:`img, bbox, label, difficult`. :obj:`difficult` is a boolean array
    that indicates whether bounding boxes are labeled as difficult or not.

    The bounding boxes are packed into a two dimensional tensor of shape
    :math:`(R, 4)`, where :math:`R` is the number of bounding boxes in
    the image. The second axis represents attributes of the bounding box.
    They are :math:`(y_{min}, x_{min}, y_{max}, x_{max})`, where the
    four attributes are coordinates of the top left and the bottom right
    vertices.

    The labels are packed into a one dimensional tensor of shape :math:`(R,)`.
    :math:`R` is the number of bounding boxes in the image.
    The class name of the label :math:`l` is :math:`l` th element of
    :obj:`VOC_BBOX_LABEL_NAMES`.

    The array :obj:`difficult` is a one dimensional boolean array of shape
    :math:`(R,)`. :math:`R` is the number of bounding boxes in the image.
    If :obj:`use_difficult` is :obj:`False`, this array is
    a boolean array with all :obj:`False`.

    The type of the image, the bounding boxes and the labels are as follows.

    * :obj:`img.dtype == numpy.float32`
    * :obj:`bbox.dtype == numpy.float32`
    * :obj:`label.dtype == numpy.int32`
    * :obj:`difficult.dtype == numpy.bool`

    Args:
        data_dir (string): Path to the root of the training data. 
            i.e. "/data/image/voc/VOCdevkit/VOC2007/"
        split ({'train', 'val', 'trainval', 'test'}): Select a split of the
            dataset. :obj:`test` split is only available for
            2007 dataset.
        year ({'2007', '2012'}): Use a dataset prepared for a challenge
            held in :obj:`year`.
        use_difficult (bool): If :obj:`True`, use images that are labeled as
            difficult in the original annotation.
        return_difficult (bool): If :obj:`True`, this dataset returns
            a boolean array
            that indicates whether bounding boxes are labeled as difficult
            or not. The default value is :obj:`False`.

    """

    def __init__(self, data_dir, split='trainval',
                 use_difficult=False, return_difficult=False,
                 ):

        # if split not in ['train', 'trainval', 'val']:
        #     if not (split == 'test' and year == '2007'):
        #         warnings.warn(
        #             'please pick split from \'train\', \'trainval\', \'val\''
        #             'for 2012 dataset. For 2007 dataset, you can pick \'test\''
        #             ' in addition to the above mentioned splits.'
        #         )
        split = data_dir.split("/")[-2]
        id_list_file = os.path.join( data_dir, '{0}.txt'.format(split) )

        self.ids = [id_.strip() for id_ in open(id_list_file)]   # 5011 images on trainval : '000005', '000007', '000009', '000012', '000016', ....
        self.data_dir = data_dir
        self.use_difficult = use_difficult
        self.return_difficult = return_difficult
        self.label_names = VOC_BBOX_LABEL_NAMES

    def __len__(self):
        return len(self.ids)

    def get_example(self, i):
        """Returns the i-th example.

        Returns a color image and bounding boxes. The image is in CHW format.
        The returned image is RGB.

        Args:
            i (int): The index of the example.

        Returns:
            tuple of an image and bounding boxes

        """
        id_ = self.ids[i]  # e.g. :   adidas_000003.jpg
        
        f = open(os.path.join(self.data_dir, 'Annotations', id_[:-4] + '.json'))
        anno = json.load(f)
        # e.g. anno :  {"filename": "adidas_000003.jpg", "coordinates": [[286.25, 47.5, 96.0, 67.5]], "logo": "adidas", "coor-order": ["x-min", "y-min", "width", "height"]}
        
        
        
        bbox = np.array(anno['coordinates']).astype(np.float32)
        bbox -= 1                             # subtract 1 to make pixel indexes 0-based
        for ibbox in range(bbox.shape[0]):
            bbox[ibbox, 2] += bbox[ibbox, 0]  # x-max = x-min + width
            bbox[ibbox, 3] += bbox[ibbox, 1]  # y-max = y-min + height
        # reorder from (x-min, y-min, x-max, y-max) to (y-min, x-min, y-max, x-max)
        bbox = bbox[:, [1, 0, 3, 2]]
        
        label = np.array([VOC_BBOX_LABEL_NAMES.index(anno['logo'])] * bbox.shape[0]).astype(np.int32)
        difficult = np.array([0] * bbox.shape[0], dtype=np.bool).astype(np.uint8)  # PyTorch don't support np.bool
        
#        print(id_, bbox, )
#        print("bbox", bbox)
#        print("label", label)
#        print("difficult", difficult)
        
        

        # Load an image
        img_file = os.path.join(self.data_dir, 'JPEGImages', id_)
        img = read_image(img_file, color=True)  # read image using PIL and reshape, transform it into numpy vectors
        
        return id_, img, bbox, label, difficult

    __getitem__ = get_example


# Logos-32plus (32 logos) --------------------

# VOC_BBOX_LABEL_NAMES = (
#     'adidas',
#     'aldi',
#     'apple',
#     'becks',
#     'bmw',
#     'carlsberg',
#     'chimay',
#     'cocacola',
#     'corona',
#     'dhl',
#     'erdinger',
#     'esso',
#     'fedex',
#     'ferrari',
#     'ford',
#     'fosters',
#     'google',
#     'guinness',
#     'heineken',
#     'HP',
#     'milka',
#     'nvidia',
#     'paulaner',
#     'pepsi',
#     'rittersport',
#     'shell',
#     'singha',
#     'starbucks',
#     'stellaartois',
#     'texaco',
#     'tsingtao',
#     'ups')



# Myli 12 Logos ---------------------

VOC_BBOX_LABEL_NAMES = (
    'bigfernand',
    'cashexpress',
    'freshburritos',
    'hapik',
    'marieblachere',
    'memphis',
    'pitaya',
    'pizzacosy',
    'pokawa',
    'pommedepain',
    'profilplus',
    'vapiano')




# LogoDet-3k-Food 100 Logos --------------------

# VOC_BBOX_LABEL_NAMES = open("LogoDet-3k-Food-brandlist.txt").readlines()
# VOC_BBOX_LABEL_NAMES = tuple([brand.strip() for brand in VOC_BBOX_LABEL_NAMES])




print("VOC_BBOX_LABEL_NAMES", VOC_BBOX_LABEL_NAMES)
